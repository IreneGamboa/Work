/*
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  BaseViewController.m
//  Zimple POS
//

#import "BaseViewController.h"

#define NOT_LOGGED_IN_ERROR_CODE 8
#define EXPIRED_SESSION_ERROR_CODE 54
#define ExpiredSessionAlertViewTag 1000

@interface BaseViewController ()

//@property (retain, nonatomic) MKMapView *userLocationMapView;

@end

@implementation BaseViewController

@synthesize HUD;
@synthesize currentStatusBarStyle;
//@synthesize userLocationMapView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    
    UIImage *backgroundImage = [UIImage imageNamed:@"Gray_Background_Tall"];
    self.view.backgroundColor = [UIColor colorWithPatternImage:backgroundImage];
    
    UITapGestureRecognizer *myLabelTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTap:)];
    [self.view addGestureRecognizer:myLabelTap];
    [myLabelTap setCancelsTouchesInView:NO];
    
    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"NavigationBackButtonText", "") style:UIBarButtonItemStylePlain target:nil action:nil];
    
    /*// Configure the MKMapView to locate the user (this MKMapView is never visible to the user)
    userLocationMapView = [[MKMapView alloc] initWithFrame:CGRectMake(0, 0, 0, 0)];
    [self.view addSubview:userLocationMapView];
    userLocationMapView.showsUserLocation = YES;
    userLocationMapView.delegate = self;*/
    
    // Prevents the view controller from expanding its contents to fullscreen on iOS 7.
    //self.edgesForExtendedLayout = UIRectEdgeNone;
    
    currentStatusBarStyle = UIStatusBarStyleLightContent;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// All the View Controllers only allow Portrait Orientation

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskPortrait;
}


- (void)handleTap:(UIGestureRecognizer *)gestureRecognizer {
    [self.view endEditing:YES];
}

- (void)continueEditingAfterLeftMenuCloses{
}

- (BOOL)checkSessionExpiration:(NSError *)error{
    if (error.code == EXPIRED_SESSION_ERROR_CODE || error.code == NOT_LOGGED_IN_ERROR_CODE){
        UIAlertView *errorAlertView = [[UIAlertView alloc] initWithTitle:@"Sesión Expirada" message:error.localizedDescription delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        errorAlertView.delegate = self;
        errorAlertView.tag = ExpiredSessionAlertViewTag;
        [errorAlertView show];
        
        UIViewController *loginViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"LoginViewController"];
        [self presentModalViewController:loginViewController animated:YES];
        
        return YES;
    }
    return NO;
}

/*#pragma mark MKMapViewDelegate Methods

- (void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{
    NSLog(@"New Location: %f %f", userLocation.location.coordinate.latitude, userLocation.location.coordinate.longitude);
    // Save the new location to the user info.
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    
    CLLocationDistance meters = [userLocation.location distanceFromLocation:userInfo.userLocation];
    userInfo.userLocation = userLocation.location;
    if (meters < 10){
        // Desired accuracy threshold, stop requesting location
        mapView.showsUserLocation = NO;
    }
}*/

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return currentStatusBarStyle;
    //return UIStatusBarStyleLightContent;
}

@end
