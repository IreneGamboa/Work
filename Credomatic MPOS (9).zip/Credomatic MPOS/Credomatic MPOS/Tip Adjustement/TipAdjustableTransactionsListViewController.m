/*
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  TipAdjustableTransactionsListViewController.m
//  Zimple POS
//

#import "TipAdjustableTransactionsListViewController.h"

#define AdjustTipAlertViewTag 0
#define AdminUserAlertView 1
#define ErrorAlertViewTag 1000

#define ReferenceNumberLabelTag 100
#define DateLabelTag 101
#define AmountLabelTag 102
#define AuthorizationNumberLabelTag 103
#define TipValueLabelTag 104

#define PINLength 4

@interface TipAdjustableTransactionsListViewController ()

@end

@implementation TipAdjustableTransactionsListViewController

@synthesize transactionsTableView;
@synthesize noTransactionsLabel;
@synthesize transactionsByAffiliateCode;
@synthesize tipAdjustmentTransactionResult;
@synthesize transactionToAdjustTip;
@synthesize transactionToAdjustTipAffiliateCode;
@synthesize tipAdjustementAmount;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    UIView *tableViewBackgroundView = [[UIView alloc] initWithFrame:transactionsTableView.frame];
    tableViewBackgroundView.backgroundColor = [UIColor clearColor];
    transactionsTableView.backgroundView = tableViewBackgroundView;
    transactionsTableView.backgroundColor = [UIColor clearColor];
    
    noTransactionsLabel.textColor = [UIColorList credomaticGrayColor];
    noTransactionsLabel.hidden = YES;
    
    transactionsByAffiliateCode = [[NSDictionary alloc] init];
    
    if (NSClassFromString(@"UIRefreshControl") != nil) {
        UIRefreshControl *refreshControl = [[UIRefreshControl alloc] init];
        [refreshControl addTarget:self action:@selector(refresh:) forControlEvents:UIControlEventValueChanged];
        [self.transactionsTableView addSubview:refreshControl];
    }
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    noTransactionsLabel.hidden = YES;
    
    [self refreshTransactions];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
    [self setTransactionsTableView:nil];
    [self setNoTransactionsLabel:nil];
    [super viewDidUnload];
}

- (void)refresh:(UIRefreshControl *)refreshControl {
    [self refreshTransactions]; 
    [refreshControl endRefreshing];
}

- (IBAction)refreshBarButtonTouchUpInside:(id)sender {
    [self refreshTransactions];
}

- (void)refreshTransactions{
    // Refresh the Results
    self.HUD.labelText = @"Cargando Transacciones";
    [self.HUD show:YES];
    SalesManager *salesManager = [[SalesManager alloc] init];
    salesManager.salesManagerDelegate = self;
    [salesManager getVoidableTransactions];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([segue.identifier isEqualToString:@"TipAdjustementTransactionToRecipeSegue"]){
        RecipeViewController *recipeViewController = segue.destinationViewController;
        UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
        //TransactionInfo *transactionInfo = userInfo.sessionInfo.currentTransactionInfo;
        SaleTransactionInfo *transactionInfo = [[SaleTransactionInfo alloc] init];
        transactionInfo.transactionResult = tipAdjustmentTransactionResult;
        transactionInfo.affiliate = [userInfo.terminalInfo.terminal affiliateByAffiliateCode:transactionToAdjustTipAffiliateCode];
        transactionInfo.creditCardInfo = [[CreditCardInfo alloc] init];
        //transactionInfo.creditCardInfo.creditCardNumberMasked = [NSString stringWithFormat:@"************%@", transactionToAdjustTip.creditCardLastDigits];
        transactionInfo.creditCardInfo.creditCardNumberMasked = transactionToAdjustTip.maskedCreditCard;
        transactionInfo.tipValue = tipAdjustementAmount;
        NSIndexPath *currentIndexPath = [transactionsTableView indexPathForSelectedRow];
        NSString *affiliateCode = [[transactionsByAffiliateCode allKeys] objectAtIndex:currentIndexPath.section];
        NSMutableArray *transactions = [transactionsByAffiliateCode objectForKey:affiliateCode];
        TransactionRecord *transactionRecord = [transactions objectAtIndex:currentIndexPath.row];
        transactionInfo.taxValue = transactionRecord.saleTaxAmount;
        transactionInfo.amount = transactionRecord.subTotalSaleAmountWithFormat;
        userInfo.sessionInfo.currentTransactionInfo = transactionInfo;
        recipeViewController.transactionTypeId = TipAdjustementTransactionTypeId;
    }
}

#pragma mark UITableViewDataSource Methods

-(int)numberOfSectionsInTableView:(UITableView *)tableView{
    return [[transactionsByAffiliateCode allKeys] count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSString *affiliateCode = [[transactionsByAffiliateCode allKeys] objectAtIndex:section];
    NSArray *transactions = [transactionsByAffiliateCode objectForKey:affiliateCode];
    return [transactions count];
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"TipAdjustableTransactionCell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    }
    
    // Configure the cell.
    NSString *affiliateCode = [[transactionsByAffiliateCode allKeys] objectAtIndex:indexPath.section];
    NSMutableArray *transactions = [transactionsByAffiliateCode objectForKey:affiliateCode];
    TransactionRecord *transactionRecord = [transactions objectAtIndex:indexPath.row];
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    Affiliate *affiliate = [userInfo.terminalInfo.terminal affiliateByAffiliateCode:affiliateCode];
    UILabel *referenceNumberLabel = (UILabel *)[cell viewWithTag:ReferenceNumberLabelTag];
    UILabel *dateLabel = (UILabel *)[cell viewWithTag:DateLabelTag];
    UILabel *amountLabel = (UILabel *)[cell viewWithTag:AmountLabelTag];
    UILabel *authorizationNumberLabel = (UILabel *)[cell viewWithTag:AuthorizationNumberLabelTag];
    UILabel *tipValueLabel = (UILabel *)[cell viewWithTag:TipValueLabelTag];
    //referenceNumberLabel.text = [NSString stringWithFormat:@"***********%@", transactionRecord.creditCardLastDigits];
    referenceNumberLabel.text = transactionRecord.maskedCreditCard;
    dateLabel.text = transactionRecord.transactionDateAndTimeWithFormat;
    amountLabel.text = [NSString stringWithFormat:@"%@ %@", transactionRecord.saleAmountWithFormat, affiliate.currencyCode];
    amountLabel.textColor = [UIColorList credomaticBlueColor];
    authorizationNumberLabel.text = [NSString stringWithFormat:@"Auth# %@", transactionRecord.saleAuthorizationNumber];
    tipValueLabel.text = [NSString stringWithFormat:@"Propina (%@ %@)", transactionRecord.saleTipAmount, affiliate.currencyCode];
    tipValueLabel.textColor = [UIColorList lightBlueColor];
    
    return cell;
}

#pragma mark UITableViewDataDelegate Methods
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    // Let the user enter the new amount for the tip
    NSString *affiliateCode = [[transactionsByAffiliateCode allKeys] objectAtIndex:indexPath.section];
    NSMutableArray *transactions = [transactionsByAffiliateCode objectForKey:affiliateCode];
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    Affiliate *affiliate = [userInfo.terminalInfo.terminal affiliateByAffiliateCode:affiliateCode];
    TransactionRecord *transactionRecord = [transactions objectAtIndex:indexPath.row];
    
    UIAlertView *adjustTipAlertView = [[UIAlertView alloc] initWithTitle:@"Ajuste de Propina" message:[NSString stringWithFormat:@"Su propina actual es de %@ %@, por favor digite su nuevo monto.", transactionRecord.saleTipAmount, affiliate.currencyCode] delegate:self cancelButtonTitle:@"Cancelar" otherButtonTitles:@"Sí", nil];
    adjustTipAlertView.tag = AdjustTipAlertViewTag;
    adjustTipAlertView.alertViewStyle = UIAlertViewStylePlainTextInput;
    UITextField *amountTextField = [adjustTipAlertView textFieldAtIndex:0];
    amountTextField.placeholder = [NSString stringWithFormat:@"Monto de Propina en %@", affiliate.currencyCode];
    amountTextField.keyboardType = UIKeyboardTypeDecimalPad;
    [adjustTipAlertView show];
}

-(UIView *) tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    static NSString *CellIdentifier = @"TableViewAffiliateHeader";
    UITableViewCell *headerView = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    UILabel *sectionTitleLabel = (UILabel *)[headerView viewWithTag:1];
    if (headerView == nil){
        [NSException raise:@"headerView == nil.." format:@"No cells with matching CellIdentifier loaded from your storyboard"];
    }
    // Set the Affiliate Name in the header
    NSString *affiliateCode = [[transactionsByAffiliateCode allKeys] objectAtIndex:section];
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    Affiliate *affiliate = [userInfo.terminalInfo.terminal affiliateByAffiliateCode:affiliateCode];
    sectionTitleLabel.text = [affiliate affiliateTitle];
    
    return headerView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 60;
}

#pragma mark SalesManagerDelegate Methods

- (void)getVoidableTransactionsResponseReceived:(NSDictionary *)transactionsByAffiliateCode error:(NSError *)error{
    [self.HUD hide:YES];
    
    if (transactionsByAffiliateCode != nil){
        self.transactionsByAffiliateCode = transactionsByAffiliateCode;
        [transactionsTableView reloadData];
        [transactionsTableView setContentOffset:CGPointZero animated:YES];
        
        BOOL hasTransactions = NO;
        for(id key in self.transactionsByAffiliateCode) {
            NSArray *transactions = [self.transactionsByAffiliateCode objectForKey:key];
            if ([transactions count] != 0){
                noTransactionsLabel.hidden = YES;
                hasTransactions = YES;
                break;
            }

        }
        if (!hasTransactions){
            noTransactionsLabel.hidden = NO;
        }
    }else{
        if (![super checkSessionExpiration:error]){
            UIAlertView *errorAlertView = [[UIAlertView alloc] initWithTitle:@"Listado de Transacciones" message:error.localizedDescription delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
            errorAlertView.delegate = self;
            errorAlertView.tag = ErrorAlertViewTag;
            [errorAlertView show];
        }
    }
}

- (void)tipAdjustementTransactionResponseReceived:(TransactionResult *)transactionResult error:(NSError *)error{
    [self.HUD hide:YES];
    
    if (transactionResult != nil){
        UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
        // Log Localytics event
        NSDictionary *dictionary =
        [NSDictionary dictionaryWithObjectsAndKeys:
         userInfo.terminalId,
         LocalyticsEventParameterNameTerminalId,
         userInfo.sessionInfo.sessionUserName,
         LocalyticsEventParameterNameUser,
         nil];
        [[LocalyticsSession shared] tagEvent:LocalyticsEventNameMakeTipAdjustement attributes:dictionary];
        
        tipAdjustmentTransactionResult = transactionResult;
        // Show the voucher for the Tip Adjustement Transaction
        [self performSegueWithIdentifier:@"TipAdjustementTransactionToRecipeSegue" sender:self];
    }else{
        if (![super checkSessionExpiration:error]){
            UIAlertView *errorAlertView = [[UIAlertView alloc] initWithTitle:@"Anular Transacción" message:error.localizedDescription delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
            errorAlertView.delegate = self;
            errorAlertView.tag = ErrorAlertViewTag;
            [errorAlertView show];
        }
    }
}

#pragma mark UIAlertViewDelegate Methods

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    // Obtain the transaction info
    if (transactionsTableView.indexPathForSelectedRow != nil){
        NSIndexPath *currentIndexPath = [transactionsTableView indexPathForSelectedRow];
        NSString *affiliateCode = [[transactionsByAffiliateCode allKeys] objectAtIndex:currentIndexPath.section];
        NSMutableArray *transactions = [transactionsByAffiliateCode objectForKey:affiliateCode];
        TransactionRecord *transactionRecord = [transactions objectAtIndex:currentIndexPath.row];
        UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
        Affiliate *affiliate = [userInfo.terminalInfo.terminal affiliateByAffiliateCode:affiliateCode];
        
        if (alertView.tag == AdjustTipAlertViewTag){
            if (buttonIndex != alertView.cancelButtonIndex){
                UITextField *tipTextField = [alertView textFieldAtIndex:0];
                //tipAdjustementAmount =  tipTextField.text;
                //tipAdjustementAmount = [NSString stringWithFormat:@"%.02f", [tipTextField.text floatValue]];
                NSNumber *tipAdjutstementNumber = [AmountFormatter convertAmountToNumber:tipTextField.text];
                tipAdjustementAmount = [AmountFormatter formatNumberAmountAsString:tipAdjutstementNumber];
                // Check if the current user can change the tip amount for a transaction
                UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
                if (userInfo.terminalInfo.userAdjustTipForTransactions){
                    
                    self.HUD.labelText = @"Ajustando Propina";
                    [self.HUD show:YES];
                    // Do the Transaction Void
                    SalesManager *salesManager = [[SalesManager alloc] init];
                    salesManager.salesManagerDelegate = self;
                    [salesManager adjustTransactionTip:transactionRecord affiliate:affiliate tipNewAmount:tipAdjustementAmount];
                    transactionToAdjustTip = transactionRecord;
                    transactionToAdjustTipAffiliateCode = affiliateCode;
                }else{
                    // Show an alert for the user to input the user and pin of someone who can.
                    UIAlertView *adminUserAlertView = [[UIAlertView alloc] initWithTitle:@"Usuario Administrador" message:@"Credenciales de Administrador:" delegate:self cancelButtonTitle:@"Cancelar" otherButtonTitles:@"Ok", nil];
                    adminUserAlertView.tag = AdminUserAlertView;
                    adminUserAlertView.alertViewStyle = UIAlertViewStyleLoginAndPasswordInput;
                    UITextField *userNameTextField = [adminUserAlertView textFieldAtIndex:0];
                    userNameTextField.placeholder = @"Nombre de Usuario";
                    userNameTextField.textAlignment = NSTextAlignmentCenter;
                    userNameTextField.keyboardType = UIKeyboardTypeEmailAddress;
                    UITextField *pinTextField = [adminUserAlertView textFieldAtIndex:1];
                    pinTextField.placeholder = @"Pin de Anulación";
                    pinTextField.textAlignment = NSTextAlignmentCenter;
                    pinTextField.keyboardType = UIKeyboardTypeNumberPad;
                    [adminUserAlertView show];
                }
            }else{
                // Deselect the current selected row
                [transactionsTableView deselectRowAtIndexPath:transactionsTableView.indexPathForSelectedRow animated:YES];
            }
        }else if (alertView.tag == AdminUserAlertView){
            if (buttonIndex != alertView.cancelButtonIndex){
                
                NSString *username = [alertView textFieldAtIndex:0].text;
                NSString *userPin = [alertView textFieldAtIndex:1].text;
                
                self.HUD.labelText = @"Ajustando Propina";
                [self.HUD show:YES];
                // Do the Transaction Void with the new user credentials
                SalesManager *salesManager = [[SalesManager alloc] init];
                salesManager.salesManagerDelegate = self;
                [salesManager adjustTransactionTip:transactionRecord affiliate:affiliate tipNewAmount:tipAdjustementAmount username:username userPIN:userPin];
                //[salesManager voidTransaction:transactionRecord username:username userPIN:userPin];
                transactionToAdjustTip = transactionRecord;
                transactionToAdjustTipAffiliateCode = affiliateCode;
            }else{
                // Deselect the current selected row
                [transactionsTableView deselectRowAtIndexPath:transactionsTableView.indexPathForSelectedRow animated:YES];
            }
        }else if (alertView.tag == ErrorAlertViewTag){
            if (transactionsTableView.indexPathForSelectedRow != nil){
                // Deselect the current selected row
                [transactionsTableView deselectRowAtIndexPath:transactionsTableView.indexPathForSelectedRow animated:YES];
            }
        }
    }
}

- (BOOL)alertViewShouldEnableFirstOtherButton:(UIAlertView *)alertView
{
    if (alertView.tag == AdminUserAlertView){
        NSString *userNameText = [[alertView textFieldAtIndex:0] text];
        NSString *pinText = [[alertView textFieldAtIndex:1] text];
        if([RegularExpressionsValidator matchRegExWithValue:EmailRegEx value:userNameText])
        {
            // Username is a valid email
            if (pinText.length ==  PINLength){
                return YES;
            }
        }
        return NO;
    }else if (alertView.tag == AdjustTipAlertViewTag){
        NSString *tipAmount = [[alertView textFieldAtIndex:0] text];
        if ([tipAmount doubleValue] >= 0){
            return YES;
        }
        return NO;
    }
    return YES;
}

@end
