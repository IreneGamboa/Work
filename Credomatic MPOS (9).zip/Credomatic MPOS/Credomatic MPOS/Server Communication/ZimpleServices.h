/*  
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  ZimpleServices.h
//  Zimple POS
//

#import <Foundation/Foundation.h>
#import "AFHTTPClient.h"
#import "AFJSONRequestOperation.h"
#import "NSString+UUID.h"
#import "ServerComunnicationConstants.h"
#import "EncryptionHelper.h"

@protocol ZimpleBackendServicesDelegate <NSObject>
@optional
- (void)terminalActivationResponseReceived:(NSData *)responseData error:(NSError *)error;
- (void)sessionHandshakeResponseReceived:(NSData *)responseData error:(NSError *)error;
- (void)loginResponseReceived:(NSData *)responseData error:(NSError *)error;
- (void)logoutResponseReceived:(NSData *)responseData error:(NSError *)error;
- (void)changeUserPasswordResponseReceived:(NSData *)responseData error:(NSError *)error;
- (void)resetPasswordResponseReceived:(NSData *)responseData error:(NSError *)error;
- (void)changeUserPINResponseReceived:(NSData *)responseData error:(NSError *)error;
- (void)saleResponseReceived:(NSData *)responseData error:(NSError *)error;
- (void)ackResponseReceived:(NSData *)responseData error:(NSError *)error;
- (void)registerSignatureResponseReceived:(NSData *)responseData error:(NSError *)error;
- (void)sendEmailReceiptResponseReceived:(NSData *)responseData error:(NSError *)error;
- (void)terminalSettlementResponseReceived:(NSData *)responseData error:(NSError *)error;
- (void)voidableTransactionsListResponseReceived:(NSData *)responseData error:(NSError *)error;
- (void)voidTransactionResponseReceived:(NSData *)responseData error:(NSError *)error;
- (void)transactionsListResponseReceived:(NSData *)responseData error:(NSError *)error;
- (void)refundResponseReceived:(NSData *)responseData error:(NSError *)error;
- (void)tipAdjustementResponseReceived:(NSData *)responseData error:(NSError *)error;
@end

@interface ZimpleServices : NSObject{

}

@property (nonatomic, strong) id <ZimpleBackendServicesDelegate> zimpleBackendServicesDelegate;

- (void)activateTerminal:(NSString *)terminalId localPublicKey:(NSString *)localPublicKey activationToken:(NSString *)activationToken;
- (void)getSessionHandshake:(NSString *)terminalId encryptedKeyFirstHalfAndIV:(NSString *)encryptedKeyFirstHalfAndIV;
- (void)login:(NSString *)terminalId username:(NSString *)username password:(NSString *)password;
- (void)logout:(NSString *)terminalId;
- (void)changeUserPassword:(NSString *)terminalId password:(NSString *)password newPassword:(NSString *)newPassword;
- (void)resetUserPassword:(NSString *)terminalId email:(NSString *)email;
- (void)changeUserPIN:(NSString *)terminalId password:(NSString *)password pin:(NSString *)pin;
- (void)sale:(NSString *)terminalId sessionkey:(NSString *)sessionKey cardPayload:(NSString *)cardPayload saleAmount:(NSString *)saleAmount affiliatedId:(NSString *)affiliateId latitude:(NSString *)latitude longitude:(NSString *)longitude taxAmount:(NSString *)taxAmount tipAmount:(NSString *)tipAmount;
- (void)ack:(NSString *)terminalId sessionkey:(NSString *)sessionKey transactionId:(NSString *)transactionId;
- (void)registerSignature:(NSString *)terminalId sessionkey:(NSString *)sessionKey transactionId:(NSString *)transactionId signatureBase64:(NSString *)signatureBase64;
- (void)sendEmailReceipt:(NSString *)terminalId sessionkey:(NSString *)sessionKey transactionId:(NSString *)transactionId email:(NSString *)email;
- (void)terminalSettlement:(NSString *)terminalId sessionkey:(NSString *)sessionKey bankTerminalAffiliate:(NSString *)bankTerminalAffiliate;
- (void)voidableTransactionsList:(NSString *)terminalId sessionkey:(NSString *)sessionKey;
- (void)voidTransaction:(NSString *)terminalId sessionkey:(NSString *)sessionKey transactionId:(NSString *)transactionId latitude:(NSString *)latitude longitude:(NSString *)longitude voidAsUser:(NSString *)voidAsUser voidAsUserPIN:(NSString *)voidAsUserPIN;
- (void)transactionsList:(NSString *)terminalId sessionkey:(NSString *)sessionKey startDate:(NSString *)startDate endDate:(NSString *)endDate transactionType:(NSString *)transactionType;
- (void)refund:(NSString *)terminalId sessionkey:(NSString *)sessionKey cardPayload:(NSString *)cardPayload refundAmount:(NSString *)refundAmount affiliatedId:(NSString *)affiliateId latitude:(NSString *)latitude longitude:(NSString *)longitude refundAsUser:(NSString *)refundAsUser refundAsUserPIN:(NSString *)refundAsUserPIN;
- (void)adjustTransactionTip:(NSString *)terminalId sessionkey:(NSString *)sessionKey transactionId:(NSString *)transactionId latitude:(NSString *)latitude longitude:(NSString *)longitude adjustTipAsUser:(NSString *)adjustTipAsUser adjustTipAsUserPIN:(NSString *)adjustTipAsUserPIN tipAmount:(NSString *)tipAmount affiliate:(NSString *)affiliateId;
@end
