/*
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  ServerComunnicationConstants.h
//  Zimple POS
//

// Set the Base url for services. When is compiled as Debug, use the Development Environment.
// When compiled as Release, use the Production Environment.
#ifdef DEBUG
    #define ZimpleBackendServicesBaseUrl @"https://mobadmin.net/zimple/public/"
#else
    #define ZimpleBackendServicesBaseUrl @"https://mipos.credomatic.com/"
#endif


#define ZimpleBackendRequestsUserAgent @"Zimple POS iOS"

#define ActivateTerminalPostPath @"api/v1/pos_public_key"
#define SessionHandshakePostPath @"api/v1/pos_session_key"
#define LoginPostPath @"api/v1/pos_session"
#define LogoutDeletePath @"api/v1/pos_session/session"
#define ChangeUserPasswordPutPath @"api/v1/user_password/user"
#define ResetUserPasswordPostPath @"api/v1/user_recover_password"
#define ChangeUserPINPutPath @"api/v1/user_pin/user"
#define SalePostPath @"api/v1/pos_sales"
#define SaleACKPostPath @"api/v1/pos_acks"
#define RegisterSignaturePostPath @"api/v1/signature"
#define SendEmailReceiptPostPath @"api/v1/pos_email_buyer"
#define TerminalSettlementPostPath @"api/v1/pos_settles"
#define VoidableTransactionsListGetPath @"api/v1/pos_voidable_transactions"
#define VoidTransactionPostPath @"api/v1/pos_voids"
#define TransactionsListGetPath @"api/v1/pos_transaction_queries"
#define RefundPostPath @"api/v1/pos_refunds"
#define TipAdjustementPostPath @"api/v1/pos_adjust_tips"

#define TerminaIdParameterName @"terminal_id"
#define PublicKeyParameterName @"public_key"
#define ResetTokenKeyParameterName @"reset_token"
#define KeyParameterName @"key"
#define MessageParameterName @"message"
#define TerminalIdGETMessageParameterName @"X-TERMINAL-ID"
#define MessageGETMessageParameterName @"X-MESSAGE"

#define UsernameMessageKeyName @"username"
#define PasswordMessageKeyName @"password"
#define SessionKeyMessageKeyName @"session_key"
#define NewPasswordMessageKeyName @"new_password"
#define EmailMessageKeyName @"email"
#define PINMessageKeyName @"new_pin"
#define CardMessageKeyName @"card"
#define AmountMessageKeyName @"amount"
#define BankTerminalAffiliateMessageKeyName @"bank_terminal_affiliate"
#define LatitudeMessageKeyName @"latitude"
#define LongitudeMessageKeyName @"longitude"
#define TransactionIdMessageKeyName @"transaction_id"
#define SignatureMessageKeyName @"signature_base64"
#define EmailMessageKeyName @"email"
#define BankTerminalAffiliateMessageKeyName @"bank_terminal_affiliate"
#define VoidAsUserMessageKeyName @"void_as_user"
#define VoidAsUserPINMessageKeyName @"void_as_user_pin"
#define StartDateMessageKeyName @"start_date"
#define EndDateMessageKeyName @"end_date"
#define TransactionTypeMessageKeyName @"transaction_type"
#define RefundAsUserMessageKeyName @"refund_as_user"
#define RefundAsUserPINMessageKeyName @"refund_as_user_pin"
#define TaxAmountMessageKeyName @"tax_amount"
#define TipAmountMessageKeyName @"tip_amount"
#define AdjustTipAsUserMessageKeyName @"adjust_tip__as_user"
#define AdjustTipAsUserPINMessageKeyName @"adjust_tip_as_user_pin"

#define ReasonCodeResponseParameterName @"reason_code"
#define ReasonTextResponseParameterName @"reason_text"
#define KeyResponseParameterName @"key"
#define MessageResponseParameterName @"message"
#define SessionKeyResponseParameterName @"session_key"
#define TerminalInfoResponseParameterName @"terminal_info"
#define AffiliatesResponseParameterName @"affiliates"
#define AffiliateResponseParameterName @"affiliate"
#define TransactionsResponseParameterName @"transactions"
#define EncryptedMessageResponseParameterName @"encrypted_message"
#define ResponsenCodeResponseParameterName @"responseCode"


#define ReasonCodeOKCode 0
