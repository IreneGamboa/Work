/*
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  ZimpleServices.m
//  Zimple POS
//

#import "ZimpleServices.h"

#define SuppressPerformSelectorLeakWarning(Stuff) \
do { \
_Pragma("clang diagnostic push") \
_Pragma("clang diagnostic ignored \"-Warc-performSelector-leaks\"") \
Stuff; \
_Pragma("clang diagnostic pop") \
} while (0)

@implementation ZimpleServices

@synthesize zimpleBackendServicesDelegate;

typedef enum {
    PostRequest = 1,
    PutRequest,
    DeleteRequest,
    GetRequest
} RequestTypes;

typedef void (^AFHTTPRequestOperationSuccess)(AFHTTPRequestOperation *operation, id responseObject);
typedef void (^AFHTTPRequestOperationError)(AFHTTPRequestOperation *operation, NSError *error);

- (void)sendRequestToBackend:(RequestTypes)requestType path:(NSString *)path params:(NSDictionary *)params responseSelector:(SEL)responseSelector{
    NSURL *url = [NSURL URLWithString:ZimpleBackendServicesBaseUrl];
    AFHTTPClient *httpClient = [[AFHTTPClient alloc] initWithBaseURL:url];
    
    httpClient.parameterEncoding = AFJSONParameterEncoding;
    
    AFHTTPRequestOperationSuccess requestSuccess = ^(AFHTTPRequestOperation *operation, id responseObject) {
        /*for (id key in operation.request.allHTTPHeaderFields) {
            
            NSLog(@"key: %@, value: %@", key, [operation.request.allHTTPHeaderFields objectForKey:key]);
        }
        
        NSString *body = [[NSString alloc] initWithData:operation.request.HTTPBody encoding:NSUTF8StringEncoding];
        //NSLog(@"Body: %@", body);
        
        NSString *responseStr = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
        NSLog(@"Request Successful, response '%@'", responseStr);*/
        SuppressPerformSelectorLeakWarning([zimpleBackendServicesDelegate performSelector:responseSelector withObject:responseObject withObject:nil]);
    };
    
    AFHTTPRequestOperationError requestError = ^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"[HTTPClient Error]: %@", error.localizedDescription);
        NSLog(@"[HTTPClient Error]: %@", operation.responseString);
        NSLog(@"[HTTPClient Error Code]: %@", [operation error]);
        
        if (operation.responseString != nil){
            
            NSDictionary* json = [NSJSONSerialization JSONObjectWithData:[operation.responseString dataUsingEncoding:NSUTF8StringEncoding] options:NSJSONWritingPrettyPrinted error:nil];
            
            NSString *messageEncryptedData = [json objectForKey:MessageResponseParameterName];
            
            NSString *isEncryptedDataStr = [json objectForKey:EncryptedMessageResponseParameterName];
            BOOL isEncryptedData = [isEncryptedDataStr boolValue];
            NSNumber *reasonCode = nil;
            NSString *completeResponseCode = @"";
            if (isEncryptedData){
                NSString *decryptedJSONString = [EncryptionHelper decryptUsingSymmetricAES256:messageEncryptedData];
                NSLog(@"Decrypted Response: %@", decryptedJSONString);
                
                NSData *decryptedJSONData = [decryptedJSONString dataUsingEncoding:NSUTF8StringEncoding];
                NSDictionary *jsonMessage = [NSJSONSerialization JSONObjectWithData:decryptedJSONData options:NSJSONWritingPrettyPrinted error:nil];
                reasonCode = [jsonMessage objectForKey:ReasonCodeResponseParameterName];
                //NSLog(@"Reason Code: %@", reasonCode);
                completeResponseCode = [NSString stringWithFormat:@"%d", [reasonCode integerValue]];
                
                if ([reasonCode isEqualToNumber:[NSNumber numberWithInt:47]]){
                    // Auhtorizer Error Code, must add the authorizer error
                    NSString *responseCode = [jsonMessage objectForKey:ResponsenCodeResponseParameterName];
                    //NSLog(@"Response Code: %@", responseCode);
                    completeResponseCode = [NSString stringWithFormat:@"%@_%@", completeResponseCode, responseCode];
                }
            }else{
                reasonCode = [json objectForKey:ReasonCodeResponseParameterName];
                completeResponseCode = [NSString stringWithFormat:@"%d", [reasonCode integerValue]];
                //NSLog(@"Reason Code: %@", reasonCode);
            }
            NSMutableDictionary *details = [NSMutableDictionary dictionary];
            [details setValue:completeResponseCode forKey:NSLocalizedDescriptionKey];
            error = [NSError errorWithDomain:@"Zimple" code:[reasonCode integerValue] userInfo:details];
        }else{
            
            NSMutableDictionary *details = [NSMutableDictionary dictionary];
            if (error.code == NSURLErrorNotConnectedToInternet){
                [details setValue:@"NO_INTERNET_CONNECTION" forKey:NSLocalizedDescriptionKey];
                error = [NSError errorWithDomain:@"Zimple" code:998 userInfo:details];
            }else{
            [details setValue:@"998" forKey:NSLocalizedDescriptionKey];
            error = [NSError errorWithDomain:@"Zimple" code:998 userInfo:details];
            }
        }
        SuppressPerformSelectorLeakWarning([zimpleBackendServicesDelegate performSelector:responseSelector withObject:nil withObject:error]);
    };
    
    // Set the User Agent of the request to Zimple User Agent
    [httpClient setDefaultHeader:@"User-Agent" value:ZimpleBackendRequestsUserAgent];
    
    switch (requestType) {
        case PostRequest:
            [httpClient postPath:path parameters:params success:requestSuccess failure:requestError];
            break;
        case PutRequest:
            [httpClient putPath:path parameters:params success:requestSuccess failure:requestError];
            break;
        case DeleteRequest:
            [httpClient deletePath:path parameters:params success:requestSuccess failure:requestError];
            break;
            case GetRequest:
            for (NSString *key in params.keyEnumerator){
                NSString *test =[params objectForKey:key];
                test = [test stringByReplacingOccurrencesOfString:@"ñ" withString:@"%F1"];
                test = [test stringByReplacingOccurrencesOfString:@" " withString:@"%20"];
                //[httpClient setDefaultHeader:key value:[params objectForKey:key]];
                [httpClient setDefaultHeader:key value:test];
            }
            NSLog(@"HttpClient: %@", [httpClient description]);
            [httpClient getPath:path parameters:nil success:requestSuccess failure:requestError];
            break;
        default:
            break;
    }
}

- (void)activateTerminal:(NSString *)terminalId localPublicKey:(NSString *)localPublicKey activationToken:(NSString *)activationToken{
    NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys:
                            terminalId, TerminaIdParameterName,
                            localPublicKey, PublicKeyParameterName,
                            activationToken, ResetTokenKeyParameterName,
                            nil];

    [self sendRequestToBackend:PostRequest path:ActivateTerminalPostPath params:params responseSelector:@selector(terminalActivationResponseReceived:error:)];
}

- (void)getSessionHandshake:(NSString *)terminalId encryptedKeyFirstHalfAndIV:(NSString *)encryptedKeyFirstHalfAndIV{
    NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys:
                            terminalId, TerminaIdParameterName,
                            encryptedKeyFirstHalfAndIV, KeyParameterName,
                            nil];
    
    [self sendRequestToBackend:PostRequest path:SessionHandshakePostPath params:params responseSelector:@selector(sessionHandshakeResponseReceived:error:)];
}

- (void)login:(NSString *)terminalId username:(NSString *)username password:(NSString *)password{
    // Generate the key-values in the JSON Message as a Dictionary
    NSDictionary *messageDictionary = [NSDictionary dictionaryWithObjectsAndKeys:
                            username, UsernameMessageKeyName,
                            password, PasswordMessageKeyName,
                            nil];
    
    // Serialize the dictionary into t JSON formatted NSData
    NSData *messageJSONData = [NSJSONSerialization dataWithJSONObject:messageDictionary options:NSJSONWritingPrettyPrinted error:nil];
    // Convert the JSON formatted NSData into an JSON formatted NSString
    NSString *messageJSONString = [[NSString alloc] initWithData:messageJSONData encoding:NSUTF8StringEncoding];
    
    NSString *encryptedJSONString = [EncryptionHelper encryptUsingSymmetricAES256:messageJSONString];
    //NSLog(@"Encrypted Message: %@", encryptedJSONString);
    
    NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys:
                            terminalId, TerminaIdParameterName,
                            encryptedJSONString, MessageParameterName,
                            nil];
    
    [self sendRequestToBackend:PostRequest path:LoginPostPath params:params responseSelector:@selector(loginResponseReceived:error:)];
}

- (void)logout:(NSString *)terminalId{
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    // Generate the key-values in the JSON Message as a Dictionary
    NSDictionary *messageDictionary = [NSDictionary dictionaryWithObjectsAndKeys:
                                       userInfo.sessionInfo.sessionKey, SessionKeyMessageKeyName,
                                       nil];
    
    // Serialize the dictionary into t JSON formatted NSData
    NSData *messageJSONData = [NSJSONSerialization dataWithJSONObject:messageDictionary options:NSJSONWritingPrettyPrinted error:nil];
    // Convert the JSON formatted NSData into an JSON formatted NSString
    NSString *messageJSONString = [[NSString alloc] initWithData:messageJSONData encoding:NSUTF8StringEncoding];
    
    NSString *encryptedJSONString = [EncryptionHelper encryptUsingSymmetricAES256:messageJSONString];
    //NSLog(@"Encrypted Message: %@", encryptedJSONString);
    
    NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys:
                            terminalId, TerminaIdParameterName,
                            encryptedJSONString, MessageParameterName,
                            nil];

    [self sendRequestToBackend:DeleteRequest path:LogoutDeletePath params:params responseSelector:@selector(logoutResponseReceived:error:)];
}

- (void)changeUserPassword:(NSString *)terminalId password:(NSString *)password newPassword:(NSString *)newPassword{
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    // Generate the key-values in the JSON Message as a Dictionary
    NSDictionary *messageDictionary = [NSDictionary dictionaryWithObjectsAndKeys:
                                       userInfo.sessionInfo.sessionKey, SessionKeyMessageKeyName,
                                       password, PasswordMessageKeyName,
                                       newPassword, NewPasswordMessageKeyName,
                                       nil];
    
    // Serialize the dictionary into t JSON formatted NSData
    NSData *messageJSONData = [NSJSONSerialization dataWithJSONObject:messageDictionary options:NSJSONWritingPrettyPrinted error:nil];
    // Convert the JSON formatted NSData into an JSON formatted NSString
    NSString *messageJSONString = [[NSString alloc] initWithData:messageJSONData encoding:NSUTF8StringEncoding];
    
    NSString *encryptedJSONString = [EncryptionHelper encryptUsingSymmetricAES256:messageJSONString];
    //NSLog(@"Encrypted Message: %@", encryptedJSONString);
    
    NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys:
                            terminalId, TerminaIdParameterName,
                            encryptedJSONString, MessageParameterName,
                            nil];
    
    [self sendRequestToBackend:PutRequest path:ChangeUserPasswordPutPath params:params responseSelector:@selector(changeUserPasswordResponseReceived:error:)];
}

- (void)resetUserPassword:(NSString *)terminalId email:(NSString *)email{
    // Generate the key-values in the JSON Message as a Dictionary
    NSDictionary *messageDictionary = [NSDictionary dictionaryWithObjectsAndKeys:
                                       email, EmailMessageKeyName,
                                       nil];
    
    // Serialize the dictionary into t JSON formatted NSData
    NSData *messageJSONData = [NSJSONSerialization dataWithJSONObject:messageDictionary options:NSJSONWritingPrettyPrinted error:nil];
    // Convert the JSON formatted NSData into an JSON formatted NSString
    NSString *messageJSONString = [[NSString alloc] initWithData:messageJSONData encoding:NSUTF8StringEncoding];
    
    NSString *encryptedJSONString = [EncryptionHelper encryptUsingSymmetricAES256:messageJSONString];
    //NSLog(@"Encrypted Message: %@", encryptedJSONString);
    
    NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys:
                            terminalId, TerminaIdParameterName,
                            encryptedJSONString, MessageParameterName,
                            nil];
    
    [self sendRequestToBackend:PostRequest path:ResetUserPasswordPostPath params:params responseSelector:@selector(resetPasswordResponseReceived:error:)];
}

- (void)changeUserPIN:(NSString *)terminalId password:(NSString *)password pin:(NSString *)pin{
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    // Generate the key-values in the JSON Message as a Dictionary
    NSDictionary *messageDictionary = [NSDictionary dictionaryWithObjectsAndKeys:
                                       userInfo.sessionInfo.sessionKey, SessionKeyMessageKeyName,
                                       password, PasswordMessageKeyName,
                                       pin, PINMessageKeyName,
                                       nil];
    
    // Serialize the dictionary into t JSON formatted NSData
    NSData *messageJSONData = [NSJSONSerialization dataWithJSONObject:messageDictionary options:NSJSONWritingPrettyPrinted error:nil];
    // Convert the JSON formatted NSData into an JSON formatted NSString
    NSString *messageJSONString = [[NSString alloc] initWithData:messageJSONData encoding:NSUTF8StringEncoding];
    
    NSString *encryptedJSONString = [EncryptionHelper encryptUsingSymmetricAES256:messageJSONString];
    //NSLog(@"Encrypted Message: %@", encryptedJSONString);
    
    NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys:
                            terminalId, TerminaIdParameterName,
                            encryptedJSONString, MessageParameterName,
                            nil];

    [self sendRequestToBackend:PutRequest path:ChangeUserPINPutPath params:params responseSelector:@selector(changeUserPINResponseReceived:error:)];
}

- (void)sale:(NSString *)terminalId sessionkey:(NSString *)sessionKey cardPayload:(NSString *)cardPayload saleAmount:(NSString *)saleAmount affiliatedId:(NSString *)affiliateId latitude:(NSString *)latitude longitude:(NSString *)longitude taxAmount:(NSString *)taxAmount tipAmount:(NSString *)tipAmount{
    // Generate the key-values in the JSON Message as a Dictionary
    NSMutableDictionary *messageDictionary = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                       sessionKey, SessionKeyMessageKeyName,
                                       cardPayload, CardMessageKeyName,
                                       saleAmount, AmountMessageKeyName,
                                       affiliateId, BankTerminalAffiliateMessageKeyName,
                                       taxAmount, TaxAmountMessageKeyName,
                                       tipAmount, TipAmountMessageKeyName,
                                       nil];
    
    if (![latitude isEqualToString:@""]){
        [messageDictionary setObject:latitude forKey:LatitudeMessageKeyName];
    }
    if (![longitude isEqualToString:@""]){
        [messageDictionary setObject:longitude forKey:LongitudeMessageKeyName];
    }
    
    // Serialize the dictionary into t JSON formatted NSData
    NSData *messageJSONData = [NSJSONSerialization dataWithJSONObject:messageDictionary options:NSJSONWritingPrettyPrinted error:nil];
    // Convert the JSON formatted NSData into an JSON formatted NSString
    NSString *messageJSONString = [[NSString alloc] initWithData:messageJSONData encoding:NSUTF8StringEncoding];

    NSString *encryptedJSONString = [EncryptionHelper encryptUsingSymmetricAES256:messageJSONString];
    //NSLog(@"Encrypted Message: %@", encryptedJSONString);
    
    NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys:
                            terminalId, TerminaIdParameterName,
                            encryptedJSONString, MessageParameterName,
                            nil];

    [self sendRequestToBackend:PostRequest path:SalePostPath params:params responseSelector:@selector(saleResponseReceived:error:)];
}

- (void)ack:(NSString *)terminalId sessionkey:(NSString *)sessionKey transactionId:(NSString *)transactionId{
    // Generate the key-values in the JSON Message as a Dictionary
    NSDictionary *messageDictionary = [NSDictionary dictionaryWithObjectsAndKeys:
                                       sessionKey, SessionKeyMessageKeyName,
                                       transactionId, TransactionIdMessageKeyName,
                                       nil];
    
    // Serialize the dictionary into t JSON formatted NSData
    NSData *messageJSONData = [NSJSONSerialization dataWithJSONObject:messageDictionary options:NSJSONWritingPrettyPrinted error:nil];
    // Convert the JSON formatted NSData into an JSON formatted NSString
    NSString *messageJSONString = [[NSString alloc] initWithData:messageJSONData encoding:NSUTF8StringEncoding];
    
    NSString *encryptedJSONString = [EncryptionHelper encryptUsingSymmetricAES256:messageJSONString];
    //NSLog(@"Encrypted Message: %@", encryptedJSONString);
    
    NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys:
                            terminalId, TerminaIdParameterName,
                            encryptedJSONString, MessageParameterName,
                            nil];

    [self sendRequestToBackend:PostRequest path:SaleACKPostPath params:params responseSelector:@selector(ackResponseReceived:error:)];
}

- (void)registerSignature:(NSString *)terminalId sessionkey:(NSString *)sessionKey transactionId:(NSString *)transactionId signatureBase64:(NSString *)signatureBase64{
    // Generate the key-values in the JSON Message as a Dictionary
    NSDictionary *messageDictionary = [NSDictionary dictionaryWithObjectsAndKeys:
                                       sessionKey, SessionKeyMessageKeyName,
                                       transactionId, TransactionIdMessageKeyName,
                                       signatureBase64, SignatureMessageKeyName,
                                       nil];
    
    // Serialize the dictionary into t JSON formatted NSData
    NSData *messageJSONData = [NSJSONSerialization dataWithJSONObject:messageDictionary options:NSJSONWritingPrettyPrinted error:nil];
    // Convert the JSON formatted NSData into an JSON formatted NSString
    NSString *messageJSONString = [[NSString alloc] initWithData:messageJSONData encoding:NSUTF8StringEncoding];
    
    NSString *encryptedJSONString = [EncryptionHelper encryptUsingSymmetricAES256:messageJSONString];
    //NSLog(@"Encrypted Message: %@", encryptedJSONString);
    
    NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys:
                            terminalId, TerminaIdParameterName,
                            encryptedJSONString, MessageParameterName,
                            nil];
    
    [self sendRequestToBackend:PostRequest path:RegisterSignaturePostPath params:params responseSelector:@selector(registerSignatureResponseReceived:error:)];
}

- (void)sendEmailReceipt:(NSString *)terminalId sessionkey:(NSString *)sessionKey transactionId:(NSString *)transactionId email:(NSString *)email{
    // Generate the key-values in the JSON Message as a Dictionary
    NSDictionary *messageDictionary = [NSDictionary dictionaryWithObjectsAndKeys:
                                       sessionKey, SessionKeyMessageKeyName,
                                       transactionId, TransactionIdMessageKeyName,
                                       email, EmailMessageKeyName,
                                       nil];
    
    // Serialize the dictionary into t JSON formatted NSData
    NSData *messageJSONData = [NSJSONSerialization dataWithJSONObject:messageDictionary options:NSJSONWritingPrettyPrinted error:nil];
    // Convert the JSON formatted NSData into an JSON formatted NSString
    NSString *messageJSONString = [[NSString alloc] initWithData:messageJSONData encoding:NSUTF8StringEncoding];
    
    NSString *encryptedJSONString = [EncryptionHelper encryptUsingSymmetricAES256:messageJSONString];
    //NSLog(@"Encrypted Message: %@", encryptedJSONString);
    
    NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys:
                            terminalId, TerminaIdParameterName,
                            encryptedJSONString, MessageParameterName,
                            nil];
    
    [self sendRequestToBackend:PostRequest path:SendEmailReceiptPostPath params:params responseSelector:@selector(sendEmailReceiptResponseReceived:error:)];
}

- (void)terminalSettlement:(NSString *)terminalId sessionkey:(NSString *)sessionKey bankTerminalAffiliate:(NSString *)bankTerminalAffiliate{
    // Generate the key-values in the JSON Message as a Dictionary
    NSDictionary *messageDictionary = [NSDictionary dictionaryWithObjectsAndKeys:
                                       sessionKey, SessionKeyMessageKeyName,
                                       bankTerminalAffiliate, BankTerminalAffiliateMessageKeyName,
                                       nil];
    
    // Serialize the dictionary into t JSON formatted NSData
    NSData *messageJSONData = [NSJSONSerialization dataWithJSONObject:messageDictionary options:NSJSONWritingPrettyPrinted error:nil];
    // Convert the JSON formatted NSData into an JSON formatted NSString
    NSString *messageJSONString = [[NSString alloc] initWithData:messageJSONData encoding:NSUTF8StringEncoding];
    
    NSString *encryptedJSONString = [EncryptionHelper encryptUsingSymmetricAES256:messageJSONString];
    //NSLog(@"Encrypted Message: %@", encryptedJSONString);
    
    NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys:
                            terminalId, TerminaIdParameterName,
                            encryptedJSONString, MessageParameterName,
                            nil];
    
    [self sendRequestToBackend:PostRequest path:TerminalSettlementPostPath params:params responseSelector:@selector(terminalSettlementResponseReceived:error:)];
}

- (void)voidableTransactionsList:(NSString *)terminalId sessionkey:(NSString *)sessionKey{
    // Generate the key-values in the JSON Message as a Dictionary
    NSDictionary *messageDictionary = [NSDictionary dictionaryWithObjectsAndKeys:
                                       sessionKey, SessionKeyMessageKeyName,
                                       nil];
    
    // Serialize the dictionary into t JSON formatted NSData
    NSData *messageJSONData = [NSJSONSerialization dataWithJSONObject:messageDictionary options:NSJSONWritingPrettyPrinted error:nil];
    // Convert the JSON formatted NSData into an JSON formatted NSString
    NSString *messageJSONString = [[NSString alloc] initWithData:messageJSONData encoding:NSUTF8StringEncoding];
    
    NSString *encryptedJSONString = [EncryptionHelper encryptUsingSymmetricAES256:messageJSONString];
    //NSLog(@"Encrypted Message: %@", encryptedJSONString);
    
    NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys:
                            terminalId, TerminalIdGETMessageParameterName,
                            encryptedJSONString, MessageGETMessageParameterName,
                            @"application/x-www-form-urlencoded; charset=utf-8", @"Content-Type",
                            nil];
    
    [self sendRequestToBackend:GetRequest path:VoidableTransactionsListGetPath params:params responseSelector:@selector(voidableTransactionsListResponseReceived:error:)];
}

- (void)voidTransaction:(NSString *)terminalId sessionkey:(NSString *)sessionKey transactionId:(NSString *)transactionId latitude:(NSString *)latitude longitude:(NSString *)longitude voidAsUser:(NSString *)voidAsUser voidAsUserPIN:(NSString *)voidAsUserPIN{
    // Generate the key-values in the JSON Message as a Dictionary
    NSMutableDictionary *messageDictionary = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                       sessionKey, SessionKeyMessageKeyName,
                                       transactionId, TransactionIdMessageKeyName,
                                       nil];
    
    if (voidAsUser != nil && voidAsUserPIN != nil && ![voidAsUser isEqualToString:@""] && ![voidAsUserPIN isEqualToString:@""]){
        [messageDictionary setObject:voidAsUser forKey:VoidAsUserMessageKeyName];
        [messageDictionary setObject:voidAsUserPIN forKey:VoidAsUserPINMessageKeyName];
    }
    
    if (![latitude isEqualToString:@""]){
        [messageDictionary setObject:latitude forKey:LatitudeMessageKeyName];
    }
    if (![longitude isEqualToString:@""]){
        [messageDictionary setObject:longitude forKey:LongitudeMessageKeyName];
    }
    
    // Serialize the dictionary into t JSON formatted NSData
    NSData *messageJSONData = [NSJSONSerialization dataWithJSONObject:messageDictionary options:NSJSONWritingPrettyPrinted error:nil];
    // Convert the JSON formatted NSData into an JSON formatted NSString
    NSString *messageJSONString = [[NSString alloc] initWithData:messageJSONData encoding:NSUTF8StringEncoding];
    
    NSString *encryptedJSONString = [EncryptionHelper encryptUsingSymmetricAES256:messageJSONString];
    //NSLog(@"Encrypted Message: %@", encryptedJSONString);
    
    NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys:
                            terminalId, TerminaIdParameterName,
                            encryptedJSONString, MessageParameterName,
                            nil];
    
    [self sendRequestToBackend:PostRequest path:VoidTransactionPostPath params:params responseSelector:@selector(voidTransactionResponseReceived:error:)];
}

- (void)transactionsList:(NSString *)terminalId sessionkey:(NSString *)sessionKey startDate:(NSString *)startDate endDate:(NSString *)endDate transactionType:(NSString *)transactionType{
    // Generate the key-values in the JSON Message as a Dictionary
    NSMutableDictionary *messageDictionary = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                       sessionKey, SessionKeyMessageKeyName,
                                       nil];
     
    if (![startDate isEqualToString:@""]){
        [messageDictionary setObject:startDate forKey:StartDateMessageKeyName];
    }
    if (![endDate isEqualToString:@""]){
        [messageDictionary setObject:endDate forKey:EndDateMessageKeyName];
    }
    if (![transactionType isEqualToString:@""]){
        [messageDictionary setObject:transactionType forKey:TransactionTypeMessageKeyName];
    }
    
    // Serialize the dictionary into t JSON formatted NSData
    NSData *messageJSONData = [NSJSONSerialization dataWithJSONObject:messageDictionary options:NSJSONWritingPrettyPrinted error:nil];
    // Convert the JSON formatted NSData into an JSON formatted NSString
    NSString *messageJSONString = [[NSString alloc] initWithData:messageJSONData encoding:NSUTF8StringEncoding];
    //NSLog(@"%@", messageJSONString);
    
    NSString *encryptedJSONString = [EncryptionHelper encryptUsingSymmetricAES256:messageJSONString];
    NSLog(@"Encrypted Message: %@", encryptedJSONString);
    encryptedJSONString = [[encryptedJSONString componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]] componentsJoinedByString:@""];
    //NSLog(@"Encrypted Message No Line Returns: %@", encryptedJSONString);
    
    NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys:
                            terminalId, TerminalIdGETMessageParameterName,
                            encryptedJSONString, MessageGETMessageParameterName,
                            nil];
    
    [self sendRequestToBackend:GetRequest path:TransactionsListGetPath params:params responseSelector:@selector(transactionsListResponseReceived:error:)];
}

- (void)refund:(NSString *)terminalId sessionkey:(NSString *)sessionKey cardPayload:(NSString *)cardPayload refundAmount:(NSString *)refundAmount affiliatedId:(NSString *)affiliateId latitude:(NSString *)latitude longitude:(NSString *)longitude refundAsUser:(NSString *)refundAsUser refundAsUserPIN:(NSString *)refundAsUserPIN{
    // Generate the key-values in the JSON Message as a Dictionary
    NSMutableDictionary *messageDictionary = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                              sessionKey, SessionKeyMessageKeyName,
                                              cardPayload, CardMessageKeyName,
                                              refundAmount, AmountMessageKeyName,
                                              affiliateId, BankTerminalAffiliateMessageKeyName,
                                              nil];
    
    if (![latitude isEqualToString:@""]){
        [messageDictionary setObject:latitude forKey:LatitudeMessageKeyName];
    }
    if (![longitude isEqualToString:@""]){
        [messageDictionary setObject:longitude forKey:LongitudeMessageKeyName];
    }
    
    if (refundAsUser != nil && refundAsUserPIN != nil && ![refundAsUser isEqualToString:@""] && ![refundAsUserPIN isEqualToString:@""]){
        [messageDictionary setObject:refundAsUser forKey:RefundAsUserMessageKeyName];
        [messageDictionary setObject:refundAsUserPIN forKey:RefundAsUserPINMessageKeyName];
    }
    
    // Serialize the dictionary into t JSON formatted NSData
    NSData *messageJSONData = [NSJSONSerialization dataWithJSONObject:messageDictionary options:NSJSONWritingPrettyPrinted error:nil];
    // Convert the JSON formatted NSData into an JSON formatted NSString
    NSString *messageJSONString = [[NSString alloc] initWithData:messageJSONData encoding:NSUTF8StringEncoding];
    
    NSString *encryptedJSONString = [EncryptionHelper encryptUsingSymmetricAES256:messageJSONString];
    //NSLog(@"Encrypted Message: %@", encryptedJSONString);
    
    NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys:
                            terminalId, TerminaIdParameterName,
                            encryptedJSONString, MessageParameterName,
                            nil];
    
    [self sendRequestToBackend:PostRequest path:RefundPostPath params:params responseSelector:@selector(refundResponseReceived:error:)];
}

- (void)adjustTransactionTip:(NSString *)terminalId sessionkey:(NSString *)sessionKey transactionId:(NSString *)transactionId latitude:(NSString *)latitude longitude:(NSString *)longitude adjustTipAsUser:(NSString *)adjustTipAsUser adjustTipAsUserPIN:(NSString *)adjustTipAsUserPIN tipAmount:(NSString *)tipAmount affiliate:(NSString *)affiliateId{
    // Generate the key-values in the JSON Message as a Dictionary
    NSMutableDictionary *messageDictionary = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                              sessionKey, SessionKeyMessageKeyName,
                                              affiliateId, BankTerminalAffiliateMessageKeyName,
                                              transactionId, TransactionIdMessageKeyName,
                                              tipAmount, TipAmountMessageKeyName,
                                              nil];
    
    if (adjustTipAsUser != nil && adjustTipAsUserPIN != nil && ![adjustTipAsUser isEqualToString:@""] && ![adjustTipAsUserPIN isEqualToString:@""]){
        [messageDictionary setObject:adjustTipAsUser forKey:AdjustTipAsUserMessageKeyName];
        [messageDictionary setObject:adjustTipAsUserPIN forKey:AdjustTipAsUserPINMessageKeyName];
    }
    
    if (![latitude isEqualToString:@""]){
        [messageDictionary setObject:latitude forKey:LatitudeMessageKeyName];
    }
    if (![longitude isEqualToString:@""]){
        [messageDictionary setObject:longitude forKey:LongitudeMessageKeyName];
    }
    
    // Serialize the dictionary into t JSON formatted NSData
    NSData *messageJSONData = [NSJSONSerialization dataWithJSONObject:messageDictionary options:NSJSONWritingPrettyPrinted error:nil];
    // Convert the JSON formatted NSData into an JSON formatted NSString
    NSString *messageJSONString = [[NSString alloc] initWithData:messageJSONData encoding:NSUTF8StringEncoding];
    
    NSString *encryptedJSONString = [EncryptionHelper encryptUsingSymmetricAES256:messageJSONString];
    //NSLog(@"Encrypted Message: %@", encryptedJSONString);
    
    NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys:
                            terminalId, TerminaIdParameterName,
                            encryptedJSONString, MessageParameterName,
                            nil];
    
    [self sendRequestToBackend:PostRequest path:TipAdjustementPostPath params:params responseSelector:@selector(tipAdjustementResponseReceived:error:)];
}

@end
