/*
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  SignatureViewController.m
//  Zimple POS
//

#import "SignatureViewController.h"

#define ErrorAlertViewTag 100

@interface SignatureViewController ()

@end

@implementation SignatureViewController

@synthesize signatureView;
@synthesize signaturePadBackgroundImageView;
@synthesize commerceNameLabel;
@synthesize amountLabel;
@synthesize referenceNumberLabel;
@synthesize signatureNameLabel;
@synthesize tiledButtonLightBlueBackgroundImageView;
@synthesize tiledButtonDarkBlueBackgroundImageView;
@synthesize hasSignature;
@synthesize transactionResult;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    hasSignature = NO;
    signatureView.delegate = self;
    
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    TransactionInfo *transactionInfo = userInfo.sessionInfo.currentTransactionInfo;
    
    // The Commerce Name is the name for the branch of the terminal (not the affiliate)
    commerceNameLabel.text = userInfo.terminalInfo.terminal.branch.name;
    referenceNumberLabel.text = [NSString stringWithFormat:@"Referencia: %@", transactionInfo.transactionResult.referenceNumber];
    
    signatureNameLabel.text = transactionInfo.creditCardInfo.cardHolderName;
    signatureNameLabel.textColor = [UIColorList credomaticGrayColor];
    
    NSString *totalAmountStr = [NSString stringWithFormat:@"%@ %@", transactionInfo.amountWithFormat, transactionInfo.affiliate.currencyCode];
    if ([transactionInfo isKindOfClass:[SaleTransactionInfo class]]){
        SaleTransactionInfo *saleTransactionInfo = (SaleTransactionInfo *)transactionInfo;
        //totalAmountStr = [NSString stringWithFormat:@"%.02f %@", saleTransactionInfo.saleTotalAmount, transactionInfo.affiliate.currencyCode];
        totalAmountStr = [NSString stringWithFormat:@"%@ %@", saleTransactionInfo.saleTotalAmountWithFormat, transactionInfo.affiliate.currencyCode];
    }
    NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc] initWithAttributedString:amountLabel.attributedText];
    [attributedText replaceCharactersInRange:NSMakeRange(0, attributedText.mutableString.length) withString:totalAmountStr];
    //const NSRange range = NSMakeRange(totalAmountStr.length-3, 3);
    NSRange range = [totalAmountStr rangeOfString:transactionInfo.affiliate.currencyCode];
    [attributedText addAttribute:NSFontAttributeName value:[UIFont fontWithName:amountLabel.font.fontName size:20] range:range];
    amountLabel.attributedText = attributedText;
    
    if (IS_IPHONE_5){
        // Change the images to fit the landscape iPhone 5 widescreen screen.
        signaturePadBackgroundImageView.image = [UIImage imageNamed:@"Signature_Pad_Background_Widescreen"];
        tiledButtonDarkBlueBackgroundImageView.image = [UIImage imageNamed:@"Tiled_Button_Blue_Background_Top_Landscape_Widescreen"];
        tiledButtonLightBlueBackgroundImageView.image = [UIImage imageNamed:@"Tiled_Button_Blue_Background_Landscape_Widescreen"];
        self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"Gray_Background_Landscape_Widescreen"]];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// Override the Portrait Orientation default in BaseViewController and make this controller only Landscape Right
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationLandscapeRight);
}

- (NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskLandscapeRight;
}

- (IBAction)saveSignatureButtonTouchUpInside:(id)sender {
    UIImage *signatureImage = signatureView.image;
    NSData *imageData = UIImagePNGRepresentation(signatureImage);
    NSString *signatureImageAs64String =  [imageData base64EncodedString];
    self.HUD.labelText = @"Registrando Firma";
    [self.HUD show:YES];
    SalesManager *salesManager = [[SalesManager alloc] init];
    salesManager.salesManagerDelegate = self;
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    [salesManager registerSignatureAndFinishTransaction:userInfo.sessionInfo.currentTransactionInfo.transactionResult signature:signatureImageAs64String];
}

- (void)viewDidUnload {
    [self setAmountLabel:nil];
    [self setCommerceNameLabel:nil];
    [self setReferenceNumberLabel:nil];
    [self setSignatureNameLabel:nil];
    [self setSignaturePadBackgroundImageView:nil];
    [self setTiledButtonLightBlueBackgroundImageView:nil];
    [self setTiledButtonDarkBlueBackgroundImageView:nil];
    [super viewDidUnload];
}

- (void)checkParameters{
    BOOL correctParameters = TRUE;
    
    if (!hasSignature){
        correctParameters = FALSE;
    }
}

#pragma mark NISignatureViewQuartzQuadraticDelegate Methods

-(void)strokeRecorded{
    hasSignature = YES;
    [self checkParameters];
}

- (void)drawingErased{
    hasSignature = NO;
    [self checkParameters];
}

#pragma mark SalesManagerDelegate Methods

- (void)registerSignatureResponseReceived:(BOOL)registerSignatureResult error:(NSError *)error{
    [self.HUD hide:YES];
    NSLog(@"RegisterSignatureResult: %d", registerSignatureResult);
    
    if (registerSignatureResult){
        //[self performSegueWithIdentifier:@"SignatureToRecipeSegue" sender:self];
        UIViewController *controller = [[UIViewController alloc] init];
        [self.navigationController pushViewController:controller animated:NO];
    }else{
        if (![super checkSessionExpiration:error]){
            UIAlertView *errorAlertView = [[UIAlertView alloc] initWithTitle:@"Registrar Firma" message:error.localizedDescription delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
            errorAlertView.delegate = self;
            errorAlertView.tag = ErrorAlertViewTag;
            [errorAlertView show];
        }
    }
}

@end
