/*
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  SaleConfirmationViewController.m
//  Zimple POS
//

#import "SaleConfirmationViewController.h"

#define NeedsTaxAndTipAlertView 98
#define AdminUserAlertView 99
#define ErrorAlertViewTag 100

#define PINLength 4

#define CreditCardInfoSectionNumber 0
#define CreditCardNumberRowNumber 0
#define CreditCardOwnerRowNumber 1

#define AmountSectionNumber 1
#define SubtotalRowNumber 0

#define TotalAmountSectionNumber 2
#define TotalAmountRowNumber 0

#define TaxAmountTextFieldTag 1000
#define TipAmountTextFieldTag 1001

@interface SaleConfirmationViewController ()

@property(nonatomic, retain) NSNumber *taxesRowNumber;
@property(nonatomic, retain) NSNumber *tipRowNumber;

@property(nonatomic) float tableViewToTiledButtonVerticalSpaceDefaultValue;

@property(nonatomic, retain) ZimpleTextField *mixedTipAmountTextField;
@property(nonatomic, retain) ZimpleSegmentedButton *mixedTipPercentageSegmentedControl;

@end

@implementation SaleConfirmationViewController

@synthesize titleLabel;
@synthesize saleConfirmationValueTableView;
@synthesize makeSaleButton;
@synthesize titleConfirmationTableViewVerticalSpace;
@synthesize makeSaleLabel;
@synthesize taxesRowNumber;
@synthesize tipRowNumber;
@synthesize tableViewToTiledButtonVerticalSpace;
@synthesize tableViewToTiledButtonVerticalSpaceDefaultValue;
@synthesize mixedTipAmountTextField;
@synthesize mixedTipPercentageSegmentedControl;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    [self registerForKeyboardNotifications];
    
    titleLabel.textColor = [UIColorList credomaticBlueColor];
    saleConfirmationValueTableView.backgroundColor = [UIColor clearColor];
    
    makeSaleButton.contentVerticalAlignment = UIControlContentVerticalAlignmentBottom;
    makeSaleButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    TransactionInfo *transactionInfo = userInfo.sessionInfo.currentTransactionInfo;
    if ([transactionInfo isKindOfClass:[SaleTransactionInfo class]]){
        titleLabel.text = @"Confirmar la Compra";
        makeSaleLabel.text = @"Realizar Venta";
    }else if ([transactionInfo isKindOfClass:[RefundTransactionInfo class]]){
        titleLabel.text = @"Confirmar la Devolución";
        makeSaleLabel.text = @"Realizar Devolución";
    }
    
    if (IS_IPHONE_5){
        // Since the iPhone 5 is a tall device, leave more space between the title and the tableview
        titleConfirmationTableViewVerticalSpace.constant = 40;
    }
    
    tableViewToTiledButtonVerticalSpaceDefaultValue = tableViewToTiledButtonVerticalSpace.constant;
    
    // Set the mixed tip controls to nil until the app checks the tip type.
    mixedTipAmountTextField = nil;
    mixedTipPercentageSegmentedControl = nil;
    
    self.tipRowNumber = 0;
    self.taxesRowNumber = 0;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskPortrait;
}

- (BOOL)transactionNeedsSignature{
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    TransactionInfo *transactionInfo = userInfo.sessionInfo.currentTransactionInfo;
    if ([AmountFormatter convertAmountToDouble:transactionInfo.amount] >= transactionInfo.affiliate.signatureAmountLimit){
        return YES;
    }
    return NO;
}

- (IBAction)makeSaleButtonTouchUpInside:(id)sender {
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    SalesManager *salesManager = [[SalesManager alloc] init];
    salesManager.salesManagerDelegate = self;
    TransactionInfo *transactionInfo = userInfo.sessionInfo.currentTransactionInfo;
    if ([transactionInfo isKindOfClass:[SaleTransactionInfo class]]){
        SaleTransactionInfo *saleTransactionInfo = (SaleTransactionInfo *)transactionInfo;
        
        NSString *hasTaxesStr = @"";
        NSString *hasTipsStr = @"";
        if ([userInfo.terminalInfo.merchant.useTax boolValue]){
            if (saleTransactionInfo.taxValue == nil || [saleTransactionInfo.taxValue isEqualToString:@""]){
                hasTaxesStr = @"NO";
            }
        }
        if ([userInfo.terminalInfo.merchant.useTip boolValue]){
            if (saleTransactionInfo.tipValue == nil || [saleTransactionInfo.tipValue isEqualToString:@""]){
                hasTipsStr = @"NO";
            }
        }
        
        if([hasTaxesStr isEqualToString:@""] && [hasTipsStr isEqualToString:@""]){
            self.HUD.labelText = @"Autorizando Transacción";
            [self.HUD show:YES];

            if ([self transactionNeedsSignature]){
                [salesManager makeSale:transactionInfo.creditCardInfo.creditCardEncryptedPayload amount:[AmountFormatter formatDoubleAmountAsStringForBackend:saleTransactionInfo.saleTotalAmount] affiliate:transactionInfo.affiliate location:userInfo.userLocation.coordinate taxAmount:[AmountFormatter formatDoubleAmountAsStringForBackend:saleTransactionInfo.taxAmount] tipAmount:[AmountFormatter formatDoubleAmountAsStringForBackend:saleTransactionInfo.tipAmount]];
            }else{
                [salesManager makeAndFinishSale:transactionInfo.creditCardInfo.creditCardEncryptedPayload amount:[AmountFormatter formatDoubleAmountAsStringForBackend:saleTransactionInfo.saleTotalAmount] affiliate:transactionInfo.affiliate location:userInfo.userLocation.coordinate taxAmount:[AmountFormatter formatDoubleAmountAsStringForBackend:saleTransactionInfo.taxAmount] tipAmount:[AmountFormatter formatDoubleAmountAsStringForBackend:saleTransactionInfo.tipAmount]];
            }
        }else{
            NSString *alertMessage = @"";
            if (![hasTaxesStr isEqualToString:@""] && [hasTipsStr isEqualToString:@""]){
                alertMessage = @"Debe ingresar un valor para el impuesto.";
            }else if (![hasTipsStr isEqualToString:@""] && [hasTaxesStr isEqualToString:@""]){
                alertMessage = @"Debe ingresar un valor para la propina.";
            }else{
                alertMessage = @"Debe ingresar un valor para los impuestos y propinas.";
            }
            UIAlertView *needsTipsAndTaxes = [[UIAlertView alloc] initWithTitle:@"" message:alertMessage delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
            needsTipsAndTaxes.tag = NeedsTaxAndTipAlertView;
            [needsTipsAndTaxes show];
        }
    }else if ([transactionInfo isKindOfClass:[RefundTransactionInfo class]]){
        
        if (userInfo.terminalInfo.userCanRefundMoney){
            // User has the permissions to make the Refund, process it.
            self.HUD.labelText = @"Realizando Devolución";
            [self.HUD show:YES];
            // Refund transactions always needs signature, so the refund operation cannot be finished here.
            //[salesManager makeRefund:transactionInfo.creditCardInfo.creditCardEncryptedPayload amount:transactionInfo.amount affiliate:transactionInfo.affiliate location:userInfo.userLocation.coordinate];
            double refundAmountAsDouble = [AmountFormatter convertAmountToDouble:transactionInfo.amount];
            [salesManager makeRefund:transactionInfo.creditCardInfo.creditCardEncryptedPayload amount:[AmountFormatter formatDoubleAmountAsStringForBackend:refundAmountAsDouble] affiliate:transactionInfo.affiliate location:userInfo.userLocation.coordinate];
        }else{
            // Show an alert for the user to input the user and pin of someone who can make the refund.
            UIAlertView *adminUserAlertView = [[UIAlertView alloc] initWithTitle:@"Usuario Administrador" message:@"Credenciales de Administrador:" delegate:self cancelButtonTitle:@"Cancelar" otherButtonTitles:@"Ok", nil];
            adminUserAlertView.tag = AdminUserAlertView;
            adminUserAlertView.alertViewStyle = UIAlertViewStyleLoginAndPasswordInput;
            UITextField *userNameTextField = [adminUserAlertView textFieldAtIndex:0];
            userNameTextField.placeholder = @"Nombre de Usuario";
            userNameTextField.textAlignment = NSTextAlignmentCenter;
            userNameTextField.keyboardType = UIKeyboardTypeEmailAddress;
            UITextField *pinTextField = [adminUserAlertView textFieldAtIndex:1];
            pinTextField.placeholder = @"Pin de Devolución";
            pinTextField.textAlignment = NSTextAlignmentCenter;
            pinTextField.keyboardType = UIKeyboardTypeNumberPad;
            [adminUserAlertView show];
        }
    }
}

- (void)presentSignatureNavController:(TransactionResult *)transactionResult{
    SignatureViewController* signatureViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"SignatureViewController"];
    signatureViewController.title = self.title; // to give the correct Back button title
    UINavigationController* nav = [[UINavigationController alloc] initWithRootViewController:signatureViewController];
    //SignatureViewController* signatureViewController2 = [self.storyboard instantiateViewControllerWithIdentifier:@"SignatureViewController"];
    //[nav pushViewController:signatureViewController2 animated:NO];
    
    //signatureViewController.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"NavigationBackButtonText", "") style:UIBarButtonItemStylePlain target:nil action:nil];
    //signatureViewController2.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"NavigationBackButtonText", "") style:UIBarButtonItemStylePlain target:nil action:nil];
    
    //signatureViewController2.transactionResult = transactionResult;
    signatureViewController.transactionResult = transactionResult;
    
    //[self presentModalViewController:nav animated:YES];
    [self presentViewController:nav animated:YES completion:nil];
    nav.delegate = self; // so that we know when the user navigates back
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([segue.identifier isEqualToString:@"ConfirmationToRecipeSegue"]){
        RecipeViewController *recipeViewController = segue.destinationViewController;
        UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
        TransactionInfo *transactionInfo = userInfo.sessionInfo.currentTransactionInfo;
        if ([transactionInfo isKindOfClass:[SaleTransactionInfo class]]){
            recipeViewController.transactionTypeId = SaleTransactionTypeId;
        }else if ([transactionInfo isKindOfClass:[RefundTransactionInfo class]]){
            recipeViewController.transactionTypeId = RefundTransactionTypeId;
        }
    }
}

- (void)tipSegmentedButtonValueChanged:(id)sender{
    UISegmentedControl *segmentedControl = (UISegmentedControl *)sender;
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    SaleTransactionInfo * transactionInfo = (SaleTransactionInfo *)userInfo.sessionInfo.currentTransactionInfo;
    int merchantTipType = userInfo.terminalInfo.merchant.merchantTipType;
    int percentageTipType = PercentageTipType;
    if (merchantTipType == percentageTipType){
        // When the tip is Percentage, the tip value is sent to the backend as the percentage amount
        transactionInfo.tipValue = [userInfo.terminalInfo.merchant.merchantTipPercentageValues objectAtIndex:segmentedControl.selectedSegmentIndex];
    }else{
        // When the tip is Amount or Mixed, the tip value is sent to the backend as the amount in the affiliate currency.
        float tipPercentage = [[userInfo.terminalInfo.merchant.merchantTipPercentageValues objectAtIndex:segmentedControl.selectedSegmentIndex] floatValue];
        //float amountAsFloat = [[transactionInfo amountAsNumber] floatValue];
        double amountAsDouble = [AmountFormatter convertAmountToDouble:transactionInfo.amount];
        transactionInfo.tipValue = [NSString stringWithFormat:@"%f", (amountAsDouble * tipPercentage) / 100];
    }
    
    if (mixedTipAmountTextField != nil){
        mixedTipAmountTextField.text = @"0";
    }
    
    if (mixedTipPercentageSegmentedControl.selectedSegmentIndex >= 0){
        [mixedTipPercentageSegmentedControl hasCorrectValues:YES];
        [mixedTipAmountTextField hasCorrectValues:YES];
    }
    
    NSIndexPath *totalAmountIndexPath = [NSIndexPath indexPathForItem:TotalAmountRowNumber inSection:TotalAmountSectionNumber];
    [self.saleConfirmationValueTableView reloadRowsAtIndexPaths:@[totalAmountIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
}

- (void)registerForKeyboardNotifications
{
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShow:)
                                                 name:UIKeyboardWillShowNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillBeHidden:)
                                                 name:UIKeyboardWillHideNotification object:nil];
    
}

// Called when the UIKeyboardWillShowNotification is sent.
- (void)keyboardWillShow:(NSNotification*)aNotification
{
    NSDictionary* info = [aNotification userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    
    self.saleConfirmationValueTableView.scrollEnabled = YES;
    
    tableViewToTiledButtonVerticalSpace.constant = kbSize.height - makeSaleButton.frame.size.height;
}

// Called when the UIKeyboardWillHideNotification is sent
- (void)keyboardWillBeHidden:(NSNotification*)aNotification
{
    tableViewToTiledButtonVerticalSpace.constant = tableViewToTiledButtonVerticalSpaceDefaultValue;
}


#pragma mark UITableViewDataSource Methods

-(int)numberOfSectionsInTableView:(UITableView *)tableView{
    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    int numberOfCells = 1;
    if (section == CreditCardInfoSectionNumber){
        numberOfCells = 2;
    }else if (section == AmountSectionNumber){
        UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
        TransactionInfo *transactionInfo = userInfo.sessionInfo.currentTransactionInfo;
        if ([transactionInfo isKindOfClass:[SaleTransactionInfo class]]){
            self.taxesRowNumber = [NSNumber numberWithInt:100]; // Set the taxesRowNumber to a default (100 for example)
            self.tipRowNumber = [NSNumber numberWithInt:100]; // Set the tipsRowNumber to a default (100 for example)
            if ([userInfo.terminalInfo.merchant.useTax boolValue]){
                self.taxesRowNumber = [NSNumber numberWithInt:1];
                ++numberOfCells;
            }
            if ([userInfo.terminalInfo.merchant.useTip boolValue]){
                ++numberOfCells;
                if ([userInfo.terminalInfo.merchant.useTax boolValue]){
                    self.tipRowNumber = [NSNumber numberWithInt:2];
                }else{
                    self.tipRowNumber = [NSNumber numberWithInt:1];
                }
            }
        }else if ([transactionInfo isKindOfClass:[RefundTransactionInfo class]]){
            numberOfCells = 1;
        }
    }else if (section == TotalAmountSectionNumber){
        numberOfCells = 1;
    }
    return numberOfCells;
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    TransactionInfo *transactionInfo = userInfo.sessionInfo.currentTransactionInfo;
    
    // Configure the cell.

    if (indexPath.section == CreditCardInfoSectionNumber || (indexPath.section == AmountSectionNumber && indexPath.row == SubtotalRowNumber)){
        
        NSString *CellIdentifier = @"SaleConfirmationInfoCell";
        SaleConfirmationInfoCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[SaleConfirmationInfoCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
        }
        cell.saleConfirmationCellType = SaleConfirmationCellTypeRegular;
        if (indexPath.section == CreditCardInfoSectionNumber){
            if (indexPath.row == CreditCardNumberRowNumber){
                cell.cellTitleLabel.text = @"Tarjeta:";
                cell.cellValueLabel.text = transactionInfo.creditCardInfo.creditCardNumberMasked;
            }else if (indexPath.row == CreditCardOwnerRowNumber){
                cell.cellTitleLabel.text = @"Nombre:";
                cell.cellValueLabel.text = transactionInfo.creditCardInfo.cardHolderName;
            }
        }else if (indexPath.section == AmountSectionNumber){
            if (indexPath.row == SubtotalRowNumber){
                cell.cellTitleLabel.text = @"Subtotal:";
                cell.cellValueLabel.text = [NSString stringWithFormat:@"%@ %@", transactionInfo.amountWithFormat, transactionInfo.affiliate.currencyCode];
            }
        }
        return cell;
    }else if (indexPath.section == TotalAmountSectionNumber){
        NSString *CellIdentifier = @"SaleConfirmationInfoTotalAmountCell";
        SaleConfirmationInfoCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[SaleConfirmationInfoCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
        }
        cell.saleConfirmationCellType = SaleConfirmationCellTypeAmount;
        if (indexPath.row == TotalAmountRowNumber){
            cell.cellTitleLabel.text = @"Monto Total";
            NSString *totalAmountStr = @"";
            if ([transactionInfo isKindOfClass:[SaleTransactionInfo class]]){
                SaleTransactionInfo *saleTransactionInfo = (SaleTransactionInfo *)transactionInfo;
                //totalAmountStr = [NSString stringWithFormat:@"%.02f %@", saleTransactionInfo.saleTotalAmount, transactionInfo.affiliate.currencyCode];
                totalAmountStr = [NSString stringWithFormat:@"%@ %@", saleTransactionInfo.saleTotalAmountWithFormat, transactionInfo.affiliate.currencyCode];
            }else if ([transactionInfo isKindOfClass:[RefundTransactionInfo class]]){
                totalAmountStr = [NSString stringWithFormat:@"%@ %@", transactionInfo.amountWithFormat, transactionInfo.affiliate.currencyCode];
            }

            NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc] initWithAttributedString:cell.cellValueLabel.attributedText];
            [attributedText replaceCharactersInRange:NSMakeRange(0, attributedText.mutableString.length) withString:totalAmountStr];
            //const NSRange range = NSMakeRange(totalAmountStr.length-3, 3);
            NSRange range = [totalAmountStr rangeOfString:transactionInfo.affiliate.currencyCode];
            [attributedText addAttribute:NSFontAttributeName value:[UIFont fontWithName:cell.cellValueLabel.font.fontName size:20] range:range];
            cell.cellValueLabel.attributedText = attributedText;
        }
        
        return cell;
    }
    
    if (indexPath.section == AmountSectionNumber){
        if (indexPath.row == [self.taxesRowNumber intValue]){
            SaleTransactionInfo *saleTransactionInfo = (SaleTransactionInfo *)userInfo.sessionInfo.currentTransactionInfo;
            NSString *CellIdentifier = @"SaleConfirmationTextViewInfoCell";
            SaleConfirmationTextViewInfoCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[SaleConfirmationTextViewInfoCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
            }
            cell.cellTitleLabel.text = @"Impuestos:";
            cell.cellValueTextField.placeholder = @"Impuestos";
            // The textfield must be always empty.
            cell.cellValueTextField.text = @"";
            //cell.cellValueTextField.text = saleTransactionInfo.taxValue;
            cell.cellValueTextField.delegate = self;
            cell.cellValueTextField.tag = TaxAmountTextFieldTag;
            // Taxes are always amount based.
            cell.cellTypeIdentifierLabel.text = transactionInfo.affiliate.currencyCode;
            /*if (userInfo.terminalInfo.merchant.merchantTaxType == MaxAmountTaxType){
                cell.cellTypeIdentifierLabel.text = transactionInfo.affiliate.currencyCode;
            }else{
                cell.cellTypeIdentifierLabel.text = @"%";
            }*/
            
            [cell.cellValueTextField hasCorrectValues:NO];
            
            return cell;
        }else if (indexPath.row == [self.tipRowNumber intValue]){
            SaleTransactionInfo *saleTransactionInfo = (SaleTransactionInfo *)userInfo.sessionInfo.currentTransactionInfo;
            if (userInfo.terminalInfo.merchant.merchantTipType == MaxAmountTaxType){
                NSString *CellIdentifier = @"SaleConfirmationTextViewInfoCell";
                SaleConfirmationTextViewInfoCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                if (cell == nil) {
                    cell = [[SaleConfirmationTextViewInfoCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
                }
                cell.cellTitleLabel.text = @"Propina:";
                cell.cellValueTextField.placeholder = @"Propina";
                if ([saleTransactionInfo.tipValue isEqualToString:@"0"]){
                    cell.cellValueTextField.text = @"";
                }else{
                    cell.cellValueTextField.text = saleTransactionInfo.tipValue;
                }
                cell.cellValueTextField.delegate = self;
                cell.cellValueTextField.tag = TipAmountTextFieldTag;
                if (userInfo.terminalInfo.merchant.merchantTipType == MaxAmountTipType){
                    cell.cellTypeIdentifierLabel.text = transactionInfo.affiliate.currencyCode;
                }else{
                    cell.cellTypeIdentifierLabel.text = @"%";
                }
                
                [cell.cellValueTextField hasCorrectValues:NO];
                
                return cell;
            }else if (userInfo.terminalInfo.merchant.merchantTipType == PercentageTaxType){
                NSString *CellIdentifier = @"SaleConfirmationSegmentedButtonInfoCell";
                SaleConfirmationSegmentedButtonInfoCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                if (cell == nil) {
                    cell = [[SaleConfirmationSegmentedButtonInfoCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
                }
                cell.cellTitleLabel.text = @"Propina:";
                //cell.cellValueLabel.text = [NSString stringWithFormat:@"%@ %@", saleTransactionInfo.tipValue, typeTypeSymbol];

                [cell.cellValueSegmentedControl addTarget:self action:@selector(tipSegmentedButtonValueChanged:) forControlEvents:UIControlEventValueChanged];
                
                [cell.cellValueSegmentedControl removeAllSegments];
                for(int index = 0; index < userInfo.terminalInfo.merchant.merchantTipPercentageValues.count; ++index){
                    NSString *percentageValue = [userInfo.terminalInfo.merchant.merchantTipPercentageValues objectAtIndex:index];
                    [cell.cellValueSegmentedControl insertSegmentWithTitle:[NSString stringWithFormat:@"%@ %%", percentageValue] atIndex:index animated:NO];
                }
                
                if (cell.cellValueSegmentedControl.numberOfSegments > 0){
                    // Select the first item in the tips segmented control.
                    cell.cellValueSegmentedControl.selectedSegmentIndex = [userInfo.terminalInfo.merchant.merchantTipPercentageValues indexOfObject:saleTransactionInfo.tipValue];
                }
                
                [cell.cellValueSegmentedControl hasCorrectValues:NO];
                
                return cell;
            }else if (userInfo.terminalInfo.merchant.merchantTipType == MixedTipType){
                NSString *CellIdentifier = @"SaleConfirmationSegmentedButtonAndTextFieldInfoCell";
                SaleConfirmationSegmentedButtonAndTextFieldInfoCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                if (cell == nil) {
                    cell = [[SaleConfirmationSegmentedButtonAndTextFieldInfoCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
                }
                cell.cellTitleLabel.text = @"Propina:";
                cell.cellValueTextField.placeholder = @"Propina";
                cell.cellValueTextField.text = saleTransactionInfo.tipValue;
                cell.cellValueTextField.delegate = self;
                cell.cellValueTextField.tag = TipAmountTextFieldTag;
                cell.cellTypeIdentifierLabel.text = transactionInfo.affiliate.currencyCode;
                
                [cell.cellValueSegmentedControl addTarget:self action:@selector(tipSegmentedButtonValueChanged:) forControlEvents:UIControlEventValueChanged];
                
                [cell.cellValueSegmentedControl removeAllSegments];
                for(int index = 0; index < userInfo.terminalInfo.merchant.merchantTipPercentageValues.count; ++index){
                    NSString *percentageValue = [userInfo.terminalInfo.merchant.merchantTipPercentageValues objectAtIndex:index];
                    [cell.cellValueSegmentedControl insertSegmentWithTitle:[NSString stringWithFormat:@"%@ %%", percentageValue] atIndex:index animated:NO];
                }
                
                if (cell.cellValueSegmentedControl.numberOfSegments > 0){
                    // Select the first item in the tips segmented control.
                    cell.cellValueSegmentedControl.selectedSegmentIndex = [userInfo.terminalInfo.merchant.merchantTipPercentageValues indexOfObject:saleTransactionInfo.tipValue];
                }
                
                mixedTipAmountTextField = cell.cellValueTextField;
                mixedTipPercentageSegmentedControl = cell.cellValueSegmentedControl;
                
                [cell.cellValueSegmentedControl hasCorrectValues:YES];
                [cell.cellValueTextField hasCorrectValues:YES];
                
                if (![userInfo.terminalInfo.merchant.useTax boolValue]){
                    // If the merchant doesnt use tax, it means that the Mixed Tip Cell is the first and only one, so the gray separator line doesnt need to be shown.
                    cell.topSeparatorView.hidden = YES;
                }
                
                return cell;
            }
        }
    }
}

#pragma mark UITableViewDataDelegate Methods
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIImageView *headerImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Full_Width_Gray_Frame"]];
    return headerImageView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    float rowHeight = tableView.rowHeight;
    if (indexPath.section == AmountSectionNumber){
        if (indexPath.row == [self.taxesRowNumber intValue]){
            return 50;
        }
        if (indexPath.row == [self.tipRowNumber intValue]){
            return 90;
        }
    }
    if (indexPath.section == TotalAmountSectionNumber){
        return 85;
    }
    return rowHeight;
}

#pragma mark SalesManagerDelegate Methods

- (void)saleResponseReceived:(TransactionResult *)transactionResult error:(NSError *)error{
    [self.HUD hide:YES];
    //NSLog(@"SaleResultReceived: %@", [transactionResult description]);
    
    if (transactionResult){
        UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
        userInfo.sessionInfo.currentTransactionInfo.transactionResult = transactionResult;
        // If the sale has been made, check for the minimun signature amount
        if ([self transactionNeedsSignature]){
            // Log Localytics event
            NSDictionary *dictionary =
            [NSDictionary dictionaryWithObjectsAndKeys:
             userInfo.terminalId,
             LocalyticsEventParameterNameTerminalId,
             userInfo.sessionInfo.sessionUserName,
             LocalyticsEventParameterNameUser,
             [NSNumber numberWithInt: 1],
             LocalyticsEventParameterNameRequiresSignature,
            nil];
            [[LocalyticsSession shared] tagEvent:LocalyticsEventNameMakeSale attributes:dictionary];
            
            // Sale surpasses the signature amount limit, request the signature
            [self presentSignatureNavController:transactionResult];
        }else{
            // Log Localytics event
            NSDictionary *dictionary =
            [NSDictionary dictionaryWithObjectsAndKeys:
             userInfo.terminalId,
             LocalyticsEventParameterNameTerminalId,
             userInfo.sessionInfo.sessionUserName,
             LocalyticsEventParameterNameUser,
             [NSNumber numberWithInt: 0],
             LocalyticsEventParameterNameRequiresSignature,
             nil];
            [[LocalyticsSession shared] tagEvent:LocalyticsEventNameMakeSale attributes:dictionary];
            
            // Sale Amount is below the signature amount, go to the Recipe View
            [self performSegueWithIdentifier:@"ConfirmationToRecipeSegue" sender:self];
        }
    }else{
        if (![super checkSessionExpiration:error]){
            UIAlertView *errorAlertView = [[UIAlertView alloc] initWithTitle:@"Confirmación de Autorización" message:error.localizedDescription delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
            errorAlertView.delegate = self;
            errorAlertView.tag = ErrorAlertViewTag;
            [errorAlertView show];
        }
    }
}

- (void)refundResponseReceived:(TransactionResult *)transactionResult error:(NSError *)error{
    [self.HUD hide:YES];
    //NSLog(@"RefundResultReceived: %@", [transactionResult description]);
    
    if (transactionResult){
        UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
        userInfo.sessionInfo.currentTransactionInfo.transactionResult = transactionResult;
        
        // Log Localytics event
        NSDictionary *dictionary =
        [NSDictionary dictionaryWithObjectsAndKeys:
         userInfo.terminalId,
         LocalyticsEventParameterNameTerminalId,
         userInfo.sessionInfo.sessionUserName,
         LocalyticsEventParameterNameUser,
         [NSNumber numberWithInt: 1],
         LocalyticsEventParameterNameRequiresSignature,
         nil];
        [[LocalyticsSession shared] tagEvent:LocalyticsEventNameMakeRefund attributes:dictionary];
        
        // Refund Transactions ALWAYS needs signature
        [self presentSignatureNavController:transactionResult];
    }else{
        if (![super checkSessionExpiration:error]){
            UIAlertView *errorAlertView = [[UIAlertView alloc] initWithTitle:@"Confirmación de Devolución" message:error.localizedDescription delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
            errorAlertView.delegate = self;
            errorAlertView.tag = ErrorAlertViewTag;
            [errorAlertView show];
        }
    }

}

#pragma mark UINavigationControllerDelegate Methods

// and here's the delegate method
- (void)navigationController:(UINavigationController *)navigationController
      willShowViewController:(UIViewController *)viewController
                    animated:(BOOL)animated {
    if (viewController == [navigationController.viewControllers objectAtIndex:0]){
        //[self dismissModalViewControllerAnimated:YES];
        [self dismissViewControllerAnimated:YES completion:nil];
    //}else if ([viewController isKindOfClass:[RecipeViewController class]]){
    }else if ([viewController isKindOfClass:[UIViewController class]]){
        //[self dismissModalViewControllerAnimated:YES];
        // Show the Recipe View
        [self performSegueWithIdentifier:@"ConfirmationToRecipeSegue" sender:self];
        // Dismiss the navigation controller
        //[self dismissModalViewControllerAnimated:YES];
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}

#pragma mark UIAlertViewDelegate Methods

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView.tag == AdminUserAlertView){
        if (buttonIndex != alertView.cancelButtonIndex){
            
            NSString *username = [alertView textFieldAtIndex:0].text;
            NSString *userPin = [alertView textFieldAtIndex:1].text;
            
            self.HUD.labelText = @"Realizando Devolución";
            [self.HUD show:YES];
            UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
            SalesManager *salesManager = [[SalesManager alloc] init  ];
            salesManager.salesManagerDelegate = self;
            TransactionInfo *transactionInfo = userInfo.sessionInfo.currentTransactionInfo;
            // Refund transactions always needs signature, so the refund operation cannot be finished here.
            [salesManager makeRefund:transactionInfo.creditCardInfo.creditCardEncryptedPayload amount:transactionInfo.amount affiliate:transactionInfo.affiliate location:userInfo.userLocation.coordinate username:username userPIN:userPin];
        }
    }
}

- (BOOL)alertViewShouldEnableFirstOtherButton:(UIAlertView *)alertView
{
    if (alertView.tag == AdminUserAlertView){
        NSString *userNameText = [[alertView textFieldAtIndex:0] text];
        NSString *pinText = [[alertView textFieldAtIndex:1] text];
        if([RegularExpressionsValidator matchRegExWithValue:EmailRegEx value:userNameText])
        {
            // Username is a valid email
            if (pinText.length ==  PINLength){
                return YES;
            }
        }
        return NO;
    }
    return YES;
}

- (void)viewDidUnload {
    [self setTitleLabel:nil];
    [self setSaleConfirmationValueTableView:nil];
    [self setMakeSaleButton:nil];
    [self setTitleConfirmationTableViewVerticalSpace:nil];
    [self setMakeSaleLabel:nil];
    [super viewDidUnload];
}

#pragma mark UITextFieldDelegate Methods

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    SaleTransactionInfo *saleTransactionInfo = (SaleTransactionInfo *)userInfo.sessionInfo.currentTransactionInfo;
    double valueAsDouble = [AmountFormatter convertAmountToDouble:newString];
    NSString *valueAsString = [AmountFormatter formatDoubleAmountAsString:valueAsDouble];
    if (textField.tag == TaxAmountTextFieldTag){
        //saleTransactionInfo.taxValue = newString;
        saleTransactionInfo.taxValue = valueAsString;
    }else if (textField.tag == TipAmountTextFieldTag){
        //saleTransactionInfo.tipValue = newString;
        saleTransactionInfo.tipValue = valueAsString;
        
        if (mixedTipPercentageSegmentedControl != nil){
            // If the Tips is Mixed Type, when entering the amount in the textfield, clear the selection in the percentage segmented button
            [mixedTipPercentageSegmentedControl setSelectedSegmentIndex:UISegmentedControlNoSegment];
        }
    }
    
    NSIndexPath *totalAmountIndexPath = [NSIndexPath indexPathForItem:TotalAmountRowNumber inSection:TotalAmountSectionNumber];
    [self.saleConfirmationValueTableView reloadRowsAtIndexPaths:@[totalAmountIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
    
    ZimpleTextField *zimpleTextField = (ZimpleTextField *)textField;
    if (![newString isEqualToString:@""]){
        if ([newString doubleValue] > [AmountFormatter convertAmountToDouble:saleTransactionInfo.amount]){
            // The value in tips or taxes cannot be larger than the amount to charge.
            textField.text = @"";
            [zimpleTextField hasCorrectValues:NO];
            if (zimpleTextField == mixedTipAmountTextField){
                [mixedTipPercentageSegmentedControl hasCorrectValues:NO];
            }
            return NO;
        }else{
            [zimpleTextField hasCorrectValues:YES];
            if (zimpleTextField == mixedTipAmountTextField){
                [mixedTipPercentageSegmentedControl hasCorrectValues:YES];
            }
        }
    }else{
        [zimpleTextField hasCorrectValues:NO];
        if (zimpleTextField == mixedTipAmountTextField){
            [mixedTipPercentageSegmentedControl hasCorrectValues:NO];
        }
    }
    
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField{
    if (textField.tag == TipAmountTextFieldTag){
        
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    //self.saleConfirmationValueTableView.scrollEnabled = NO;
    if ([textField.text isEqualToString:@""]){
        
        UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
        SaleTransactionInfo *saleTransactionInfo = (SaleTransactionInfo *)userInfo.sessionInfo.currentTransactionInfo;
        if (textField.tag == TaxAmountTextFieldTag){
            saleTransactionInfo.taxValue = textField.text;
        }else if (textField.tag == TipAmountTextFieldTag){
            saleTransactionInfo.tipValue = textField.text;
        }
        NSIndexPath *totalAmountIndexPath = [NSIndexPath indexPathForItem:TotalAmountRowNumber inSection:TotalAmountSectionNumber];
        [self.saleConfirmationValueTableView reloadRowsAtIndexPaths:@[totalAmountIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
    }
    [self.saleConfirmationValueTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForItem:0 inSection:0] atScrollPosition:UITableViewRowAnimationBottom animated:YES];
}

@end
