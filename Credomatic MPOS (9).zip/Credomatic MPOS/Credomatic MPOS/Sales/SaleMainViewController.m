/*
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  SaleMainViewController.m
//  Zimple POS
//

#import "SaleMainViewController.h"

#define AmountTextFieldTag 0
#define TaxesTextFieldTag 1
#define TipTextFieldTag 2

@interface SaleMainViewController ()

@property (weak, nonatomic) UITextField *activeField;

@end

@implementation SaleMainViewController

@synthesize scrollView;
@synthesize contentView;
@synthesize titleLabel;
@synthesize amountTextField;
@synthesize amountCurrencyLabel;
@synthesize continueButton;
@synthesize contentViewHeightConstraint;
@synthesize amountTextFieldHeightConstraint;
@synthesize taxTextFieldHeightConstraint;
@synthesize tipTextFieldHeightConstraint;
@synthesize saleAffiliate;
@synthesize taxTextField;
@synthesize tipTextField;
@synthesize taxPercentageLabel;
@synthesize tipTypeSwitch;
@synthesize verticalSeparatorImageView;
@synthesize activeField;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    titleLabel.textColor = [UIColorList credomaticBlueColor];
    taxPercentageLabel.textColor = [UIColorList credomaticBlueColor];
    amountCurrencyLabel.textColor = [UIColorList credomaticBlueColor];
    amountCurrencyLabel.text = saleAffiliate.currencyCode;
    
    tipTypeSwitch.onText = @"%";
    tipTypeSwitch.offText = saleAffiliate.currencyCode;
	[tipTypeSwitch addTarget:self action:@selector(tipTypeSwitchValueChanged:) forControlEvents:UIControlEventValueChanged];
    
    amountTextField.font = [UIFont fontWithName:amountTextField.font.familyName size:40];
    if (IS_IPHONE_5){
        contentViewHeightConstraint.constant += 88;
        
        amountTextFieldHeightConstraint.constant = 60;
        amountTextField.font = [UIFont fontWithName:amountTextField.font.familyName size:50];
        
        taxTextFieldHeightConstraint.constant = 45;
        taxTextField.font = [UIFont fontWithName:taxTextField.font.familyName size:19];
        tipTextFieldHeightConstraint.constant = 45;
        tipTextField.font = [UIFont fontWithName:tipTextField.font.familyName size:19];
    }
    contentView.backgroundColor = [UIColor clearColor];
    
    taxTextField.hidden = YES;
    tipTextField.hidden = YES;
    taxPercentageLabel.hidden = YES;
    tipTypeSwitch.hidden = YES;
    verticalSeparatorImageView.hidden = YES;
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    titleLabel.text = saleAffiliate.affiliateTitle;
    amountCurrencyLabel.text = saleAffiliate.currencyCode;
    
    // Dont take into account the saved tax value. Must be enabled when processing taxes is enabled.
    //float taxPercentage = [SettingsManager getTaxPercentageUserDefault];
    float taxPercentage = 0;
    if (taxPercentage > 0){
        taxTextField.text = [NSString stringWithFormat:@"%2.f", taxPercentage];
    }

    // Set the current sale as nil;
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    userInfo.sessionInfo.currentTransactionInfo = nil;
    
    continueButton.enabled = FALSE;
    amountTextField.text = @"";
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)handleTap:(UIGestureRecognizer *)gestureRecognizer{
    // Override the handleTap Method to prevent the keyboard from disappear when the view is touched.
}

- (void)continueEditingAfterLeftMenuCloses{
    [amountTextField becomeFirstResponder];
}

- (void)tipTypeSwitchValueChanged:(id)sender
{
}

- (void)checkParameters:(NSString *)amount{
    BOOL correctParameters = TRUE;
    
    if ([amount isEqualToString:@""] || (saleAffiliate.maxAmountLimit != VALUE_NOT_SET && [AmountFormatter convertAmountToDouble:amount] > saleAffiliate.maxAmountLimit)){
        correctParameters = FALSE;
        [amountTextField hasCorrectValues:NO];
    }else{
        if ([AmountFormatter convertAmountToDouble:amount] > 0){
            [amountTextField hasCorrectValues:YES];
        }else{
            correctParameters = FALSE;
            [amountTextField hasCorrectValues:NO];
        }
    }
    
    continueButton.enabled = correctParameters;
}

- (IBAction)continueButtonTouchUpInside:(id)sender {
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    SaleTransactionInfo *saleTransactionInfo = [[SaleTransactionInfo alloc] init];
    saleTransactionInfo.amount = amountTextField.text;
    /*if ([taxTextField.text isEqualToString:@""]){
        saleTransactionInfo.taxPercentage = @"0";
    }else{
        saleTransactionInfo.taxPercentage = taxTextField.text;
    }
    if ([tipTextField.text isEqualToString:@""]){
        saleTransactionInfo.tipValue = @"0";
    }else{
        saleTransactionInfo.tipValue = tipTextField.text;
    }
    saleTransactionInfo.isTipPercetage = tipTypeSwitch.on;
     */
    saleTransactionInfo.affiliate = saleAffiliate;
    
    userInfo.sessionInfo.currentTransactionInfo = saleTransactionInfo;
    
    [self performSegueWithIdentifier:@"SalesToSlideCardSegue" sender:self];
}

#pragma mark - UITextField Delegate Methods

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    
    if (textField.tag == AmountTextFieldTag){
        // Every time the amount changes, the tips must be resetted, sinde tip restrictions depends on the amount
        tipTextField.text = @"";
        [self checkParameters:newString];
    }else if (textField.tag == TaxesTextFieldTag){
        float taxesPercentaje = [newString floatValue];
        if (taxesPercentaje > 100){
            textField.text = @"100";
            return NO;
        }else if (taxesPercentaje < 0){
            textField.text = @"0";
            return NO;
        }
    }else if (textField.tag == TipTextFieldTag){
        float tipValue = [newString floatValue];
        if (tipTypeSwitch.on){
            // % is selected in switch
            if (tipValue > 100){
                textField.text = @"100";
                return NO;
            }else if (tipValue < 0){
                textField.text = @"0";
                return NO;
            }
        }else{
            // Currency is selected in the switch
            // Tip cannot be superior to the 99% of the amount sale
            // (Tip * 100) / amount
            float saleAmount = [amountTextField.text floatValue];
            float tipPercentage = (tipValue * 100) / saleAmount;
            NSLog(@"Tip Percentage: %.02f", tipPercentage);
            if (tipPercentage > 99){
                // Set the tip to the 99% of the amount
                // (99 * amount) / 100
                float maxTipAmount = (99 * saleAmount) / 100;
                textField.text = [NSString stringWithFormat:@"%.02f",maxTipAmount ];
                return NO;
            }
        }
    }
    
    return YES;
}

- (BOOL)textFieldShouldClear:(UITextField *)textField{
    
    if (textField.tag == AmountTextFieldTag){
        [self checkParameters:@""];
    }
    
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    activeField = textField;
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    activeField = nil;
    if (textField.tag == TaxesTextFieldTag){
        textField.text = [NSString stringWithFormat:@"%d", [textField.text intValue]];
    }else{
        textField.text = [NSString stringWithFormat:@"%.02f", [textField.text doubleValue]];
    }
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    
    return YES;
}

- (void)viewDidUnload {
    [self setTipTypeSwitch:nil];
    [self setTipTypeSwitch:nil];
    [self setTitleLabel:nil];
    [self setContentView:nil];
    [self setContentViewHeightConstraint:nil];
    [self setAmountTextFieldHeightConstraint:nil];
    [self setTaxTextFieldHeightConstraint:nil];
    [self setTipTextFieldHeightConstraint:nil];
    [self setVerticalSeparatorImageView:nil];
    [super viewDidUnload];
}

@end
