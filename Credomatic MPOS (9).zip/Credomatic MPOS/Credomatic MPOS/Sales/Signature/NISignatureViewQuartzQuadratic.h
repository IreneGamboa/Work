//
//  NISignatureViewQuartzQuadratic.h
//  SignatureDemo
//
//  Created by Jason Harwig on 11/6/12.
//  Copyright (c) 2012 Near Infinity Corporation. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol NISignatureViewQuartzQuadraticDelegate <NSObject>
@optional
- (void)strokeRecorded;
- (void)drawingErased;
@end

@interface NISignatureViewQuartzQuadratic : UIView

@property (nonatomic, strong) id <NISignatureViewQuartzQuadraticDelegate> delegate;

@end
