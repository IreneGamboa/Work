/*
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  ShareRecipeViewController.m
//  Zimple POS
//

#import "ShareRecipeViewController.h"

#define EmailTextFieldTag 0
#define PrintReceiptNotAvailableAlertTag 1
#define ErrorAlertViewTag 100

@interface ShareRecipeViewController ()

@property (weak, nonatomic) UITextField *activeField;
@property (nonatomic) BOOL isPrinting;

@end

@implementation ShareRecipeViewController

@synthesize scrollView;
@synthesize contentView;
@synthesize emailTextField;
@synthesize sendButton;
@synthesize titleLabel;
@synthesize recipeDisclamerLabel;
@synthesize activeField;
@synthesize transactionRecord;
@synthesize isPrinting;
@synthesize transactionTypeId;
@synthesize transactionRecordCurrency;
@synthesize transactionRecordAffiliateBankTerminal;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    [self registerForKeyboardNotifications];
    
    titleLabel.textColor = [UIColorList credomaticBlueColor];
    recipeDisclamerLabel.textColor = [UIColorList credomaticGrayColor];
    sendButton.enabled = NO;
    
    scrollView.backgroundColor = [UIColor clearColor];
    contentView.backgroundColor = [UIColor clearColor];
    
    self.navigationItem.leftBarButtonItem = nil;
    self.navigationItem.hidesBackButton = YES;
    
    if (transactionRecord != nil){
        // Disable the right bar button (End Transaction) when viewing a already made transaction
        self.navigationItem.rightBarButtonItem = nil;
    }
    
    isPrinting = NO;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
    [self unRegisterForAccesoryNotifications];
    [self setEmailTextField:nil];
    [self setSendButton:nil];
    [self setTitleLabel:nil];
    [self setRecipeDisclamerLabel:nil];
    [self setScrollView:nil];
    [self setContentView:nil];
    [self setPrintReceiptButton:nil];
    [super viewDidUnload];
}

- (void)registerForKeyboardNotifications
{
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWasShown:)
                                                 name:UIKeyboardDidShowNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillBeHidden:)
                                                 name:UIKeyboardWillHideNotification object:nil];
    
}

- (void)registerForAccesoryNotifications
{
    EAAccessoryManager *sam = [EAAccessoryManager sharedAccessoryManager];
    [sam registerForLocalNotifications];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(accessoryDidConnect:)
                                                 name:EAAccessoryDidConnectNotification
                                               object:nil];
}

- (void)unRegisterForAccesoryNotifications
{
    EAAccessoryManager *sam = [EAAccessoryManager sharedAccessoryManager];
    [sam unregisterForLocalNotifications];
    [[NSNotificationCenter defaultCenter] removeObserver:EAAccessoryDidConnectNotification];
}

// Called when the UIKeyboardDidShowNotification is sent.
- (void)keyboardWasShown:(NSNotification*)aNotification
{
    NSDictionary* info = [aNotification userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    
    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0.0, 0.0, kbSize.height, 0.0);
    scrollView.contentInset = contentInsets;
    scrollView.scrollIndicatorInsets = contentInsets;
    
    CGRect aRect = self.view.frame;
    aRect.size.height -= kbSize.height;
    CGPoint origin = activeField.frame.origin;
    origin.y -= scrollView.contentOffset.y;
    
    origin.y += self.activeField.frame.size.height;
    origin.y +=self.activeField.frame.origin.y + self.activeField.frame.size.height;
    
    if (!CGRectContainsPoint(aRect, origin) ) {
        CGPoint scrollPoint = CGPointMake(0.0, activeField.frame.origin.y-(aRect.size.height) + 44);
        [scrollView setContentOffset:scrollPoint animated:YES];
    }
}

// Called when the UIKeyboardWillHideNotification is sent
- (void)keyboardWillBeHidden:(NSNotification*)aNotification
{
    UIEdgeInsets contentInsets = UIEdgeInsetsZero;
    scrollView.contentInset = contentInsets;
    scrollView.scrollIndicatorInsets = contentInsets;
}

- (void)checkParameters:(NSString *)email{
    BOOL correctParameters = TRUE;
    
    if (![RegularExpressionsValidator matchRegExWithValue:EmailRegEx value:email]){
        correctParameters = FALSE;
        [emailTextField hasCorrectValues:NO];
    }else{
        [emailTextField hasCorrectValues:YES];
    }
    
    sendButton.enabled = correctParameters;
}

- (IBAction)sendButtonTouchUpInside:(id)sender {
    [emailTextField resignFirstResponder];
    self.HUD.mode = MBProgressHUDModeIndeterminate;
    self.HUD.labelText = @"Enviando Correo Electrónico";
    [self.HUD show:YES];
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    TransactionInfo  *transactionInfo = userInfo.sessionInfo.currentTransactionInfo;
    NSString *transactionId = transactionInfo.transactionResult.zimpleTransactionId;
    if (transactionRecord != nil){
        transactionId = transactionRecord.zimpleTransactionId;
    }
    // Sent the email when there's a email address
    SalesManager *salesManager = [[SalesManager alloc] init  ];
    salesManager.salesManagerDelegate = self;
    [salesManager sendEmailSaleReceipt:transactionId email:emailTextField.text];
}

- (void)accessoryDidConnect:(NSNotification*)aNotification{
    NSLog(@"Connected");
    EAAccessory *accesoryDevice = [aNotification.userInfo objectForKey:EAAccessoryKey];
    NSLog(@"Manufacturer: %@", accesoryDevice.manufacturer);
    NSLog(@"Model: %@", accesoryDevice.modelNumber);
    for(NSString *protocol in accesoryDevice.protocolStrings){
        NSLog(@"Protocol: %@", protocol);
    }
    if([accesoryDevice.protocolStrings indexOfObject:@"com.zebra.rawport"] != NSNotFound){
        if (isPrinting){
            [NSThread detachNewThreadSelector:@selector(print:) toTarget:self withObject:accesoryDevice];
        }
    }
    
}

- (IBAction)printReceiptButtonTouchUpInside:(id)sender {
    UIAlertView *printReceiptNotAvailableAlertView = [[UIAlertView alloc] initWithTitle:@"Impresión de Recibo" message:@"La funcionalidad de impresión no se encuentra habilitada." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    printReceiptNotAvailableAlertView.tag = PrintReceiptNotAvailableAlertTag;
    //[printReceiptNotAvailableAlertView show];
    
    // First, check if theres a connected printer.
    isPrinting = YES;
    NSMutableArray *connectedAccesories = [[NSMutableArray alloc] init];
    [self checkAvailableExternalDevices:connectedAccesories];
    
    if ([connectedAccesories count] == 0){
        // No devices currently connected, list the bluetooth devices to the user
        EAAccessoryManager *sam = [EAAccessoryManager sharedAccessoryManager];
        [sam showBluetoothAccessoryPickerWithNameFilter:nil completion:^(NSError *error) {
            NSLog(@"error: %@", error.description);
            if (error == nil){
                NSLog(@"Error is nil in showBluetoothAccesoryPickerWithNameFilter");
            }else{
                isPrinting = NO;
            }
        }];
    }else if (connectedAccesories.count > 1){
        // More than one accesories connected for printing, present the user with a list to choose from.
        EAAccessory *selectedPrinter = [connectedAccesories objectAtIndex:0];
        [NSThread detachNewThreadSelector:@selector(print:) toTarget:self withObject:selectedPrinter];
    }else{
        EAAccessory *selectedPrinter = [connectedAccesories objectAtIndex:0];
        [NSThread detachNewThreadSelector:@selector(print:) toTarget:self withObject:selectedPrinter];
    }
}

- (IBAction)finishBarButtontTouchUpInside:(id)sender {
    // Clear the current transaction info
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    userInfo.sessionInfo.currentTransactionInfo = nil;
     
    [self.navigationController popToRootViewControllerAnimated:YES];
}

- (void)checkAvailableExternalDevices:(NSMutableArray *)connectedAccesories{
    EAAccessoryManager *sam = [EAAccessoryManager sharedAccessoryManager];
    for (EAAccessory *accessory in [sam connectedAccessories]) {
        if([accessory.protocolStrings indexOfObject:@"com.zebra.rawport"] != NSNotFound){
            [connectedAccesories addObject:accessory];
            //Note: This will find the first printer connected! If you have multiple Zebra printers connected, you should display a list to the user and have him select the one they wish to use
        }
    }
}

- (void)print:(EAAccessory *)printerAccesory{
    id<ZebraPrinterConnection, NSObject> connection = nil;
    
    connection = [[MfiBtPrinterConnection alloc] initWithSerialNumber:printerAccesory.serialNumber];
    BOOL didOpen = [connection open];
    if(didOpen == YES) {
        NSError *error = nil;
        id<ZebraPrinter,NSObject> printer = [ZebraPrinterFactory getInstance:connection error:&error];
        
        if(printer != nil) {
            PrinterLanguage language = [printer getPrinterControlLanguage];
            
            if (language == PRINTER_LANGUAGE_ZPL){
                NSLog(@"Printer Language: ZPL");
            }else if (language == PRINTER_LANGUAGE_CPCL){
                NSLog(@"Printer Language: CPCL");
            }
            
            NSError * __autoreleasing commandError = nil;
            id<ToolsUtil,NSObject> printerToolsUtil = [printer getToolsUtil];
            //BOOL success = [printerToolsUtil sendCommand:@"! U1 getvar \"device.unique_id\" " error:&commandError];
            //BOOL success = [printerToolsUtil sendCommand:@"! U1 getvar \"hola\" " error:&commandError];
            
            NSString *languageStr = [SGD GET:@"device.languages" withPrinterConnection:connection error:&commandError];
            NSLog(@"The Language is: %@", languageStr);
            if ([languageStr hasPrefix:@"?line_print"]){
                // Printer has line_print language set. It will print every character as is. For example: ^XA^FO17,16^GB379,371,8^FS^FT65,255^A0N,135,134^FDTEST^FS^XZ will print ^XA^FO17,16^GB379,371,8^FS^FT65,255^A0N,135,134^FDTEST^FS^XZ instead of interpreting the string as a ZPL string.
                // Change the language to ZPL
                NSLog(@"Printer has line_print, changing it to zpl");
                //BOOL success1 = [SGD SET:@"device.languages" withValue:@"line_print" andWithPrinterConnection:connection error:&error];
                BOOL success1 = [SGD SET:@"device.languages" withValue:@"hybrid_xml_zpl" andWithPrinterConnection:connection error:&error];
                if (success1){
                    NSLog(@"Success: Device set to ZPL");
                }else{
                    NSLog(@"Not Success: Device not set to ZPL");
                }
            }
            
            // Always set the printer as ZPL mode.
            //BOOL success1 = [printerToolsUtil sendCommand:@"! U1 setvar \"device.languages\" \"hybrid_xml_zpl\"" error:nil];
            
            
            /*BOOL success = [printerToolsUtil sendCommand:@"! U1 getvar \"device.languages\"'\r\n'" error:&commandError];
            if (success){
                NSLog(@"Success");
                //BOOL success1 = [printerToolsUtil sendCommand:@"! U1 setvar \"device.languages\" \"hybrid_xml_zpl\"" error:nil];
                BOOL success1 = [printerToolsUtil sendCommand:@"! U1 setvar \"device.languages\" \"zpl\"" error:nil];
                //BOOL success1 = [printerToolsUtil sendCommand:@"! U1 setvar \"device.languages\" \"hola\"" error:&commandError];
                NSLog(@"Succes1: %d", success1);

            }else{
                NSLog(@"Not Success");
            }*/
            
            NSError *error = nil;
            NSMutableString *zplReceiptFormat = [[NSMutableString alloc] init];
                //zplReceiptFormat = @"^XA^FO17,16^GB379,371,8^FS^FT65,255^A0N,135,134^FDTEST^FS^XZ";
            //zplReceiptFormat = @"^XA^LL203^FO50,50^ADN,36,20^FDJose Manuel Saurez Lee^FS^XZ";
            /*[zplReceiptFormat appendFormat:@"^XA"];                 // Start
            [zplReceiptFormat appendFormat:@"^LH15,30"];            // Set the Label Home (start of the recipe) to x=30 y=30 (similar to padding).
            [zplReceiptFormat appendFormat:@"^LL150"];              // Set the Length to 1 inch in a 203 dpi printer.
            [zplReceiptFormat appendFormat:@"^JMB"];
            //[zplReceiptFormat appendFormat:@"^AD,20,20"];
            //[zplReceiptFormat appendFormat:@"^FO50,50"];
            //[zplReceiptFormat appendFormat:@"^FB203,4,,C"];
            [zplReceiptFormat appendFormat:@"^FDTERMINAL I.D:^FS"];
            [zplReceiptFormat appendFormat:@"^XZ"];                 // End*/
            
            /*[zplReceiptFormat appendFormat:@"! 15 200 200 150 1\r\n"];                 // Start
            [zplReceiptFormat appendFormat:@"ON-FEED IGNORE\r\n"];            // Set the Label Home (start of the recipe) to x=30 y=30 (similar to padding).
            //[zplReceiptFormat appendFormat:@"BOX 20 20 380 380 8\r\n"];              // Set the Length to 1 inch in a 203 dpi printer.
            [zplReceiptFormat appendFormat:@"CENTER\r\n"];              // Set the Length to 1 inch in a 203 dpi printer.
            [zplReceiptFormat appendFormat:@"! U1 SETBOLD 2"];
            [zplReceiptFormat appendFormat:@"TEXT 0 2 0 15 CENTERED COMPANY NAME\r\n"];              // Set the Length to 1 inch in a 203 dpi printer.
            [zplReceiptFormat appendFormat:@"PRINT\r\n"];                 // End
            */
            
            NSString *creditCardLastDigits = @"";
            if (transactionRecord.creditCardLastDigits != nil){
                creditCardLastDigits = transactionRecord.creditCardLastDigits;
            }
            
            /*[zplReceiptFormat appendFormat:@"! U1 JOURNAL\r\n"];
            [zplReceiptFormat appendFormat:@"! U1 LMARGIN 15\r\n"];                 // Sets the left margin to 15 dots to the left
            [zplReceiptFormat appendFormat:@"! U1 CENTER\r\n"];
            [zplReceiptFormat appendFormat:@"! U1 SETBOLD 0\r\n"];                  // Sets the fonts as Regular, not Bold
            [zplReceiptFormat appendFormat:@"! U1 SETLP 5 0 47\r\n"];               // Sets the title font to be type 5 0, height 47
            [zplReceiptFormat appendFormat:@"%@\r\n", userInfo.terminalInfo.terminal.branch.name];
            [zplReceiptFormat appendFormat:@"! U1 SETLP 7 0 15\r\n"];               // Sets the text font to 7 0, height 15
            [zplReceiptFormat appendFormat:@"Terminal ID:   %@\r\n", userInfo.terminalId];
            [zplReceiptFormat appendFormat:@"Fecha:     %@\r\n", transactionDate];
            [zplReceiptFormat appendFormat:@"# Tarjeta: %@\r\n", transactionCardNumber];
            [zplReceiptFormat appendFormat:@"Ref.:      %@\r\n", transactionReferenceNumber];
            [zplReceiptFormat appendFormat:@"Auth.:     %@\r\n", transactionAuthorizationNumber];
            [zplReceiptFormat appendFormat:@"Factura:   %@\r\n\r\n", transactionBillNumber];
            [zplReceiptFormat appendFormat:@"! U1 SETLP 7 0 47\r\n"];               // Sets the Amount Title font to 7 0, with more height of 47 (more spacing)
            [zplReceiptFormat appendFormat:@"Venta:     "];
            [zplReceiptFormat appendFormat:@"! U1 SETLP 5 2 47\r\n"];               // Sets the font for the Amount to 5 2, with height of 47
            [zplReceiptFormat appendFormat:@"! U1 SETBOLD 2\r\n"];                  // Sets the Amount to Bold with level 2
            [zplReceiptFormat appendFormat:@"%@ ", transactionAmount];
            [zplReceiptFormat appendFormat:@"! U1 SETLP 7 0 15\r\n"];
            [zplReceiptFormat appendFormat:@"%@\r\n", transactionRecordCurrency];
            [zplReceiptFormat appendFormat:@"\r\n"];
            if (![transactionType isEqualToString:@""]){
                [zplReceiptFormat appendFormat:@"%@\r\n", transactionType];
            }
            [zplReceiptFormat appendFormat:@"! U1 SETBOLD 0\r\n"];              // Sets the next line to non-bold (regular)
            //[zplReceiptFormat appendFormat:@"! U1 SETLP 7 0 15\r\n"];               // Sets the next line to the reguar font
            [zplReceiptFormat appendFormat:@"*** Copia Cliente ***\r\n\r\n\r\n"];
    */
            //NSLog(@"ZPL Format: %@", zplReceiptFormat);
            //zplReceiptFormat = @"^XA^XZ";
            // In CPCL
            //zplReceiptFormat = @"! 0 200 200 406 1\r\nON-FEED IGNORE\r\nBOX 20 20 380 380 8\r\nT 0 6 137 177 TEST\r\nPRINT\r\n";

            //zplReceiptFormat = @"Hola";
                //NSData *data = [NSData dataWithBytes:[zplReceiptFormat UTF8String] length:[testLabel length]];
            NSData *data = [zplReceiptFormat dataUsingEncoding:NSUTF8StringEncoding];
            [connection write:data error:&error];
            
            NSString *receipt = [self createZplReceipt];
            NSLog(@"Receipt ZPL Format: %@", receipt);
            NSMutableData *data1 = [[NSMutableData alloc] initWithData:[receipt dataUsingEncoding:NSUTF8StringEncoding]];
            [self printReceiptAsOneJobUsingNSData:connection withData:data1];
            
        } else {
        }
    } else {
    }
    
    [connection close];
    isPrinting = NO;
}

-(NSString*)createZplReceipt {
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    
    NSString *recipeHeight = @"570";
    
    NSString *transactionDate = @"";
    NSString *transactionCardNumber = @"";
    NSString *transactionReferenceNumber = @"";
    NSString *transactionAuthorizationNumber = @"";
    NSString *transactionBillNumber = @"";
    NSString *transactionAmount = @"";
    NSString *transactionType = @"";
    NSString *subtotalAmount = @"";
    NSString *taxesAmount = @"";
    NSString *tipAmount = @"";
    
    TransactionInfo *transactionInfo = userInfo.sessionInfo.currentTransactionInfo;
    if (transactionRecord == nil){
        // If transactionRecord is Nil it means that we are requesting a voucher for the transaction that the user just did a moment ago.
        if ([transactionTypeId isEqualToString:SaleTransactionTypeId] || [transactionTypeId isEqualToString:RefundTransactionTypeId] || [transactionTypeId isEqualToString:VoidTransactionTypeId] || [transactionTypeId isEqualToString:TipAdjustementTransactionTypeId]){
            transactionCardNumber = transactionInfo.creditCardInfo.creditCardNumberMasked;
            transactionReferenceNumber = transactionInfo.transactionResult.referenceNumber;
            transactionAuthorizationNumber = transactionInfo.transactionResult.authorizationNumber;
            transactionBillNumber = transactionInfo.transactionResult.invoice;
            transactionDate = transactionInfo.transactionResult.transactionDateAndTimeWithFormat;
            transactionAmount = transactionInfo.transactionResult.salesAmountWithFormat;
            transactionRecordCurrency = transactionInfo.affiliate.currencyCode;
            
            if ([transactionTypeId isEqualToString:SaleTransactionTypeId] || [transactionTypeId isEqualToString:TipAdjustementTransactionTypeId]){
                SaleTransactionInfo *saleTransactionInfo = (SaleTransactionInfo *)transactionInfo;
                subtotalAmount = saleTransactionInfo.amountWithFormat;
                taxesAmount = [NSString stringWithFormat:@"%@", saleTransactionInfo.taxAmountWithFormat];
                tipAmount = [NSString stringWithFormat:@"%@", saleTransactionInfo.tipAmountWithFormat];
            }else if ([transactionTypeId isEqualToString:RefundTransactionTypeId]){
                transactionType = @"***DEVOLUCIÓN***";
                recipeHeight = @"480";
            }else if ([transactionTypeId isEqualToString:VoidTransactionTypeId]){
                transactionType = @"***ANULACIÓN***";
                recipeHeight = @"480";
            }
        }
    }else{
        // If the TransacationRecord in not null, it means the voucher it from a transaction already stored in the backend
        /*NSString *creditCardLastDigits = @"";
        if (transactionRecord.creditCardLastDigits != nil){
            creditCardLastDigits = transactionRecord.creditCardLastDigits;
        }
        transactionCardNumber = [NSString stringWithFormat:@"************%@", creditCardLastDigits];*/
        transactionCardNumber = transactionRecord.maskedCreditCard;
        transactionReferenceNumber = transactionRecord.saleReferenceNumber;
        transactionAuthorizationNumber = transactionRecord.saleAuthorizationNumber;
        transactionBillNumber = transactionRecord.saleInvoice;
        transactionDate = transactionRecord.transactionDateAndTimeWithFormat;
        transactionAmount = transactionRecord.saleAmountWithFormat;
        
        
        if ([transactionTypeId isEqualToString:SaleTransactionTypeId] || [transactionTypeId isEqualToString:TipAdjustementTransactionTypeId]){
            subtotalAmount = transactionRecord.subTotalSaleAmountWithFormat;
            taxesAmount = transactionRecord.taxAmountWithFormat;
            tipAmount = transactionRecord.tipAmountWithFormat;
        }else if ([transactionTypeId isEqualToString:VoidTransactionTypeId]){
            transactionType = @"***ANULACIÓN***";
            recipeHeight = @"480";
        }else if ([transactionTypeId isEqualToString:RefundTransactionTypeId]){
            transactionType = @"***DEVOLUCIÓN***";
            recipeHeight = @"480";
        }
    }
    
    // Remove the Accents of the transactionType for printing the recipe
    //transactionType = [transactionType stringByFoldingWithOptions:NSDiacriticInsensitiveSearch locale:[NSLocale localeWithLocaleIdentifier:@"en_US"]];
    
    /*
     Some basics of ZPL. Find more information here : http://www.zebra.com/content/dam/zebra/manuals/en-us/printer/zplii-pm-vol2-en.pdf
     
     ^XA indicates the beginning of a label
     ^PW sets the width of the label (in dots)
     ^MNN sets the printer in continuous mode (variable length receipts only make sense with variably sized labels)
     ^LL sets the length of the label (we calculate this value at the end of the routine)
     ^LH sets the reference axis for printing.
     You will notice we change this positioning of the 'Y' axis (length) as we build up the label. Once the positioning is changed, all new fields drawn on the label are rendered as if '0' is the new home position
     ^FO sets the origin of the field relative to Label Home ^LH
     ^A sets font information
     ^FD is a field description
     ^GB is graphic boxes (or lines)
     ^B sets barcode information
     ^XZ indicates the end of a label
     ^FH before an ^FD indicates that the ^FD can contain values in HEX (for accents, for example), with an _. Example, _A0 es á
     */

    // Header
    //NSString *zplTemplate =  [NSString stringWithFormat:@"^XA^CF0,23,23^LH10,70^LL480" \
    
    int totalAmountLabelLocationY = 330;
    int clientCopyLabelLocationY = 385;
    
    NSMutableString *zplTemplate =  [NSMutableString stringWithFormat:@"^XA^CF0,23,23^LH10,70^LL%@" \
    
    //  Credomatic Title
    @"^AS,,40,40"   \
    @"^FB350,2,,C" \
    @"^FH^FDCredomatic" \
    @"^FS" \
                              
    //  Commerce Title
    @"^FO0,40" \
    @"^AP,,30,30"   \
    @"^FB350,3,,C" \
    @"^FH^FD%@" \
    @"^FS" \
    
    // Terminal ID
    @"^FO0,120" \
    @"^FB200,1,,L" \
    @"^FH^FDTerminal ID:" \
    @"^FS" \
    
    @"^FO200,120" \
    @"^FB150,1,,R" \
    @"^FH^FD%@" \
    @"^FS" \
    
    // Date
    @"^FO0,150"
    @"^FB200,1,,L" \
    @"^FH^FDFecha:" \
    @"^FS" \
    
    @"^FO100,150"
    @"^FB250,1,,R" \
    @"^FH^FD%@" \
    @"^FS" \
    
    // Card Number
    @"^FO0,180"
    @"^FB200,1,,L" \
    @"^FH^FD# Tarjeta:" \
    @"^FS" \
    
    @"^FO100,180"
    @"^FB250,1,,R" \
    @"^FH^FD%@" \
    @"^FS" \
    
    // Reference Number
    @"^FO0,210"
    @"^FB200,1,,L" \
    @"^FH^FDReferencia:" \
    @"^FS" \
    
    @"^FO200,210"
    @"^FB150,1,,R" \
    @"^FH^FD%@" \
    @"^FS" \
    
    // Authorization Number
    @"^FO0,240"
    @"^FB200,1,,L" \
    @"^FH^FD%@" \
    @"^FS" \
    
    @"^FO200,240"
    @"^FB150,1,,R" \
    @"^FH^FD%@" \
    @"^FS" \
    
    // Bill Number
    @"^FO0,270"
    @"^FB200,1,,L" \
    @"^FH^FDFactura:" \
    @"^FS" \
    
    @"^FO200,270"
    @"^FB150,1,,R" \
    @"^FH^FD%@" \
    @"^FS"
    
    , recipeHeight, [userInfo.terminalInfo.terminal.branch.name stringWithZPLAccentsInHex], [transactionRecordAffiliateBankTerminal stringWithZPLAccentsInHex], [transactionDate stringWithZPLAccentsInHex], [transactionCardNumber stringWithZPLAccentsInHex], [[transactionReferenceNumber stringByReplacingOccurrencesOfString:@" " withString:@""] stringWithZPLAccentsInHex], [@"Autorización:" stringWithZPLAccentsInHex], [transactionAuthorizationNumber stringWithZPLAccentsInHex], [transactionBillNumber stringWithZPLAccentsInHex]];
    
    if ([transactionTypeId isEqualToString:RefundTransactionTypeId] || [transactionTypeId isEqualToString:VoidTransactionTypeId]){
        // Append the Transaction Type
        
        [zplTemplate appendFormat:
         
         // Transaction Type
         @"^AP,,30,30"   \
         @"^FO,300"   \
         @"^FB350,2,,C" \
         @"^FH^FD%@" \
         @"^FS", [transactionType stringWithZPLAccentsInHex]];
    }
    
    if([transactionTypeId isEqualToString:SaleTransactionTypeId] || [transactionTypeId isEqualToString:TipAdjustementTransactionTypeId]){
        // Print the Subtotal, Taxes and Tip values
        
        [zplTemplate appendFormat:
         
         // Subtotal Number
         @"^FO0,300"
         @"^FB200,1,,L" \
         @"^FH^FDVenta:" \
         @"^FS" \
         
         @"^FO200,300"
         @"^FB150,1,,R" \
         @"^FH^FD%@ %@" \
         @"^FS", [subtotalAmount stringWithZPLAccentsInHex], [transactionRecordCurrency stringWithZPLAccentsInHex]];
        
        [zplTemplate appendFormat:
         
         // Taxes Amount
         @"^FO0,330"
         @"^FB200,1,,L" \
         @"^FH^FDImpuestos:" \
         @"^FS" \
         
         @"^FO200,330"
         @"^FB150,1,,R" \
         @"^FH^FD%@ %@" \
         @"^FS", [taxesAmount stringWithZPLAccentsInHex], [transactionRecordCurrency stringWithZPLAccentsInHex]];
        
        [zplTemplate appendFormat:
         
         // Tips Amount
         @"^FO0,360"
         @"^FB200,1,,L" \
         @"^FH^FDPropina:" \
         @"^FS" \
         
         @"^FO200,360"
         @"^FB150,1,,R" \
         @"^FH^FD%@ %@" \
         @"^FS", [tipAmount stringWithZPLAccentsInHex], [transactionRecordCurrency stringWithZPLAccentsInHex]];
        
        totalAmountLabelLocationY += 90;
        clientCopyLabelLocationY += 90;
        
    }
    
    // Append the rest of the recipe
    
    [zplTemplate appendFormat:
     
     // Amount
     @"^FO0,%d"
     @"^FB200,1,,L" \
     @"^FH^FDTotal:" \
     @"^FS" \
     
     @"^AU,,35,35"   \
     @"^FO75,%d"
     @"^FB275,1,,R" \
     @"^FH^FD%@ %@" \
     @"^FS" \
     
     //  Customer Copy Label
     @"^AP,,30,30"   \
     @"^FO,%d"   \
     @"^FB350,2,,C" \
     @"^FH^FD*** Copia Cliente ***" \
     @"^FS" \
     
     @"^XZ", totalAmountLabelLocationY, totalAmountLabelLocationY, [transactionAmount stringWithZPLAccentsInHex], transactionRecordCurrency, clientCopyLabelLocationY];
    
    return zplTemplate;
}

-(void)printReceiptAsOneJobUsingNSData:(id<NSObject,ZebraPrinterConnection>)connection withData:(NSMutableData*)fullLabel {
    /*
     Sending large amounts of data in a single write command can overflow the NSStream buffers which are the underlying mechanism used by the SDK to communicate with the printers.
     This method shows one way to break up large data into smaller chunks to send to the printer
     */
    NSError *error = nil;
    
    int blockSize = 1024;
    int totalSize = fullLabel.length;
    int bytesRemaining = totalSize;
    
    while (bytesRemaining > 0) {
        int bytesToSend = MIN(blockSize, bytesRemaining);
        NSRange range = NSMakeRange(0, bytesToSend);
        
        NSData *partialLabel = [fullLabel subdataWithRange:range];
        [connection write:partialLabel error:&error];
        
        bytesRemaining -= bytesToSend;
        
        [fullLabel replaceBytesInRange:range withBytes:NULL length:0];
    }
    if(error != nil) {
    }
}


-(void)printReceiptAsOneJobUsingNSString:(id<NSObject,ZebraPrinter>)printer withString:(NSMutableString*)fullLabel {
    /*
     Sending large amounts of data in a single write command can overflow the NSStream buffers which are the underlying mechanism used by the SDK to communicate with the printers.
     This method shows one way to break up large strings into smaller chunks to send to the printer
     */
    NSError *error = nil;
    
    int blockSize = 1024;
    int totalSize = fullLabel.length;
    int bytesRemaining = totalSize;
    
    while (bytesRemaining > 0) {
        int bytesToSend = MIN(blockSize, bytesRemaining);
        NSRange range = NSMakeRange(0, bytesToSend);
        
        NSString *partialLabel = [fullLabel substringWithRange:range];
        
        [[printer getToolsUtil] sendCommand:partialLabel error:&error];
        
        bytesRemaining -= bytesToSend;
        
        [fullLabel deleteCharactersInRange:range];
        
    }
    if(error != nil) {
        NSLog(@"Error Printing");
    }
}

#pragma mark - UITextField Delegate Methods

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    
    if (textField.tag == EmailTextFieldTag){
        [self checkParameters:newString];
    }
    
    return YES;
}

- (BOOL)textFieldShouldClear:(UITextField *)textField{
    
    if (textField.tag == EmailTextFieldTag){
        [self checkParameters:@""];
    }
    
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    activeField = textField;
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    activeField = nil;
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    if (textField.tag == EmailTextFieldTag){
        if (sendButton.enabled == true){
            [self sendButtonTouchUpInside:sendButton];
        }
    }
    
    return YES;
}

#pragma mark SalesManagerDelegate Methods

- (void)sendEmailSaleReceiptResponseReceived:(BOOL)sendEmailReceiptResult error:(NSError *)error{
    self.HUD.mode = MBProgressHUDModeCustomView;
    self.HUD.customView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"37x-Checkmark"]];
    self.HUD.labelText = @"Recibo enviado con éxito";
    [self.HUD hide:YES afterDelay:2];
    //NSLog(@"SendEmailReceiptResult: %d", sendEmailReceiptResult);
    
    if (sendEmailReceiptResult){
        UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
        
        NSString *locayticsEventName = LocalyticsEventNameSendVoucherEmail;
        if (transactionRecord != nil){
            locayticsEventName = LocalyticsEventNameReSendVoucherEmail;
        }
        // Log Localytics event
        NSDictionary *dictionary =
        [NSDictionary dictionaryWithObjectsAndKeys:
         userInfo.terminalId,
         LocalyticsEventParameterNameTerminalId,
         userInfo.sessionInfo.sessionUserName,
         LocalyticsEventParameterNameUser,
         nil];
        
        [[LocalyticsSession shared] tagEvent:locayticsEventName attributes:dictionary];
        
        emailTextField.text = @"";
        [self checkParameters:emailTextField.text];
        
        [self.viewDeckController closeRightViewAnimated:YES];
    }else{
        if (![super checkSessionExpiration:error]){
            UIAlertView *errorAlertView = [[UIAlertView alloc] initWithTitle:@"Enviar Recibo" message:error.localizedDescription delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
            errorAlertView.delegate = self;
            errorAlertView.tag = ErrorAlertViewTag;
            [errorAlertView show];
        }
    }
}

#pragma mark IIViewDeckControllerDelegate Methods

-(void)viewDeckController:(IIViewDeckController *)viewDeckController willCloseViewSide:(IIViewDeckSide)viewDeckSide animated:(BOOL)animated{
    if (viewDeckSide == IIViewDeckRightSide){
        [self.view endEditing:YES];
    }
}

@end
