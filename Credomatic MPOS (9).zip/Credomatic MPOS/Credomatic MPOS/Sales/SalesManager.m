/*
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  SalesManager.m
//  Zimple POS
//

#import "SalesManager.h"

#define SuppressPerformSelectorLeakWarning(Stuff) \
do { \
_Pragma("clang diagnostic push") \
_Pragma("clang diagnostic ignored \"-Warc-performSelector-leaks\"") \
Stuff; \
_Pragma("clang diagnostic pop") \
} while (0)

@implementation SalesManager

@synthesize salesManagerDelegate;
@synthesize ackContinueSelector;

- (void)makeSale:(NSString *)cardPayload amount:(NSString *)amount affiliate:(Affiliate *)affiliate location:(CLLocationCoordinate2D)location taxAmount:(NSString *)taxAmount tipAmount:(NSString *)tipAmount{
    /*
     The Sale Process is (Make a Sale and dont send the ACK):
     
     1 - Send the sale request.
     2 - Parse the sale response
     */
    
    // 1
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    ZimpleServices *zimpleServices = [[ZimpleServices alloc] init];
    zimpleServices.zimpleBackendServicesDelegate = self;
    ackContinueSelector = nil;
    NSString *latitude = @"";
    NSString *longitude = @"";
    if (CLLocationCoordinate2DIsValid(location)) {
        //NSLog(@"Coordinate valid");
        latitude = [NSString stringWithFormat:@"%f",location.latitude];
        longitude = [NSString stringWithFormat:@"%f",location.longitude];
    } else {
        //NSLog(@"Coordinate invalid");
    }
    [zimpleServices sale:userInfo.terminalId sessionkey:userInfo.sessionInfo.sessionKey cardPayload:cardPayload saleAmount:amount affiliatedId:affiliate.bankTerminalId latitude:latitude longitude:longitude taxAmount:taxAmount tipAmount:tipAmount];
}

- (void)makeAndFinishSale:(NSString *)cardPayload amount:(NSString *)amount affiliate:(Affiliate *)affiliate location:(CLLocationCoordinate2D)location taxAmount:(NSString *)taxAmount tipAmount:(NSString *)tipAmount{
    /*
     The Sale Process is:
     
     1 - Send the sale request.
     2 - Parse the sale response
     3 - If successful, send the ACK request
     */
    
    // 1
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    ZimpleServices *zimpleServices = [[ZimpleServices alloc] init];
    zimpleServices.zimpleBackendServicesDelegate = self;
    ackContinueSelector = @selector(saleAckResponsedReceived:error:);
    NSString *latitude = @"";
    NSString *longitude = @"";
    if (CLLocationCoordinate2DIsValid(location)) {
        //NSLog(@"Coordinate valid");
        latitude = [NSString stringWithFormat:@"%f",location.latitude];
        longitude = [NSString stringWithFormat:@"%f",location.longitude];
    } else {
        //NSLog(@"Coordinate invalid");
    }
    [zimpleServices sale:userInfo.terminalId sessionkey:userInfo.sessionInfo.sessionKey cardPayload:cardPayload saleAmount:amount affiliatedId:affiliate.bankTerminalId latitude:latitude longitude:longitude taxAmount:taxAmount tipAmount:tipAmount];
}

- (void)sendACK:(NSString *)transactionId{
    //NSLog(@"Sending ACK for Transaction: %@", transactionId);
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    ZimpleServices *zimpleServices = [[ZimpleServices alloc] init];
    zimpleServices.zimpleBackendServicesDelegate = self;
    [zimpleServices ack:userInfo.terminalId sessionkey:userInfo.sessionInfo.sessionKey transactionId:transactionId];
}

- (void)registerSignatureAndFinishTransaction:(TransactionResult *)transactionResult signature:(NSString *)signature{
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    ZimpleServices *zimpleServices = [[ZimpleServices alloc] init];
    zimpleServices.zimpleBackendServicesDelegate = self;
    ackContinueSelector = @selector(signatureAckResponsedReceived:error:);
    self.transactionResult = transactionResult;
    [zimpleServices registerSignature:userInfo.terminalId sessionkey:userInfo.sessionInfo.sessionKey transactionId:transactionResult.zimpleTransactionId signatureBase64:signature];
}

- (void)sendEmailSaleReceipt:(NSString *)transactionId email:(NSString *)email{
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    ZimpleServices *zimpleServices = [[ZimpleServices alloc] init];
    zimpleServices.zimpleBackendServicesDelegate = self;
    [zimpleServices sendEmailReceipt:userInfo.terminalId sessionkey:userInfo.sessionInfo.sessionKey transactionId:transactionId email:email];
}

- (void)saleAckResponsedReceived:(BOOL)saleMade error:(NSError *)error{
    if (saleMade){
        [salesManagerDelegate saleResponseReceived:self.transactionResult error:nil];
    }else{
        [salesManagerDelegate saleResponseReceived:nil error:error];
    }
}

- (void)signatureAckResponsedReceived:(BOOL)signatureAckMade error:(NSError *)error{
    if (signatureAckMade){
        [salesManagerDelegate registerSignatureResponseReceived:YES error:nil];
    }else{
        [salesManagerDelegate registerSignatureResponseReceived:NO error:error];
    }
}


- (void)settleTerminal:(Affiliate *)affiliate{
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    ZimpleServices *zimpleServices = [[ZimpleServices alloc] init];
    zimpleServices.zimpleBackendServicesDelegate = self;
    [zimpleServices terminalSettlement:userInfo.terminalId sessionkey:userInfo.sessionInfo.sessionKey bankTerminalAffiliate:affiliate.bankTerminalId];
}

- (void)getVoidableTransactions{
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    ZimpleServices *zimpleServices = [[ZimpleServices alloc] init];
    zimpleServices.zimpleBackendServicesDelegate = self;
    [zimpleServices voidableTransactionsList:userInfo.terminalId sessionkey:userInfo.sessionInfo.sessionKey];
}

- (void)voidTransaction:(TransactionRecord *)transactionRecord{
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    ZimpleServices *zimpleServices = [[ZimpleServices alloc] init];
    zimpleServices.zimpleBackendServicesDelegate = self;
    ackContinueSelector = @selector(voidAckResponsedReceived:error:);
    NSString *latitude = @"";
    NSString *longitude = @"";
    if (CLLocationCoordinate2DIsValid(userInfo.userLocation.coordinate)) {
        //NSLog(@"Coordinate valid");
        latitude = [NSString stringWithFormat:@"%f",userInfo.userLocation.coordinate.latitude];
        longitude = [NSString stringWithFormat:@"%f",userInfo.userLocation.coordinate.longitude];
    } else {
        //NSLog(@"Coordinate invalid");
    }
    [zimpleServices voidTransaction:userInfo.terminalId sessionkey:userInfo.sessionInfo.sessionKey transactionId:transactionRecord.zimpleTransactionId latitude:latitude longitude:longitude  voidAsUser:@"" voidAsUserPIN:@""];
}

- (void)voidTransaction:(TransactionRecord *)transactionRecord username:(NSString *)username userPIN:(NSString *)userPIN{
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    ZimpleServices *zimpleServices = [[ZimpleServices alloc] init];
    zimpleServices.zimpleBackendServicesDelegate = self;
    ackContinueSelector = @selector(voidAckResponsedReceived:error:);
    NSString *latitude = @"";
    NSString *longitude = @"";
    if (CLLocationCoordinate2DIsValid(userInfo.userLocation.coordinate)) {
        //NSLog(@"Coordinate valid");
        latitude = [NSString stringWithFormat:@"%f",userInfo.userLocation.coordinate.latitude];
        longitude = [NSString stringWithFormat:@"%f",userInfo.userLocation.coordinate.longitude];
    } else {
        //NSLog(@"Coordinate invalid");
    }
    [zimpleServices voidTransaction:userInfo.terminalId sessionkey:userInfo.sessionInfo.sessionKey transactionId:transactionRecord.zimpleTransactionId latitude:latitude longitude:longitude  voidAsUser:username voidAsUserPIN:userPIN];
}

- (void)voidAckResponsedReceived:(BOOL)voidMade error:(NSError *)error{
    if (voidMade){
        [salesManagerDelegate voidTransactionResponseReceived:self.transactionResult error:nil];
    }else{
        [salesManagerDelegate voidTransactionResponseReceived:nil error:error];
    }
}

- (void)getTransactionsList:(NSDate *)startDate endDate:(NSDate *)endDate transactionType:(NSString *)transactionType{
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    ZimpleServices *zimpleServices = [[ZimpleServices alloc] init];
    zimpleServices.zimpleBackendServicesDelegate = self;
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSString *startDateFormattedString = @"";
    NSString *endDateFormattedString = @"";
    if (startDate != nil){
        startDateFormattedString = [dateFormatter stringFromDate:startDate];
        //NSLog(@"Start Date: %@", startDateFormattedString);
    }
    if (endDate != nil){
        endDateFormattedString = [dateFormatter stringFromDate:endDate];
        //NSLog(@"End Date: %@", endDateFormattedString);
    }
    [zimpleServices transactionsList:userInfo.terminalId sessionkey:userInfo.sessionInfo.sessionKey startDate:startDateFormattedString endDate:endDateFormattedString transactionType:transactionType];
}

- (void)makeRefund:(NSString *)cardPayload amount:(NSString *)amount affiliate:(Affiliate *)affiliate location:(CLLocationCoordinate2D)location{
    /*
     The Refund Process is (Make a Refund and dont send the ACK):
     
     1 - Send the refund request.
     2 - Parse the refund response
     */
    
    // 1
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    ZimpleServices *zimpleServices = [[ZimpleServices alloc] init];
    zimpleServices.zimpleBackendServicesDelegate = self;
    ackContinueSelector = nil;
    NSString *latitude = @"";
    NSString *longitude = @"";
    if (CLLocationCoordinate2DIsValid(location)) {
        //NSLog(@"Coordinate valid");
        latitude = [NSString stringWithFormat:@"%f",location.latitude];
        longitude = [NSString stringWithFormat:@"%f",location.longitude];
    } else {
        //NSLog(@"Coordinate invalid");
    }
    [zimpleServices refund:userInfo.terminalId sessionkey:userInfo.sessionInfo.sessionKey cardPayload:cardPayload refundAmount:amount affiliatedId:affiliate.bankTerminalId latitude:latitude longitude:longitude refundAsUser:@"" refundAsUserPIN:@""];
}

- (void)makeRefund:(NSString *)cardPayload amount:(NSString *)amount affiliate:(Affiliate *)affiliate location:(CLLocationCoordinate2D)location username:(NSString *)username userPIN:(NSString *)userPIN{
    /*
     The Refund Process is (Make a Refund and dont send the ACK):
     
     1 - Send the refund request.
     2 - Parse the refund response
     */
    
    // 1
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    ZimpleServices *zimpleServices = [[ZimpleServices alloc] init];
    zimpleServices.zimpleBackendServicesDelegate = self;
    ackContinueSelector = nil;
    NSString *latitude = @"";
    NSString *longitude = @"";
    if (CLLocationCoordinate2DIsValid(location)) {
        //NSLog(@"Coordinate valid");
        latitude = [NSString stringWithFormat:@"%f",location.latitude];
        longitude = [NSString stringWithFormat:@"%f",location.longitude];
    } else {
        //NSLog(@"Coordinate invalid");
    }
    [zimpleServices refund:userInfo.terminalId sessionkey:userInfo.sessionInfo.sessionKey cardPayload:cardPayload refundAmount:amount affiliatedId:affiliate.bankTerminalId latitude:latitude longitude:longitude refundAsUser:username refundAsUserPIN:userPIN];
}

- (void)makeAndFinishRefund:(NSString *)cardPayload amount:(NSString *)amount affiliate:(Affiliate *)affiliate location:(CLLocationCoordinate2D)location{
    /*
     The Refund Process is (Make a Refund and dont send the ACK):
     
     1 - Send the refund request.
     2 - Parse the refund response
     3 - If successful, send the ACK request
     */
    
    // 1
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    ZimpleServices *zimpleServices = [[ZimpleServices alloc] init];
    zimpleServices.zimpleBackendServicesDelegate = self;
    ackContinueSelector = @selector(refundAckResponsedReceived:error:);
    NSString *latitude = @"";
    NSString *longitude = @"";
    if (CLLocationCoordinate2DIsValid(location)) {
        //NSLog(@"Coordinate valid");
        latitude = [NSString stringWithFormat:@"%f",location.latitude];
        longitude = [NSString stringWithFormat:@"%f",location.longitude];
    } else {
        //NSLog(@"Coordinate invalid");
    }
    [zimpleServices refund:userInfo.terminalId sessionkey:userInfo.sessionInfo.sessionKey cardPayload:cardPayload refundAmount:amount affiliatedId:affiliate.bankTerminalId latitude:latitude longitude:longitude refundAsUser:@"" refundAsUserPIN:@""];
    
}

- (void)refundAckResponsedReceived:(BOOL)refundMade error:(NSError *)error{
    if (refundMade){
        [salesManagerDelegate refundResponseReceived:self.transactionResult error:nil];
    }else{
        [salesManagerDelegate refundResponseReceived:nil error:error];
    }
}

- (void)adjustTransactionTip:(TransactionRecord *)transactionRecord affiliate:(Affiliate *)affiliate tipNewAmount:(NSString *)tipNewAmount{
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    ZimpleServices *zimpleServices = [[ZimpleServices alloc] init];
    zimpleServices.zimpleBackendServicesDelegate = self;
    ackContinueSelector = @selector(adjustTipAckResponsedReceived:error:);
    NSString *latitude = @"";
    NSString *longitude = @"";
    if (CLLocationCoordinate2DIsValid(userInfo.userLocation.coordinate)) {
        //NSLog(@"Coordinate valid");
        latitude = [NSString stringWithFormat:@"%f",userInfo.userLocation.coordinate.latitude];
        longitude = [NSString stringWithFormat:@"%f",userInfo.userLocation.coordinate.longitude];
    } else {
        //NSLog(@"Coordinate invalid");
    }
    [zimpleServices adjustTransactionTip:userInfo.terminalId sessionkey:userInfo.sessionInfo.sessionKey transactionId:transactionRecord.zimpleTransactionId latitude:latitude longitude:longitude adjustTipAsUser:@"" adjustTipAsUserPIN:@"" tipAmount:tipNewAmount affiliate:affiliate.bankTerminalId];
}

- (void)adjustTransactionTip:(TransactionRecord *)transactionRecord affiliate:(Affiliate *)affiliate tipNewAmount:(NSString *)tipNewAmount username:(NSString *)username userPIN:(NSString *)userPIN{
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    ZimpleServices *zimpleServices = [[ZimpleServices alloc] init];
    zimpleServices.zimpleBackendServicesDelegate = self;
    ackContinueSelector = @selector(adjustTipAckResponsedReceived:error:);
    NSString *latitude = @"";
    NSString *longitude = @"";
    if (CLLocationCoordinate2DIsValid(userInfo.userLocation.coordinate)) {
        //NSLog(@"Coordinate valid");
        latitude = [NSString stringWithFormat:@"%f",userInfo.userLocation.coordinate.latitude];
        longitude = [NSString stringWithFormat:@"%f",userInfo.userLocation.coordinate.longitude];
    } else {
        //NSLog(@"Coordinate invalid");
    }
    [zimpleServices adjustTransactionTip:userInfo.terminalId sessionkey:userInfo.sessionInfo.sessionKey transactionId:transactionRecord.zimpleTransactionId latitude:latitude longitude:longitude adjustTipAsUser:username adjustTipAsUserPIN:userPIN tipAmount:tipNewAmount affiliate:affiliate.bankTerminalId];
}

- (void)adjustTipAckResponsedReceived:(BOOL)voidMade error:(NSError *)error{
    if (voidMade){
        [salesManagerDelegate tipAdjustementTransactionResponseReceived:self.transactionResult error:nil];
    }else{
        [salesManagerDelegate tipAdjustementTransactionResponseReceived:nil error:error];
    }
}


#pragma mark ZimpleBackendServicesDelegate Methods

- (void)saleResponseReceived:(NSData *)responseData error:(NSError *)error{
    if (responseData != nil){
        NSError *myError;
        if (error == nil){
            NSDictionary* json = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONWritingPrettyPrinted error:&myError];
            
            NSString *messageEncryptedData = [json objectForKey:MessageResponseParameterName];
            //NSLog(@"MessageEncryptedData: %@",messageEncryptedData);
            
            NSString *decryptedJSONString = [EncryptionHelper decryptUsingSymmetricAES256:messageEncryptedData];
            //NSLog(@"Decrypted Response: %@", decryptedJSONString);
            
            NSData *decryptedJSONData = [decryptedJSONString dataUsingEncoding:NSUTF8StringEncoding];
            NSDictionary *jsonMessage = [NSJSONSerialization JSONObjectWithData:decryptedJSONData options:NSJSONWritingPrettyPrinted error:nil];
            
            
            NSNumber *reasonCode = [jsonMessage objectForKey:ReasonCodeResponseParameterName];
            NSLog(@"Reason Code: %@", reasonCode);
            
            if (reasonCode.intValue == 0){
                self.transactionResult = [[TransactionResult alloc] initWithDictionary:jsonMessage error:nil];
                //NSLog(@"Zimple Transaction Id: %@", self.transactionResult.zimpleTransactionId);
                if (ackContinueSelector != nil){
                    // If the sale is successful and theres is a ackContinueSelector, send an ACK to the server
                    [self sendACK:self.transactionResult.zimpleTransactionId];
                }else{
                    // Sale successful and No ACKContinueSelector
                    [salesManagerDelegate saleResponseReceived:self.transactionResult error:nil];
                }
                return;
            }
        }
    }
    
    NSMutableDictionary *details = [NSMutableDictionary dictionary];
    //NSString *reasonCodeStr = [NSString stringWithFormat:@"%d", error.code];
    NSString *reasonCodeStr = [error.userInfo objectForKey:NSLocalizedDescriptionKey];
    [details setValue:NSLocalizedString(reasonCodeStr, @"") forKey:NSLocalizedDescriptionKey];
    error = [NSError errorWithDomain:@"Zimple" code:error.code userInfo:details];
    [salesManagerDelegate saleResponseReceived:nil error:error];
}

- (void)ackResponseReceived:(NSData *)responseData error:(NSError *)error{
    if (responseData != nil){
        NSError *myError;
        if (error == nil){
            NSDictionary* json = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONWritingPrettyPrinted error:&myError];
            
            NSString *messageEncryptedData = [json objectForKey:MessageResponseParameterName];
            //NSLog(@"MessageEncryptedData: %@",messageEncryptedData);
            
            NSString *decryptedJSONString = [EncryptionHelper decryptUsingSymmetricAES256:messageEncryptedData];
            //NSLog(@"Decrypted Response: %@", decryptedJSONString);
            
            NSData *decryptedJSONData = [decryptedJSONString dataUsingEncoding:NSUTF8StringEncoding];
            NSDictionary *jsonMessage = [NSJSONSerialization JSONObjectWithData:decryptedJSONData options:NSJSONWritingPrettyPrinted error:nil];
            
            
            NSNumber *reasonCode = [jsonMessage objectForKey:ReasonCodeResponseParameterName];
            //NSLog(@"Reason Code: %@", reasonCode);
            
            if (reasonCode.intValue == 0){
                NSInvocation *anInvocation = [NSInvocation
                                              invocationWithMethodSignature:
                                              [self methodSignatureForSelector:ackContinueSelector]];
                
                [anInvocation setSelector:ackContinueSelector];
                [anInvocation setTarget:self];
                BOOL result = YES;
                [anInvocation setArgument:&result atIndex:2];
                [anInvocation invoke];

            }else{
                myError = [[NSError alloc] initWithDomain:@"Zimple" code:[reasonCode intValue] userInfo:nil];
                //SuppressPerformSelectorLeakWarning([salesManagerDelegate performSelector:ackContinueSelector withObject:NO withObject:myError]);
            }
        }else{
            //SuppressPerformSelectorLeakWarning([salesManagerDelegate performSelector:ackContinueSelector withObject:NO withObject:error]);
        }
    }else{
        //SuppressPerformSelectorLeakWarning([salesManagerDelegate performSelector:ackContinueSelector withObject:NO withObject:error]);
    }
    
}

- (void)registerSignatureResponseReceived:(NSData *)responseData error:(NSError *)error{
    if (responseData != nil){
        NSError *myError;
        if (error == nil){
            NSDictionary* json = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONWritingPrettyPrinted error:&myError];
            
            NSString *messageEncryptedData = [json objectForKey:MessageResponseParameterName];
            //NSLog(@"MessageEncryptedData: %@",messageEncryptedData);
            
            NSString *decryptedJSONString = [EncryptionHelper decryptUsingSymmetricAES256:messageEncryptedData];
            //NSLog(@"Decrypted Response: %@", decryptedJSONString);
            
            NSData *decryptedJSONData = [decryptedJSONString dataUsingEncoding:NSUTF8StringEncoding];
            NSDictionary *jsonMessage = [NSJSONSerialization JSONObjectWithData:decryptedJSONData options:NSJSONWritingPrettyPrinted error:nil];
            
            
            NSNumber *reasonCode = [jsonMessage objectForKey:ReasonCodeResponseParameterName];
            //NSLog(@"Reason Code: %@", reasonCode);
            
            if (reasonCode.intValue == 0){
                // If the signature was registered, send the ACK
                [self sendACK:self.transactionResult.zimpleTransactionId];
                return;
            }
        }
    }
    
    NSMutableDictionary *details = [NSMutableDictionary dictionary];
    //NSString *reasonCodeStr = [NSString stringWithFormat:@"%d", error.code];
    NSString *reasonCodeStr = [error.userInfo objectForKey:NSLocalizedDescriptionKey];
    [details setValue:NSLocalizedString(reasonCodeStr, @"") forKey:NSLocalizedDescriptionKey];
    error = [NSError errorWithDomain:@"Zimple" code:error.code userInfo:details];
    [salesManagerDelegate registerSignatureResponseReceived:NO error:error];
}

- (void)sendEmailReceiptResponseReceived:(NSData *)responseData error:(NSError *)error{
    if (responseData != nil){
        NSError *myError;
        if (error == nil){
            NSDictionary* json = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONWritingPrettyPrinted error:&myError];
            
            NSString *messageEncryptedData = [json objectForKey:MessageResponseParameterName];
            //NSLog(@"MessageEncryptedData: %@",messageEncryptedData);
            
            NSString *decryptedJSONString = [EncryptionHelper decryptUsingSymmetricAES256:messageEncryptedData];
            //NSLog(@"Decrypted Response: %@", decryptedJSONString);
            
            NSData *decryptedJSONData = [decryptedJSONString dataUsingEncoding:NSUTF8StringEncoding];
            NSDictionary *jsonMessage = [NSJSONSerialization JSONObjectWithData:decryptedJSONData options:NSJSONWritingPrettyPrinted error:nil];
            
            
            NSNumber *reasonCode = [jsonMessage objectForKey:ReasonCodeResponseParameterName];
            //NSLog(@"Reason Code: %@", reasonCode);
            if (reasonCode.intValue == 0){
                [salesManagerDelegate sendEmailSaleReceiptResponseReceived:YES error:nil];
                return;
            }
        }
    }
    
    NSMutableDictionary *details = [NSMutableDictionary dictionary];
    //NSString *reasonCodeStr = [NSString stringWithFormat:@"%d", error.code];
    NSString *reasonCodeStr = [error.userInfo objectForKey:NSLocalizedDescriptionKey];
    [details setValue:NSLocalizedString(reasonCodeStr, @"") forKey:NSLocalizedDescriptionKey];
    error = [NSError errorWithDomain:@"Zimple" code:error.code userInfo:details];
    [salesManagerDelegate sendEmailSaleReceiptResponseReceived:NO error:error];
}

- (void)terminalSettlementResponseReceived:(NSData *)responseData error:(NSError *)error{
    if (responseData != nil){
        NSError *myError;
        if (error == nil){
            NSDictionary* json = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONWritingPrettyPrinted error:&myError];
            
            NSString *messageEncryptedData = [json objectForKey:MessageResponseParameterName];
            //NSLog(@"MessageEncryptedData: %@",messageEncryptedData);
            
            NSString *decryptedJSONString = [EncryptionHelper decryptUsingSymmetricAES256:messageEncryptedData];
            //NSLog(@"Decrypted Response: %@", decryptedJSONString);
            
            NSData *decryptedJSONData = [decryptedJSONString dataUsingEncoding:NSUTF8StringEncoding];
            NSDictionary *jsonMessage = [NSJSONSerialization JSONObjectWithData:decryptedJSONData options:NSJSONWritingPrettyPrinted error:nil];
            
            
            NSNumber *reasonCode = [jsonMessage objectForKey:ReasonCodeResponseParameterName];
            //NSLog(@"Reason Code: %@", reasonCode);
            
            if (reasonCode.intValue == 0){
                [salesManagerDelegate settleTerminalResponseReceived:YES error:nil];
                return;
            }
        }
    }
    
    NSMutableDictionary *details = [NSMutableDictionary dictionary];
    //NSString *reasonCodeStr = [NSString stringWithFormat:@"%d", error.code];
    NSString *reasonCodeStr = [error.userInfo objectForKey:NSLocalizedDescriptionKey];
    [details setValue:NSLocalizedString(reasonCodeStr, @"") forKey:NSLocalizedDescriptionKey];
    error = [NSError errorWithDomain:@"Zimple" code:error.code userInfo:details];
    [salesManagerDelegate settleTerminalResponseReceived:NO error:error];
}

- (void)voidableTransactionsListResponseReceived:(NSData *)responseData error:(NSError *)error{
    if (responseData != nil){
        NSError *myError;
        if (error == nil){
            NSDictionary* json = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONWritingPrettyPrinted error:&myError];
            
            NSString *messageEncryptedData = [json objectForKey:MessageResponseParameterName];
            //NSLog(@"MessageEncryptedData: %@",messageEncryptedData);
            
            NSString *decryptedJSONString = [EncryptionHelper decryptUsingSymmetricAES256:messageEncryptedData];
            NSLog(@"Decrypted Response: %@", decryptedJSONString);
            
            NSData *decryptedJSONData = [decryptedJSONString dataUsingEncoding:NSUTF8StringEncoding];
            NSDictionary *jsonMessage = [NSJSONSerialization JSONObjectWithData:decryptedJSONData options:NSJSONWritingPrettyPrinted error:nil];
            
            
            NSNumber *reasonCode = [jsonMessage objectForKey:ReasonCodeResponseParameterName];
            //NSLog(@"Reason Code: %@", reasonCode);
            
            if (reasonCode.intValue == 0){
                NSMutableDictionary *transactionsByAffiliateCode = [[NSMutableDictionary alloc] init];
                NSArray *affiliatesArray = [jsonMessage objectForKey:AffiliatesResponseParameterName];
                for (NSDictionary *affiliateInfo in affiliatesArray) {
                    NSString *affiliateCode = [affiliateInfo objectForKey:AffiliateResponseParameterName];
                    
                    NSArray* transactionsArray = [affiliateInfo objectForKey:TransactionsResponseParameterName];
                    NSMutableArray *affiliateTransactions = [[NSMutableArray alloc] init];
                    for(NSMutableDictionary *transactionDictionary in transactionsArray){
                        TransactionRecord *transactionRecord = [[TransactionRecord alloc] initWithDictionary:transactionDictionary error:nil];
                        [affiliateTransactions addObject:transactionRecord];
                    }
                    [transactionsByAffiliateCode setObject:affiliateTransactions forKey:affiliateCode];
                }
                [salesManagerDelegate getVoidableTransactionsResponseReceived:transactionsByAffiliateCode error:nil];
                return;
            }
        }
    }
    
    NSMutableDictionary *details = [NSMutableDictionary dictionary];
    //NSString *reasonCodeStr = [NSString stringWithFormat:@"%d", error.code];
    NSString *reasonCodeStr = [error.userInfo objectForKey:NSLocalizedDescriptionKey];
    [details setValue:NSLocalizedString(reasonCodeStr, @"") forKey:NSLocalizedDescriptionKey];
    error = [NSError errorWithDomain:@"Zimple" code:error.code userInfo:details];
    [salesManagerDelegate getVoidableTransactionsResponseReceived:nil error:error];
}

- (void)voidTransactionResponseReceived:(NSData *)responseData error:(NSError *)error{
    if (responseData != nil){
        NSError *myError;
        if (error == nil){
            NSDictionary* json = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONWritingPrettyPrinted error:&myError];
            
            NSString *messageEncryptedData = [json objectForKey:MessageResponseParameterName];
            //NSLog(@"MessageEncryptedData: %@",messageEncryptedData);
            
            NSString *decryptedJSONString = [EncryptionHelper decryptUsingSymmetricAES256:messageEncryptedData];
            //NSLog(@"Decrypted Response: %@", decryptedJSONString);
            
            NSData *decryptedJSONData = [decryptedJSONString dataUsingEncoding:NSUTF8StringEncoding];
            NSDictionary *jsonMessage = [NSJSONSerialization JSONObjectWithData:decryptedJSONData options:NSJSONWritingPrettyPrinted error:nil];
            
            
            NSNumber *reasonCode = [jsonMessage objectForKey:ReasonCodeResponseParameterName];
            //NSLog(@"Reason Code: %@", reasonCode);
            
            if (reasonCode.intValue == 0){
                self.transactionResult = [[TransactionResult alloc] initWithDictionary:jsonMessage error:nil];
                [salesManagerDelegate voidTransactionResponseReceived:self.transactionResult error:nil];
                return;
            }
        }
    }
    
    NSMutableDictionary *details = [NSMutableDictionary dictionary];
    //NSString *reasonCodeStr = [NSString stringWithFormat:@"%d", error.code];
    NSString *reasonCodeStr = [error.userInfo objectForKey:NSLocalizedDescriptionKey];
    [details setValue:NSLocalizedString(reasonCodeStr, @"") forKey:NSLocalizedDescriptionKey];
    error = [NSError errorWithDomain:@"Zimple" code:error.code userInfo:details];
    [salesManagerDelegate voidTransactionResponseReceived:NO error:error];
}

- (void)transactionsListResponseReceived:(NSData *)responseData error:(NSError *)error{
    if (responseData != nil){
        NSError *myError;
        if (error == nil){
            NSDictionary* json = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONWritingPrettyPrinted error:&myError];
            
            NSString *messageEncryptedData = [json objectForKey:MessageResponseParameterName];
            //NSLog(@"MessageEncryptedData: %@",messageEncryptedData);
            
            NSString *decryptedJSONString = [EncryptionHelper decryptUsingSymmetricAES256:messageEncryptedData];
            NSLog(@"Decrypted Response: %@", decryptedJSONString);
            
            NSData *decryptedJSONData = [decryptedJSONString dataUsingEncoding:NSUTF8StringEncoding];
            NSDictionary *jsonMessage = [NSJSONSerialization JSONObjectWithData:decryptedJSONData options:NSJSONWritingPrettyPrinted error:nil];
            
            
            NSNumber *reasonCode = [jsonMessage objectForKey:ReasonCodeResponseParameterName];
            //NSLog(@"Reason Code: %@", reasonCode);
            
            if (reasonCode.intValue == 0){
                NSMutableDictionary *transactionsByAffiliateCode = [[NSMutableDictionary alloc] init];
                NSArray *affiliatesArray = [jsonMessage objectForKey:AffiliatesResponseParameterName];
                for (NSDictionary *affiliateInfo in affiliatesArray) {
                    NSString *affiliateCode = [affiliateInfo objectForKey:AffiliateResponseParameterName];
                    
                    NSArray* transactionsArray = [affiliateInfo objectForKey:TransactionsResponseParameterName];
                    NSMutableArray *affiliateTransactions = [[NSMutableArray alloc] init];
                    for(NSMutableDictionary *transactionDictionary in transactionsArray){
                        TransactionRecord *transactionRecord = [[TransactionRecord alloc] initWithDictionary:transactionDictionary error:nil];
                        [affiliateTransactions addObject:transactionRecord];
                    }
                    [transactionsByAffiliateCode setObject:affiliateTransactions forKey:affiliateCode];
                }
                [salesManagerDelegate getTransactionsListResponseReceived:transactionsByAffiliateCode error:nil];
                return;
            }
        }
    }

    NSMutableDictionary *details = [NSMutableDictionary dictionary];
    //NSString *reasonCodeStr = [NSString stringWithFormat:@"%d", error.code];
    NSString *reasonCodeStr = [error.userInfo objectForKey:NSLocalizedDescriptionKey];
    [details setValue:NSLocalizedString(reasonCodeStr, @"") forKey:NSLocalizedDescriptionKey];
    error = [NSError errorWithDomain:@"Zimple" code:error.code userInfo:details];
    [salesManagerDelegate getTransactionsListResponseReceived:nil error:error];
}

- (void)refundResponseReceived:(NSData *)responseData error:(NSError *)error{
    if (responseData != nil){
        NSError *myError;
        if (error == nil){
            NSDictionary* json = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONWritingPrettyPrinted error:&myError];
            
            NSString *messageEncryptedData = [json objectForKey:MessageResponseParameterName];
            //NSLog(@"MessageEncryptedData: %@",messageEncryptedData);
            
            NSString *decryptedJSONString = [EncryptionHelper decryptUsingSymmetricAES256:messageEncryptedData];
            //NSLog(@"Decrypted Response: %@", decryptedJSONString);
            
            NSData *decryptedJSONData = [decryptedJSONString dataUsingEncoding:NSUTF8StringEncoding];
            NSDictionary *jsonMessage = [NSJSONSerialization JSONObjectWithData:decryptedJSONData options:NSJSONWritingPrettyPrinted error:nil];
            
            
            NSNumber *reasonCode = [jsonMessage objectForKey:ReasonCodeResponseParameterName];
            //NSLog(@"Reason Code: %@", reasonCode);
            
            if (reasonCode.intValue == 0){
                self.transactionResult = [[TransactionResult alloc] initWithDictionary:jsonMessage error:nil];
                //NSLog(@"Zimple Transaction Id: %@", self.transactionResult.zimpleTransactionId);
                if (ackContinueSelector != nil){
                    // If the refund is successful and theres is a ackContinueSelector, send an ACK to the server
                    [self sendACK:self.transactionResult.zimpleTransactionId];
                }else{
                    // Sale successful and No ACKContinueSelector
                    [salesManagerDelegate refundResponseReceived:self.transactionResult error:nil];
                }
                return;
            }
        }
    }
    
    NSMutableDictionary *details = [NSMutableDictionary dictionary];
    //NSString *reasonCodeStr = [NSString stringWithFormat:@"%d", error.code];
    NSString *reasonCodeStr = [error.userInfo objectForKey:NSLocalizedDescriptionKey];
    [details setValue:NSLocalizedString(reasonCodeStr, @"") forKey:NSLocalizedDescriptionKey];
    error = [NSError errorWithDomain:@"Zimple" code:error.code userInfo:details];
    [salesManagerDelegate refundResponseReceived:nil error:error];
}

- (void)tipAdjustementResponseReceived:(NSData *)responseData error:(NSError *)error{
    if (responseData != nil){
        NSError *myError;
        if (error == nil){
            NSDictionary* json = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONWritingPrettyPrinted error:&myError];
            
            NSString *messageEncryptedData = [json objectForKey:MessageResponseParameterName];
            //NSLog(@"MessageEncryptedData: %@",messageEncryptedData);
            
            NSString *decryptedJSONString = [EncryptionHelper decryptUsingSymmetricAES256:messageEncryptedData];
            NSLog(@"Decrypted Response: %@", decryptedJSONString);
            
            NSData *decryptedJSONData = [decryptedJSONString dataUsingEncoding:NSUTF8StringEncoding];
            NSDictionary *jsonMessage = [NSJSONSerialization JSONObjectWithData:decryptedJSONData options:NSJSONWritingPrettyPrinted error:nil];
            
            
            NSNumber *reasonCode = [jsonMessage objectForKey:ReasonCodeResponseParameterName];
            //NSLog(@"Reason Code: %@", reasonCode);
            
            if (reasonCode.intValue == 0){
                self.transactionResult = [[TransactionResult alloc] initWithDictionary:jsonMessage error:nil];
                if (ackContinueSelector != nil){
                    // If the refund is successful and theres is a ackContinueSelector, send an ACK to the server
                    [self sendACK:self.transactionResult.zimpleTransactionId];
                }else{
                    // Sale successful and No ACKContinueSelector
                    [salesManagerDelegate tipAdjustementTransactionResponseReceived:self.transactionResult error:nil];
                }
                return;
            }
        }
    }
    
    NSMutableDictionary *details = [NSMutableDictionary dictionary];
    //NSString *reasonCodeStr = [NSString stringWithFormat:@"%d", error.code];
    NSString *reasonCodeStr = [error.userInfo objectForKey:NSLocalizedDescriptionKey];
    [details setValue:NSLocalizedString(reasonCodeStr, @"") forKey:NSLocalizedDescriptionKey];
    error = [NSError errorWithDomain:@"Zimple" code:error.code userInfo:details];
    [salesManagerDelegate tipAdjustementTransactionResponseReceived:NO error:error];
}

@end
