/*
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  RecipeViewController.m
//  Zimple POS
//

#import "RecipeViewController.h"

@interface RecipeViewController ()

@end

@implementation RecipeViewController

@synthesize shareRecipeNavController;
@synthesize titleLabel;
@synthesize recipeDescriptionLabel;
@synthesize voucherBackgroundImage;
@synthesize commerceNameLabel;
@synthesize terminalIdTitleLabel;
@synthesize terminalIdValueLabel;
@synthesize creditCardNumberTitleLabel;
@synthesize creditCardNumberValueLabel;
@synthesize referenceNumberTitleLabel;
@synthesize referenceNumberValueLabel;
@synthesize authorizationNumberTitleLabel;
@synthesize authorizationNumberValueLabel;
@synthesize billNumberTitleLabel;
@synthesize billNumberValueLabel;
@synthesize dateTitleLabel;
@synthesize dateValueLabel;
@synthesize transactionTypeLabel;
@synthesize amountTitleLabel;
@synthesize amountValueLabel;
@synthesize subtotalTitleLabel;
@synthesize subtotalValueLabel;
@synthesize taxAmountTitleLabel;
@synthesize taxAmountValueLabel;
@synthesize tipAmountTitleLabel;
@synthesize tipAmountValueLabel;
@synthesize transactionTypeId;
@synthesize transactionRecord;
@synthesize transactionRecordCurrency;
@synthesize transactionRecordAffiliateBankTerminal;
@synthesize tiledButtonBlueBackgroundImageView;
@synthesize tiledButtonArrowBackgroundImageView;
@synthesize tiledButtonLabel;
@synthesize tiledButtonButton;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    NSLog(@"Description: %@", [self description]);
    shareRecipeNavController = [self.storyboard instantiateViewControllerWithIdentifier:@"ShareReceiptNavController"];
    
    titleLabel.textColor = [UIColorList credomaticBlueColor];
    recipeDescriptionLabel.textColor = [UIColorList credomaticGrayColor];
    
    commerceNameLabel.textColor = [UIColorList credomaticGrayColor];
    terminalIdTitleLabel.textColor = [UIColorList credomaticGrayColor];
    terminalIdValueLabel.textColor = [UIColorList credomaticGrayColor];
    creditCardNumberTitleLabel.textColor = [UIColorList credomaticGrayColor];
    creditCardNumberValueLabel.textColor = [UIColorList credomaticGrayColor];
    referenceNumberTitleLabel.textColor = [UIColorList credomaticGrayColor];
    referenceNumberValueLabel.textColor = [UIColorList credomaticGrayColor];
    authorizationNumberTitleLabel.textColor = [UIColorList credomaticGrayColor];
    authorizationNumberValueLabel.textColor = [UIColorList credomaticGrayColor];
    billNumberTitleLabel.textColor = [UIColorList credomaticGrayColor];
    billNumberValueLabel.textColor = [UIColorList credomaticGrayColor];
    dateTitleLabel.textColor = [UIColorList credomaticGrayColor];
    dateValueLabel.textColor = [UIColorList credomaticGrayColor];
    transactionTypeLabel.textColor = [UIColorList credomaticGrayColor];
    amountTitleLabel.textColor = [UIColorList credomaticGrayColor];
    amountValueLabel.textColor = [UIColorList credomaticGrayColor];
    subtotalTitleLabel.textColor = [UIColorList credomaticGrayColor];
    subtotalValueLabel.textColor = [UIColorList credomaticGrayColor];
    taxAmountTitleLabel.textColor = [UIColorList credomaticGrayColor];
    taxAmountValueLabel.textColor = [UIColorList credomaticGrayColor];
    tipAmountTitleLabel.textColor = [UIColorList credomaticGrayColor];
    tipAmountValueLabel.textColor = [UIColorList credomaticGrayColor];
    
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    TransactionInfo *transactionInfo = userInfo.sessionInfo.currentTransactionInfo;
    if (transactionRecord == nil){
        // If transactionRecord is Nil it means that we are requesting a voucher for the transaction that the user just did a moment ago.
        
        // Hide the back button for this kind of voucher
        self.navigationController.navigationItem.leftBarButtonItem = nil;
        self.navigationItem.leftBarButtonItem = nil;
        self.navigationItem.backBarButtonItem = nil;
        self.navigationController.navigationItem.backBarButtonItem = nil;
        self.navigationController.navigationItem.hidesBackButton = YES;
        self.navigationItem.hidesBackButton = YES;
        
        // Disable the share receipt option (Share for this transaction is made through the Tiled Button.
        self.navigationItem.rightBarButtonItem = nil;
        
        if ([transactionTypeId isEqualToString:SaleTransactionTypeId] || [transactionTypeId isEqualToString:RefundTransactionTypeId] || [transactionTypeId isEqualToString:VoidTransactionTypeId] || [transactionTypeId isEqualToString:TipAdjustementTransactionTypeId]){
            commerceNameLabel.text = userInfo.terminalInfo.terminal.branch.name;
            transactionRecordAffiliateBankTerminal = transactionInfo.affiliate.bankTerminal;
            terminalIdValueLabel.text = transactionRecordAffiliateBankTerminal;
            
            creditCardNumberValueLabel.text = transactionInfo.creditCardInfo.creditCardNumberMasked;
            referenceNumberValueLabel.text = transactionInfo.transactionResult.referenceNumber;
            authorizationNumberValueLabel.text = transactionInfo.transactionResult.authorizationNumber;
            billNumberValueLabel.text = transactionInfo.transactionResult.invoice;
            dateValueLabel.text = transactionInfo.transactionResult.transactionDateAndTimeWithFormat;
            
            transactionTypeLabel.text = @"";
            
            subtotalTitleLabel.hidden = YES;
            subtotalValueLabel.hidden = YES;
            taxAmountTitleLabel.hidden = YES;
            taxAmountValueLabel.hidden = YES;
            tipAmountTitleLabel.hidden = YES;
            tipAmountValueLabel.hidden = YES;
            
            amountValueLabel.text = [NSString stringWithFormat:@"%@ %@", transactionInfo.transactionResult.salesAmountWithFormat, transactionInfo.affiliate.currencyCode];
            
            if ([transactionTypeId isEqualToString:SaleTransactionTypeId] || [transactionTypeId isEqualToString:TipAdjustementTransactionTypeId]){
            
                subtotalTitleLabel.hidden = NO;
                subtotalValueLabel.hidden = NO;
                taxAmountTitleLabel.hidden = NO;
                taxAmountValueLabel.hidden = NO;
                tipAmountTitleLabel.hidden = NO;
                tipAmountValueLabel.hidden = NO;
                
                    SaleTransactionInfo *saleTransactionInfo = (SaleTransactionInfo *)transactionInfo;
                
                    subtotalValueLabel.text = [NSString stringWithFormat:@"%@ %@", saleTransactionInfo.amountWithFormat, transactionInfo.affiliate.currencyCode];
                    //taxAmountValueLabel.text = [NSString stringWithFormat:@"%.02f %@", saleTransactionInfo.taxAmount, transactionInfo.affiliate.currencyCode];
                taxAmountValueLabel.text = [NSString stringWithFormat:@"%@ %@", saleTransactionInfo.taxAmountWithFormat, transactionInfo.affiliate.currencyCode];
                    tipAmountValueLabel.text = [NSString stringWithFormat:@"%@ %@", saleTransactionInfo.tipAmountWithFormat, transactionInfo.affiliate.currencyCode];
                
                //amountValueLabel.text = [NSString stringWithFormat:@"%@ %@", transactionInfo.transactionResult.saleAmountWithFormat, transactionInfo.affiliate.currencyCode];
                
            }else if ([transactionTypeId isEqualToString:RefundTransactionTypeId]){
                titleLabel.text = @"Recibo";
                recipeDescriptionLabel.text = @"Su devolución ha sido exitosa, adjunto encontrará el detalle de la transacción";
                transactionTypeLabel.text = @"***DEVOLUCIÓN***";
            }else if ([transactionTypeId isEqualToString:VoidTransactionTypeId]){
                titleLabel.text = @"Recibo";
                recipeDescriptionLabel.text = @"Su anulación ha sido exitosa, adjunto encontrará el detalle de la transacción";
                transactionTypeLabel.text = @"***ANULACIÓN***";
            }
        }
    }else{
        // A voucher from a previous transaction does not have:
        //  - A description
        //  - The Finish Tiled Button on the bottom
        //  - A Share option through the Navigation Bar Button
        
        // Hides the Tiled Button on the bottom
        tiledButtonBlueBackgroundImageView.hidden = YES;
        tiledButtonArrowBackgroundImageView.hidden = YES;
        tiledButtonLabel.hidden = YES;
        tiledButtonButton.hidden = YES;
        
        // If the TransacationRecord in not null, it means the voucher it from a transaction already stored in the backend
        commerceNameLabel.text = userInfo.terminalInfo.terminal.branch.name;
        terminalIdValueLabel.text = transactionRecordAffiliateBankTerminal;
        /*NSString *creditCardLastDigits = @"";
        if (transactionRecord.creditCardLastDigits != nil){
            creditCardLastDigits = transactionRecord.creditCardLastDigits;
        }
        creditCardNumberValueLabel.text = [NSString stringWithFormat:@"************%@", creditCardLastDigits];*/
        creditCardNumberValueLabel.text = transactionRecord.maskedCreditCard;
        referenceNumberValueLabel.text = transactionRecord.saleReferenceNumber;
        authorizationNumberValueLabel.text = transactionRecord.saleAuthorizationNumber;
        billNumberValueLabel.text = transactionRecord.saleInvoice;
        dateValueLabel.text = transactionRecord.transactionDateAndTimeWithFormat;
        
        subtotalValueLabel.text = [NSString stringWithFormat:@"%@ %@", transactionRecord.subTotalSaleAmountWithFormat, transactionRecordCurrency];
        if (transactionRecord.saleTaxAmount == nil){
            taxAmountValueLabel.text = [NSString stringWithFormat:@"0 %@", transactionRecordCurrency];
        }else{
            taxAmountValueLabel.text = [NSString stringWithFormat:@"%@ %@", transactionRecord.taxAmountWithFormat, transactionRecordCurrency];
        }
        if (transactionRecord.saleTipAmount == nil){
            tipAmountValueLabel.text = [NSString stringWithFormat:@"0 %@", transactionRecordCurrency];
        }else{
            tipAmountValueLabel.text = [NSString stringWithFormat:@"%@ %@", transactionRecord.tipAmountWithFormat, transactionRecordCurrency];
        }
        
        transactionTypeLabel.text = @"";
        recipeDescriptionLabel.text = @"";
        if ([transactionTypeId isEqualToString:VoidTransactionTypeId]){
            titleLabel.text = @"Recibo";
            transactionTypeLabel.text = @"***ANULACIÓN***";
            
            subtotalTitleLabel.hidden = YES;
            subtotalValueLabel.hidden = YES;
            taxAmountTitleLabel.hidden = YES;
            taxAmountValueLabel.hidden = YES;
            tipAmountTitleLabel.hidden = YES;
            tipAmountValueLabel.hidden = YES;
            
        }else if ([transactionTypeId isEqualToString:RefundTransactionTypeId]){
            titleLabel.text = @"Recibo";
            transactionTypeLabel.text = @"***DEVOLUCIÓN***";
            
            subtotalTitleLabel.hidden = YES;
            subtotalValueLabel.hidden = YES;
            taxAmountTitleLabel.hidden = YES;
            taxAmountValueLabel.hidden = YES;
            tipAmountTitleLabel.hidden = YES;
            tipAmountValueLabel.hidden = YES; 
        }
        
        amountValueLabel.text = [NSString stringWithFormat:@"%@ %@", transactionRecord.saleAmountWithFormat, transactionRecordCurrency];
        
        ShareRecipeViewController *shareReceiptViewController = [[shareRecipeNavController viewControllers] objectAtIndex:0];
        shareReceiptViewController.transactionRecord = transactionRecord;
        shareReceiptViewController.transactionTypeId = transactionTypeId;
        shareReceiptViewController.transactionRecordCurrency = transactionRecordCurrency;
        shareReceiptViewController.transactionRecordAffiliateBankTerminal = transactionRecordAffiliateBankTerminal;
    }
    
    // Center the recipe in the vertical space of the view
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.view attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:voucherBackgroundImage attribute:NSLayoutAttributeCenterY multiplier:1 constant:0]];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    if (transactionRecord == nil){
        // Disable the right controller (no right swipe allowed for this recipe).
        self.viewDeckController.rightController = nil;
    }else{
        // The Voucher can be shared through the "Share Navigation Bar Button" only when its an older transacion (or a TransacionRecord)
        self.viewDeckController.rightController = shareRecipeNavController;
        self.viewDeckController.rightSize = 10.0f;
    }
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    self.viewDeckController.rightController = nil;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskPortrait;
}

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation
{
    return UIInterfaceOrientationPortrait;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([segue.identifier isEqualToString:@"RecipeToShareRecpeSegue"]){
        ShareRecipeViewController *shareReceiptViewController = segue.destinationViewController;
        shareReceiptViewController.transactionRecord = transactionRecord;
        shareReceiptViewController.transactionTypeId = transactionTypeId;
        shareReceiptViewController.transactionRecordCurrency = transactionRecordCurrency;
        shareReceiptViewController.transactionRecordAffiliateBankTerminal = transactionRecordAffiliateBankTerminal;
    }
}

- (IBAction)finishButtonTouchUpInside:(id)sender {
    [self performSegueWithIdentifier:@"RecipeToShareRecpeSegue" sender:self];
}

- (IBAction)shareReceiptButtonTouchUpInside:(id)sender{
    [self.viewDeckController openRightViewAnimated:YES];
}

- (void)viewDidUnload {
    [self setTitleLabel:nil];
    [self setRecipeDescriptionLabel:nil];
    [self setVoucherBackgroundImage:nil];
    [self setCommerceNameLabel:nil];
    [self setTerminalIdTitleLabel:nil];
    [self setTerminalIdValueLabel:nil];
    [self setCreditCardNumberTitleLabel:nil];
    [self setCreditCardNumberValueLabel:nil];
    [self setReferenceNumberTitleLabel:nil];
    [self setReferenceNumberTitleLabel:nil];
    [self setReferenceNumberValueLabel:nil];
    [self setAuthorizationNumberTitleLabel:nil];
    [self setAuthorizationNumberValueLabel:nil];
    [self setBillNumberTitleLabel:nil];
    [self setBillNumberValueLabel:nil];
    [self setBillNumberTitleLabel:nil];
    [self setBillNumberValueLabel:nil];
    [self setDateTitleLabel:nil];
    [self setDateValueLabel:nil];
    [self setTransactionTypeLabel:nil];
    [self setAmountTitleLabel:nil];
    [self setAmountValueLabel:nil];
    [self setTiledButtonArrowBackgroundImageView:nil];
    [self setTiledButtonBlueBackgroundImageView:nil];
    [self setTiledButtonLabel:nil];
    [self setTiledButtonButton:nil];
    [super viewDidUnload];
}
@end
