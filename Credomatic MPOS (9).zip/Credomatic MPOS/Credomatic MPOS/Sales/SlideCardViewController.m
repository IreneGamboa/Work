/*
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  SlideCardViewController.m
//  Zimple POS
//

#import "SlideCardViewController.h"

#define WrongSwipeAlertViewTag 1
#define ReaderSerialNumberInvalidAlertViewTag 2

@interface SlideCardViewController ()

@property (nonatomic)BOOL isSendingCommand;

@end

@implementation SlideCardViewController

@synthesize connectDeviceView;
@synthesize startDeviceView;
@synthesize slideCardView;
@synthesize startDeviceViewTall;
@synthesize slideCardViewTall;
@synthesize connectDeviceViewTall;
@synthesize startingDeviceImageView;
@synthesize startDeviceImageView;
@synthesize connectDeviceImageView;
@synthesize slideCardImageView;
@synthesize slideCardTitle;
@synthesize slideCardDescription;
@synthesize connectDeviceTitle;
@synthesize startDeviceTitle;
@synthesize isSendingCommand;
@synthesize tempView;

@synthesize startingDeviceImageViewTall;
@synthesize startDeviceImageViewTall;
@synthesize connectDeviceImageViewTall;
@synthesize slideCardImageViewTall;
@synthesize connectDeviceTitleTall;
@synthesize startDeviceTitleTall;
@synthesize slideCardTitleTall;
@synthesize slideCardDescriptionTall;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    if (IS_IPHONE_5){
        /*connectDeviceImageView.image = [UIImage imageNamed:@"Connect_Device_Tall"];
        startDeviceImageView.image = [UIImage imageNamed:@"Starting_Device_Tall"];
        slideCardImageView.image = [UIImage imageNamed:@"Slide_Card_Tall"];
        */
        startDeviceView = startDeviceViewTall;
        slideCardView = slideCardViewTall;
        connectDeviceView = connectDeviceViewTall;
        
        connectDeviceTitle = connectDeviceTitleTall;
        startDeviceTitle = startDeviceTitleTall;
        slideCardTitle = slideCardTitleTall;
        slideCardDescription = slideCardDescriptionTall;
        
        startingDeviceImageView = startingDeviceImageViewTall;
        /*startingDeviceImageView = startingDeviceImageViewTall;
        startDeviceImageView = startDeviceImageViewTall;
        connectDeviceImageView =  connectDeviceImageViewTall;
        slideCardImageView = slideCardImageViewTall;
        */
    }
    
    connectDeviceTitle.textColor = [UIColorList credomaticBlueColor];
    startDeviceTitle.textColor = [UIColorList credomaticBlueColor];
    slideCardTitle.textColor = [UIColorList credomaticBlueColor];
    slideCardDescription.textColor = [UIColorList credomaticGrayColor];
    
    connectDeviceView.backgroundColor = [UIColor clearColor];
    slideCardView.backgroundColor = [UIColor clearColor];
    
    NSString *startingDeviceGifName = @"Starting_Device_Gif";
    if (IS_RETINA){
        startingDeviceGifName = @"Starting_Device_Gif@2x";
    }
    
    NSData* data = [NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:startingDeviceGifName ofType:@"gif"]];
    UIImage* image = [UIImage animatedGIFWithData:data];
    startingDeviceImageView.image = image;
    
    self.HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.slideCardView addSubview:self.HUD];
    
#ifdef DEBUG
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    //NSString *creditCardEncryptedPayload = @"020901801f4e28008383252a353438382a2a2a2a2a2a2a2a353830325e56494c4c414c4f424f53205649414c45532f444f55474c41535e2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a3f2a3b353438382a2a2a2a2a2a2a2a353830323d2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a3f2a78fb0044b6021975687a4f003a38f4fcd729c538913dbf05f51fc1179933e1fc762228a645316070c8174572ba7b985aa5477c64cb43cfadba082b7bd388eb27da7f4fc6da1e10340570933de0218d483c55f8e1763b48a78bbb670ba2ce4bd458466bc02eb49bc19fe4b4442fb08bc042f85a5836e2c5e45431323036303334323062994900320014c0000d47fb03";
    NSString *creditCardEncryptedPayload =@"02fb00801f4828008383252a353438382a2a2a2a2a2a2a2a393931305e53415552455a204c45452f4a4f5345204d4c2e5e313430372a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a3f2a3b353438382a2a2a2a2a2a2a2a393931303d313430372a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a3f2ad990f866023bc26c0d77351ac51426f4e087fca41ffab08fd5a67a59d3f1f0ff6dac7f202ce7a95a9d479b6e527156cd76534cfb86f9f9e785580b2b67c7194f8f85dc6e6f38914d2e83562a1f6acacf8ed97b15b0a0f1471bc61b62f9a003403a21a96d7eb7311640706a4ce8a7b9f154313330323034393631629949004100056000993c4c03";
    NSError *error = nil;
    CreditCardInfo* creditCardInfo = [CreditCardInfo creditCardInfoFromHexEncryptedPayload:creditCardEncryptedPayload error:&error];
    if (error == nil){
        userInfo.sessionInfo.currentTransactionInfo.creditCardInfo = creditCardInfo;
        NSLog(@"[TEST] Credit Card Number: %@", creditCardInfo.creditCardNumberMasked);
        NSLog(@"[TEST] Credit Card Name: %@", creditCardInfo.cardHolderName);
    }else{
        NSLog(@"Error Validating Credit Card: %@", error.localizedDescription);
    }
#else
    self.navigationController.navigationItem.rightBarButtonItem = nil;
    self.navigationItem.rightBarButtonItem = nil;
#endif

    isSendingCommand = FALSE;
    
    if (floor(NSFoundationVersionNumber) > NSFoundationVersionNumber_iOS_6_1) {
        self.navigationController.navigationBar.translucent = NO;
    }
    
    [UIView transitionFromView:tempView
                        toView:connectDeviceView
                      duration:2.0
                       options:UIViewAnimationOptionTransitionCrossDissolve
                    completion:^(BOOL finished) {
                        // animation completed
                        //start the swipe task. ie, cause SDK to start waiting for a swipe to be made
                        UmRet ret = [uniReader requestSwipe];
                        NSLog(@"Demo: requestSwipe return code: \"%@\"", UmRet_lookup(ret));
                    }];
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    [self umsdk_activate];
}

- (void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    
    [uniReader cancelTask];
    [self umsdk_deactivate];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)next:(id)sender {
    [self performSegueWithIdentifier:@"SlideCardToConfirmationSegue" sender:self];
}

//-----------------------------------------------------------------------------
#pragma mark - uniMag SDK activation/deactivation -
//-----------------------------------------------------------------------------

-(void) umsdk_registerObservers:(BOOL) reg {
	NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
    
    //list of notifications and their corresponding selector    
    NSString *notificationsStrings[] = {
        //
        uniMagAttachmentNotification,
        uniMagDetachmentNotification,
        //
        uniMagInsufficientPowerNotification,
        uniMagPoweringNotification,
        uniMagTimeoutNotification,
        uniMagDidConnectNotification,
        uniMagDidDisconnectNotification,
        //
        uniMagSwipeNotification,
        uniMagTimeoutSwipeNotification,
        uniMagDataProcessingNotification,
        uniMagInvalidSwipeNotification,
        uniMagDidReceiveDataNotification,
        //
        uniMagCmdSendingNotification,
        uniMagCommandTimeoutNotification,
        uniMagDidReceiveCmdNotification,
        //
        uniMagSystemMessageNotification,
        nil
    };
    
    SEL notificationsSelectors[] = {
        //
        @selector(umDevice_attachment:),
        @selector(umDevice_detachment:),
        //
        @selector(umConnection_lowVolume:),
        @selector(umConnection_starting:),
        @selector(umConnection_timeout:),
        @selector(umConnection_connected:),
        @selector(umConnection_disconnected:),
        //
        @selector(umSwipe_starting:),
        @selector(umSwipe_timeout:),
        @selector(umDataProcessing:),
        @selector(umSwipe_invalid:),
        @selector(umSwipe_receivedSwipe:),
        //
        @selector(umCommand_starting:),
        @selector(umCommand_timeout:),
        @selector(umCommand_receivedResponse:),
        //
        @selector(umSystemMessage:),
        nil
    };
    
    //register or unregister
    for (int i=0; notificationsStrings[i] != nil ;i++) {
        if (reg)
            [nc addObserver:self selector:notificationsSelectors[i] name:notificationsStrings[i] object:nil];
        else
            [nc removeObserver:self name:notificationsStrings[i] object:nil];
    }
}

-(void) umsdk_activate {
    
    //register observers for all uniMag notifications
	[self umsdk_registerObservers:TRUE];
    
    
	//enable info level NSLogs inside SDK
    // Here we turn on before initializing SDK object so the act of initializing is logged
    [uniMag enableLogging:TRUE];
    
    //initialize the SDK by creating a uniMag class object
    uniReader = [[uniMag alloc] init];
    
    
     //set SDK to perform the connect task automatically when headset is attached
     [uniReader setAutoConnect:TRUE];
     
    
    //set swipe timeout to infinite. By default, swipe task will timeout after 20 seconds
	[uniReader setSwipeTimeoutDuration:0];
    
    //make SDK maximize the volume automatically during connection
    [uniReader setAutoAdjustVolume:TRUE];
    
    //By default, the diagnostic wave file logged by the SDK is stored under the temp directory
    // Here it is set to be under the Documents folder in the app sandbox so the log can be accessed
    // through iTunes file sharing. See UIFileSharingEnabled in iOS doc.
    [uniReader setWavePath: [NSHomeDirectory() stringByAppendingPathComponent: @"/Documents/audio.caf"]];
    
    //NSLog(@"Reader Attached: %d", [uniReader isReaderAttached]);
    //NSLog(@"Reader Connection Status: %d", [uniReader getConnectionStatus]);
    if ([uniReader isReaderAttached] == TRUE && [uniReader getConnectionStatus] == TRUE){
        // The reader is already attached and connected.
        
        // Transition from the Connect View to the Slide Card View
        [UIView transitionFromView:connectDeviceView
                            toView:slideCardView
                          duration:2.0
                           options:UIViewAnimationOptionTransitionCrossDissolve
                        completion:^(BOOL finished) {
                            // animation completed
                            //start the swipe task. ie, cause SDK to start waiting for a swipe to be made
                            UmRet ret = [uniReader requestSwipe];
                            NSLog(@"Demo: requestSwipe return code: \"%@\"", UmRet_lookup(ret));
                        }];
    }
}

-(void) umsdk_deactivate {
    //it is the responsibility of SDK client to unregister itself as notification observer
    [self umsdk_registerObservers:FALSE];
}

//-----------------------------------------------------------------------------
#pragma mark - uniMag SDK notification handlers  -
//-----------------------------------------------------------------------------

#pragma mark attachment

//called when uniMag is physically attached
- (void)umDevice_attachment:(NSNotification *)notification {
    [self.HUD hide:NO];
    // Transition from the Connect View to the Slide Card View
    [UIView transitionFromView:connectDeviceView
                        toView:startDeviceView
                      duration:2.0
                       options:UIViewAnimationOptionTransitionCrossDissolve
                    completion:^(BOOL finished) {
                        // animation completed
                    }];
    
    NSLog(@"Device Attached");
}

//called when uniMag is physically detached
- (void)umDevice_detachment:(NSNotification *)notification {
    [self.HUD hide:NO];
    // Transition from the Connect View to the Slide Card View
    [UIView transitionFromView:slideCardView
                        toView:connectDeviceView
                      duration:2.0
                       options:UIViewAnimationOptionTransitionCrossDissolve
                    completion:^(BOOL finished) {
                        // animation completed
                    }];
    [UIView transitionFromView:startDeviceView
                        toView:connectDeviceView
                      duration:2.0
                       options:UIViewAnimationOptionTransitionCrossDissolve
                    completion:^(BOOL finished) {
                        // animation completed
                    }];
     
    NSLog(@"Connection Deattached");
}

#pragma mark connection task

//called when attempting to start the connection task but iDevice's headphone playback volume is too low
- (void)umConnection_lowVolume:(NSNotification *)notification {
    UIAlertView *volumeBad = [[UIAlertView alloc]
                              initWithTitle:@"Conectar Dispositvo"
                              message:@"El nivel de volumen se encuentra muy bajo. Suba al máximo el volumen y conecte el dispositivo nuevamente."
                              delegate:self
                              cancelButtonTitle:@"OK"
                              otherButtonTitles:nil];
    [volumeBad show];
}

//called when successfully starting the connection task
- (void)umConnection_starting:(NSNotification *)notification {
    NSLog(@"Connection Starting");
}

//called when SDK failed to handshake with reader in time. ie, the connection task has timed out
- (void)umConnection_timeout:(NSNotification *)notification {
	UIAlertView *connectionFailed = [[UIAlertView alloc]
                                     initWithTitle:@"Conectar Dispositivo"
                                     message:@"Presione Ok y conecte el dispositivo nuevamente."
                                     delegate:self
                                     cancelButtonTitle:@"Ok"
                                     otherButtonTitles:nil];
	[connectionFailed show];
}

//called when the connection task is successful. SDK's connection state changes to true
- (void)umConnection_connected:(NSNotification *)notification {
    NSLog(@"Connection Connected");
    [self.HUD hide:NO];
    // Send a command querying the reader for its Serial Number.
    isSendingCommand = YES;
    UmRet ret = [uniReader sendCommandGetSerialNumber];
    
    // Transition from the Connect View to the Slide Card View
    [UIView transitionFromView:startDeviceView
                        toView:slideCardView
                      duration:2.0
                       options:UIViewAnimationOptionTransitionCrossDissolve
                    completion:^(BOOL finished) {
                        // animation completed
                        //start the swipe task. ie, cause SDK to start waiting for a swipe to be made
                        //UmRet ret = [uniReader requestSwipe];
                        //NSLog(@"Demo: requestSwipe return code: \"%@\"", UmRet_lookup(ret));
                        
                    }];
}

//called when SDK's connection state changes to false. This happens when reader becomes
// physically detached or when a disconnect API is called
- (void)umConnection_disconnected:(NSNotification *)notification {
    NSLog(@"Connection Disconnected");
    [self.HUD hide:NO];
    
}

#pragma mark swipe task

//called when the swipe task is successfully starting, meaning the SDK starts to
// wait for a swipe to be made
- (void)umSwipe_starting:(NSNotification *)notification {
    NSLog(@"Starting Swipe");
}

//called when the SDK hasn't received a swipe from the device within a configured
// "swipe timeout interval".
- (void)umSwipe_timeout:(NSNotification *)notification {
}

//called when the SDK has read something from the uniMag device
// (eg a swipe, a response to a command) and is in the process of decoding it
// Use this to provide an early feedback on the UI
- (void)umDataProcessing:(NSNotification *)notification {
    NSLog(@"Data Processing");
    NSString *hudText = @"Leyendo Datos";
    if (isSendingCommand){
        hudText = @"Validando lector";
    }
    self.HUD.labelText = hudText;
    [self.HUD show:YES];
}

//called when SDK failed to read a valid card swipe
- (void)umSwipe_invalid:(NSNotification *)notification {
    [self.HUD hide:YES];
    NSLog(@"Invalid Swipe");
    // Show an alert to the user indicating the swipe contained wrong information
    UIAlertView *wrongSwipeAlertView = [[UIAlertView alloc] initWithTitle:@"Lectura de Tarjeta" message:@"La lectura es inválida, por favor presiona Ok e intente nuevamente" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
    wrongSwipeAlertView.tag = WrongSwipeAlertViewTag;
    [wrongSwipeAlertView show];
}

//called when SDK received a swipe successfully
- (void)umSwipe_receivedSwipe:(NSNotification *)notification {
    [self.HUD hide:YES];
	NSData *data = [notification object];

    // Format the Hex Data (Remove the <> and spaces)
    NSString *cardPayloadHex = [data description];
    cardPayloadHex = [cardPayloadHex stringByReplacingOccurrencesOfString:@"<" withString:@""];
    cardPayloadHex = [cardPayloadHex stringByReplacingOccurrencesOfString:@">" withString:@""];
    cardPayloadHex = [cardPayloadHex stringByReplacingOccurrencesOfString:@" " withString:@""];
    //NSLog(@"Data Readed as Hex: %@", cardPayloadHex);
    
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    // Validate the content of the Swipe
    NSError *error = nil;
    CreditCardInfo* creditCardInfo = [CreditCardInfo creditCardInfoFromHexEncryptedPayload:cardPayloadHex error:&error];
    if (error == nil){
        userInfo.sessionInfo.currentTransactionInfo.creditCardInfo = creditCardInfo;
        //NSLog(@"Credit Card Number: %@", creditCardInfo.creditCardNumberMasked);
        //NSLog(@"Credit Card Name: %@", creditCardInfo.cardHolderName);
        
        // If the Credit Card is valid, continue with the process.
        [self performSegueWithIdentifier:@"SlideCardToConfirmationSegue" sender:self];
        
    }else{
        //NSLog(@"Error Validating Credit Card: %@", error.localizedDescription);
        // Show an alert to the user indicating the swipe contained wrong information
        UIAlertView *wrongSwipeAlertView = [[UIAlertView alloc] initWithTitle:@"Lectura de Tarjeta" message:@"La lectura es inválida, por favor presiona Ok e intente nuevamente" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        wrongSwipeAlertView.tag = WrongSwipeAlertViewTag;
        [wrongSwipeAlertView show];
    }
}

#pragma mark command task

//called when SDK successfully starts to send a command. SDK starts the command
// task
- (void)umCommand_starting:(NSNotification *)notification {
}

//called when SDK failed to receive a command response within a configured
// "command timeout interval"
- (void)umCommand_timeout:(NSNotification *)notification {
    [self.HUD hide:YES];
}

//called when SDK successfully received a response to a command
- (void)umCommand_receivedResponse:(NSNotification *)notification {
    [self.HUD hide:YES];
	NSData *data = [notification object];
	NSString *text = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    // Example of readerSerialNumber: T130204961o must be converted to a valid readerSerialNumber: T130204961
    NSString *readerSerialNumber = [text substringFromIndex:2];
    readerSerialNumber = [readerSerialNumber substringToIndex:readerSerialNumber.length-2];
    
    if ([readerSerialNumber isEqualToString:userInfo.terminalInfo.terminal.readerSerialNumber]){
        // Reader inserted is the same as registered in the backend. Continue with swipe
        sleep(2);
        isSendingCommand = NO;
        UmRet ret = [uniReader requestSwipe];
    }else{
        // Readers don't match. Present error.
        UIAlertView *invalidReaderSerialNumberAlertView = [[UIAlertView alloc] initWithTitle:@"Validación de lector" message:@"El lector utilizado no se encuentra registrado para esta terminal. Por favor utilice el lector registrado." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        invalidReaderSerialNumberAlertView.tag = ReaderSerialNumberInvalidAlertViewTag;
        [invalidReaderSerialNumberAlertView show];
    }
}

#pragma mark misc

//this is a observer for a generic and extensible notification. It's currently only used during firmware update
- (void) umSystemMessage:(NSNotification *)notification {
	NSError *err = nil;
	err = [notification object];
}


- (void)viewDidUnload {
    [self setConnectDeviceView:nil];
    [self setSlideCardView:nil];
    [self setStartDeviceView:nil];
    [self setStartingDeviceImageView:nil];
    [self setConnectDeviceImageView:nil];
    [self setSlideCardImageView:nil];
    [self setStartDeviceImageView:nil];
    [self setStartDeviceViewTall:nil];
    [self setSlideCardViewTall:nil];
    [super viewDidUnload];
}

#pragma mark UIAlertViewDelegate Methods

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView.tag == WrongSwipeAlertViewTag){
        // Reenable the swipe operation
        UmRet ret = [uniReader requestSwipe];
        NSLog(@"Demo: requestSwipe return code: \"%@\"", UmRet_lookup(ret));
    }else if (alertView.tag == ReaderSerialNumberInvalidAlertViewTag){
        // Invalid Reader
        
    }

}

@end
