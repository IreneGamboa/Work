/*
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  SalesManager.h
//  Zimple POS
//

#import <Foundation/Foundation.h>
#import "ZimpleServices.h"
#import "ServerComunnicationConstants.h"
#import "EncryptionHelper.h"
#import "Terminal.h"
#import "TransactionResult.h"
#import "TransactionRecord.h"
#import <MapKit/MapKit.h>

@protocol SalesManagerDelegate <NSObject>
@optional
- (void)saleResponseReceived:(TransactionResult *)transactionResult error:(NSError *)error;
- (void)ackResponseReceived:(BOOL)ackResult error:(NSError *)error;
- (void)registerSignatureResponseReceived:(BOOL)registerSignatureResult error:(NSError *)error;
- (void)sendEmailSaleReceiptResponseReceived:(BOOL)sendEmailReceiptResult error:(NSError *)error;
- (void)settleTerminalResponseReceived:(BOOL)terminalSettlementResult error:(NSError *)error;
- (void)getVoidableTransactionsResponseReceived:(NSDictionary *)transactionsByAffiliateCode error:(NSError *)error;
- (void)voidTransactionResponseReceived:(TransactionResult *)transactionResult error:(NSError *)error;
- (void)getTransactionsListResponseReceived:(NSDictionary *)transactionsByAffiliateCode error:(NSError *)error;
- (void)refundResponseReceived:(TransactionResult *)transactionResult error:(NSError *)error;
- (void)tipAdjustementTransactionResponseReceived:(TransactionResult *)transactionResult error:(NSError *)error;
@end

@interface SalesManager : NSObject <ZimpleBackendServicesDelegate>

@property (nonatomic, strong) id <SalesManagerDelegate> salesManagerDelegate;
@property (nonatomic) SEL ackContinueSelector;

@property (strong, nonatomic) TransactionResult *transactionResult;

- (void)makeSale:(NSString *)cardPayload amount:(NSString *)amount affiliate:(Affiliate *)affiliate location:(CLLocationCoordinate2D)location taxAmount:(NSString *)taxAmount tipAmount:(NSString *)tipAmount;
- (void)makeAndFinishSale:(NSString *)cardPayload amount:(NSString *)amount affiliate:(Affiliate *)affiliate location:(CLLocationCoordinate2D)location taxAmount:(NSString *)taxAmount tipAmount:(NSString *)tipAmount;
- (void)registerSignatureAndFinishTransaction:(TransactionResult *)transactionResult signature:(NSString *)signature;
- (void)sendEmailSaleReceipt:(NSString *)transactionId email:(NSString *)email;
- (void)settleTerminal:(Affiliate *)affiliate;
- (void)getVoidableTransactions;
- (void)voidTransaction:(TransactionRecord *)transactionInfo;
- (void)voidTransaction:(TransactionRecord *)transactionInfo username:(NSString *)username userPIN:(NSString *)userPIN;
- (void)getTransactionsList:(NSDate *)startDate endDate:(NSDate *)endDate transactionType:(NSString *)transactionType;
- (void)makeRefund:(NSString *)cardPayload amount:(NSString *)amount affiliate:(Affiliate *)affiliate location:(CLLocationCoordinate2D)location;
- (void)makeRefund:(NSString *)cardPayload amount:(NSString *)amount affiliate:(Affiliate *)affiliate location:(CLLocationCoordinate2D)location username:(NSString *)username userPIN:(NSString *)userPIN;
- (void)makeAndFinishRefund:(NSString *)cardPayload amount:(NSString *)amount affiliate:(Affiliate *)affiliate location:(CLLocationCoordinate2D)location;
- (void)adjustTransactionTip:(TransactionRecord *)transactionRecord affiliate:(Affiliate *)affiliate tipNewAmount:(NSString *)tipNewAmount;
- (void)adjustTransactionTip:(TransactionRecord *)transactionRecord affiliate:(Affiliate *)affiliate tipNewAmount:(NSString *)tipNewAmount username:(NSString *)username userPIN:(NSString *)userPIN;

@end
