/*
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  SlideCardViewController.h
//  Zimple POS
//

#import <UIKit/UIKit.h>
#import "UserInfo.h"
#import "uniMag.h"
#import "UIImage+GIF.h"
#import "BaseViewController.h"
#import "CreditCardInfo.h"

@interface SlideCardViewController : BaseViewController <UIAlertViewDelegate>{

    uniMag *uniReader;
    
}

@property (strong, nonatomic) IBOutlet UIView *connectDeviceView;
@property (strong, nonatomic) IBOutlet UIView *startDeviceView;
@property (strong, nonatomic) IBOutlet UIView *slideCardView;
@property (strong, nonatomic) IBOutlet UIView *startDeviceViewTall;
@property (strong, nonatomic) IBOutlet UIView *slideCardViewTall;
@property (strong, nonatomic) IBOutlet UIView *connectDeviceViewTall;

@property (weak, nonatomic) IBOutlet UIImageView *startingDeviceImageView;
@property (weak, nonatomic) IBOutlet UIImageView *startDeviceImageView;
@property (weak, nonatomic) IBOutlet UIImageView *connectDeviceImageView;
@property (weak, nonatomic) IBOutlet UIImageView *slideCardImageView;

@property (weak, nonatomic) IBOutlet UIImageView *startingDeviceImageViewTall;
@property (weak, nonatomic) IBOutlet UIImageView *startDeviceImageViewTall;
@property (weak, nonatomic) IBOutlet UIImageView *connectDeviceImageViewTall;
@property (weak, nonatomic) IBOutlet UIImageView *slideCardImageViewTall;

@property (weak, nonatomic) IBOutlet UILabel *connectDeviceTitle;
@property (weak, nonatomic) IBOutlet UILabel *startDeviceTitle;
@property (weak, nonatomic) IBOutlet UILabel *slideCardTitle;
@property (weak, nonatomic) IBOutlet UILabel *slideCardDescription;

@property (weak, nonatomic) IBOutlet UILabel *connectDeviceTitleTall;
@property (weak, nonatomic) IBOutlet UILabel *startDeviceTitleTall;
@property (weak, nonatomic) IBOutlet UILabel *slideCardTitleTall;
@property (weak, nonatomic) IBOutlet UILabel *slideCardDescriptionTall;

@property (weak, nonatomic) IBOutlet UIView *tempView;


- (IBAction)next:(id)sender;
@end
