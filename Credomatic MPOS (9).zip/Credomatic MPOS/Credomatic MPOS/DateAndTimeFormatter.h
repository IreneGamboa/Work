//
//  DateAndTimeFormatter.h
//  Credomatic MPOS
//
//  Created by Jose Saurez on 11/22/13.
//  Copyright (c) 2013 Mobtion. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DateAndTimeFormatter : NSObject

+ (NSDate *)convertDateFromBackend:(NSString *)dateStr;
+ (NSDate *)convertTimeFromBackend:(NSString *)timeStr;
+ (NSString *)formatDate:(NSDate *)date;
+ (NSString *)formatTime:(NSDate *)time;
+ (NSString *)formatDateAndTime:(NSDate *)date time:(NSDate *)time separatedBy:(NSString *)separatedBy;

@end
