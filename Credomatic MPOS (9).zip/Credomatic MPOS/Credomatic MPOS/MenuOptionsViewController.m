/*
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  MenuOptionsViewController.m
//  Zimple POS
//

#import "MenuOptionsViewController.h"

#define LogoutAlertViewTag 0
#define ErrorAlertViewTag 100
#define TransactionInProgressAlertViewTag 99

@implementation MenuOption

@synthesize menuOptionName;
@synthesize menuOptionViewController;

@end

@implementation MenuSection

@synthesize menuSectionName;
@synthesize menuOptions;

@end

@interface MenuOptionsViewController ()

@property (nonatomic, strong) NSIndexPath *logoutIndexPath;
@property (nonatomic, strong) NSIndexPath *lastIndexPathSelected;

@property (nonatomic, strong) NSMutableArray *affiliateIndexPaths;
@property (nonatomic, strong) NSMutableArray *settlementIndexPaths;
@property (nonatomic, strong) NSMutableArray *voidIndexPaths;
@property (nonatomic, strong) NSMutableArray *refundsIndexPaths;

@property (nonatomic) BOOL isReselectingOldSelection;

@end

@implementation MenuOptionsViewController

@synthesize menuOptionsTableView;
@synthesize menuOptionsSections;
@synthesize logoutIndexPath;
@synthesize lastIndexPathSelected;
@synthesize affiliateIndexPaths;
@synthesize settlementIndexPaths;
@synthesize voidIndexPaths;
@synthesize refundsIndexPaths;
@synthesize isReselectingOldSelection;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    self.viewDeckController.delegate = self;
    
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"Options_Menu_Background"]];
    if (floor(NSFoundationVersionNumber) <= NSFoundationVersionNumber_iOS_6_1) {
        [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"Gray_NavBar"] forBarMetrics:UIBarMetricsDefault];
    }else{
        [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"Gray_NavBar_iOS7"] forBarMetrics:UIBarMetricsDefault];
    }
    
    UIView *tableViewBackgroundView = [[UIView alloc] initWithFrame:menuOptionsTableView.frame];
    tableViewBackgroundView.backgroundColor = [UIColor clearColor];
    menuOptionsTableView.backgroundView = tableViewBackgroundView;
    menuOptionsTableView.backgroundColor = [UIColor clearColor];
    
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"MainStoryboard" bundle:nil];
    UINavigationController *voidableTransactionNavBarController = [storyboard instantiateViewControllerWithIdentifier:@"VoidableTransactionsNavController"];
    UINavigationController *refundNavBarController = [storyboard instantiateViewControllerWithIdentifier:@"RefundsNavController"];
    UINavigationController *settlementNavBarController = [storyboard instantiateViewControllerWithIdentifier:@"SettlementNavController"];
    UINavigationController *reportsNavBarController = [storyboard instantiateViewControllerWithIdentifier:@"TransactionsListNavController"];
    UINavigationController *settingsNavBarController = [storyboard instantiateViewControllerWithIdentifier:@"SettingsNavController"];
    LogoutViewController * logoutViewController = [storyboard instantiateViewControllerWithIdentifier:@"LogoutViewController"];
    UINavigationController *logoutNavBarController = [[UINavigationController alloc] initWithRootViewController:logoutViewController];
    UINavigationController *tipAdjustementNavBarController = [storyboard instantiateViewControllerWithIdentifier:@"TipAdjustementNavController"];
    
    affiliateIndexPaths = [[NSMutableArray alloc] init];
    settlementIndexPaths = [[NSMutableArray alloc] init];
    voidIndexPaths = [[NSMutableArray alloc] init];
    refundsIndexPaths = [[NSMutableArray alloc] init];
    
    menuOptionsSections = [[NSMutableArray alloc] init];
    
    MenuSection *mainOperationsSection = [[MenuSection alloc] init];
    mainOperationsSection.menuSectionName = @"Autorización";
    mainOperationsSection.menuOptions = [[NSMutableArray alloc] init];
    [menuOptionsSections addObject:mainOperationsSection];
    
    // Read all the Affiliates of the terminal and add them under the "Sales" Group
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    
    for (Affiliate *affiliate in userInfo.terminalInfo.terminal.affiliatesWithSalePermissions) {
        MenuOption *affiliateAuthOption = [[MenuOption alloc] init];
        affiliateAuthOption.menuOptionName = affiliate.affiliateTitle;
        UINavigationController *affiliateNavigationController = [storyboard instantiateViewControllerWithIdentifier:@"SaleNavigationController"];
        SaleMainViewController *affiliateViewController = [affiliateNavigationController.viewControllers objectAtIndex:0];
        affiliateViewController.saleAffiliate = affiliate;
        affiliateAuthOption.menuOptionViewController = affiliateNavigationController;
        [mainOperationsSection.menuOptions addObject:affiliateAuthOption];
        // Add the Index Path of the Affiliate to the Affiliates Array so we can disable the Affiliate in case the user doesnt have the permissions.
        [affiliateIndexPaths addObject:[NSIndexPath indexPathForItem:[mainOperationsSection.menuOptions count]-1 inSection:0]];
    }
    
    MenuSection *posActionsSection = [[MenuSection alloc] init];
    posActionsSection.menuSectionName = @"Administrativo";
    posActionsSection.menuOptions = [[NSMutableArray alloc] init];
    [menuOptionsSections addObject:posActionsSection];
    
    MenuOption *tipAdjustementOption = [[MenuOption alloc] init];
    tipAdjustementOption.menuOptionName = @"Ajuste de Propina";
    tipAdjustementOption.menuOptionViewController = tipAdjustementNavBarController;
    [posActionsSection.menuOptions addObject:tipAdjustementOption];
    // Add the Index Path of the Void to the Voids Array so we can disable the Void section in case the user doesnt have the permissions.
    //[voidIndexPaths addObject:[NSIndexPath indexPathForItem:[posActionsSection.menuOptions count]-1 inSection:1]];
    
    MenuOption *salesVoidOption = [[MenuOption alloc] init];
    salesVoidOption.menuOptionName = @"Anulación";
    salesVoidOption.menuOptionViewController = voidableTransactionNavBarController;
    [posActionsSection.menuOptions addObject:salesVoidOption];
    // Add the Index Path of the Void to the Voids Array so we can disable the Void section in case the user doesnt have the permissions.
    [voidIndexPaths addObject:[NSIndexPath indexPathForItem:[posActionsSection.menuOptions count]-1 inSection:1]];
    
    MenuOption *salesRefundOption = [[MenuOption alloc] init];
    salesRefundOption.menuOptionName = @"Devolución";
    salesRefundOption.menuOptionViewController = refundNavBarController;
    [posActionsSection.menuOptions addObject:salesRefundOption];
    // Add the Index Path of the Refund to the Refunds Array so we can disable the Refunds section in case the user doesnt have the permissions.
    [refundsIndexPaths addObject:[NSIndexPath indexPathForItem:[posActionsSection.menuOptions count]-1 inSection:1]];
    
    MenuOption *terminalSettlementOption = [[MenuOption alloc] init];
    terminalSettlementOption.menuOptionName = @"Cierre";
    terminalSettlementOption.menuOptionViewController = settlementNavBarController;
    [posActionsSection.menuOptions addObject:terminalSettlementOption];
    // Add the Index Path of the Settlement to the Settlements Array so we can disable the Settlement section in case the user doesnt have the permissions.
    [settlementIndexPaths addObject:[NSIndexPath indexPathForItem:[posActionsSection.menuOptions count]-1 inSection:1]];
    
    MenuOption *reportsOption = [[MenuOption alloc] init];
    reportsOption.menuOptionName = @"Reportes";
    reportsOption.menuOptionViewController = reportsNavBarController;
    [posActionsSection.menuOptions addObject:reportsOption];
    
    MenuSection *miscSection = [[MenuSection alloc] init];
    miscSection.menuSectionName = @"Misc.";
    miscSection.menuOptions = [[NSMutableArray alloc] init];
    [menuOptionsSections addObject:miscSection];
    
    MenuOption *settingsOption = [[MenuOption alloc] init];
    settingsOption.menuOptionName = @"Configuración";
    settingsOption.menuOptionViewController = settingsNavBarController;
    [miscSection.menuOptions addObject:settingsOption];
    
    MenuOption *logoutOption = [[MenuOption alloc] init];
    logoutOption.menuOptionName = @"Salir";
    logoutOption.menuOptionViewController = logoutNavBarController;
    [miscSection.menuOptions addObject:logoutOption];
    
    logoutIndexPath = [NSIndexPath indexPathForItem:1 inSection:2];

    for (int i = 0; i < [menuOptionsSections count]; ++i){
        MenuSection *menuSection = [menuOptionsSections objectAtIndex:i];
        //NSLog(@"MenuSection : %@", menuSection.menuSectionName);
        for (int j = 0; j < [menuSection.menuOptions count]; ++j){
            MenuOption *menuOption = [menuSection.menuOptions objectAtIndex:j];
            //NSLog(@"MenuOption : %@", menuOption.menuOptionName);
            lastIndexPathSelected = [NSIndexPath indexPathForItem:j inSection:i];
            if ([self userCanSelectOperation:lastIndexPathSelected]){
                i = [menuOptionsSections count];
                break;
            }
        }
    }
    [menuOptionsTableView selectRowAtIndexPath:lastIndexPathSelected animated:YES scrollPosition:UITableViewScrollPositionNone];
    [self tableView:menuOptionsTableView didSelectRowAtIndexPath:lastIndexPathSelected];
    
    // When the center view controller is shown, show the left pane and the hide it again (to show the user the pane its there).
    [self.viewDeckController toggleLeftViewAnimated:YES completion:^(IIViewDeckController *controller, BOOL success) {
        [self.viewDeckController closeLeftViewBouncing:^(IIViewDeckController *controller) {
        }];
    }];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)userCanSelectOperation:(NSIndexPath *)indexPath{
    // Check if the user can make the selected operation.
    BOOL allowedOperation = TRUE;
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    if (!userInfo.terminalInfo.userCanMakeSales){
        if ([affiliateIndexPaths indexOfObject:indexPath] != NSNotFound){
            // The user cant make sales and the selected index is a Sale
            allowedOperation = FALSE;
        }
    }
    
    if (!userInfo.terminalInfo.userCanSettleTerminal){
        if ([settlementIndexPaths indexOfObject:indexPath] != NSNotFound){
            // The user cant settle the terminal and the selected index is a Terminal Settlement option
            allowedOperation = FALSE;
        }
    }
    
    return allowedOperation;
}

#pragma mark UITableViewDataSource Methods

-(int)numberOfSectionsInTableView:(UITableView *)tableView{
    return [menuOptionsSections count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    MenuSection *menuSection = [menuOptionsSections objectAtIndex:section];
    return [menuSection.menuOptions count];
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    MenuOptionsCell *cell = (MenuOptionsCell*)[tableView dequeueReusableCellWithIdentifier:@"SlidingMenuCell"];
    // then set the properties for the class.
    // Configure the cell.
    MenuSection *menuSection = [menuOptionsSections objectAtIndex:indexPath.section];
    MenuOption *menuOption = [menuSection.menuOptions objectAtIndex:indexPath.row];
    cell.cellTextLabel.text = menuOption.menuOptionName;
    UIImageView *selectedBackgroundImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Options_Menu_Cell_Selected_Background"]];
    cell.selectedBackgroundView = selectedBackgroundImageView;
    
    cell.cellTextLabel.textColor = [UIColor whiteColor];
    cell.cellTextLabel.highlightedTextColor = [UIColorList credomaticBlueColor];
    cell.backgroundColor = [UIColor clearColor];
    return cell;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    MenuSection *menuSection = [menuOptionsSections objectAtIndex:section];
    return  menuSection.menuSectionName;
}


#pragma mark UITableViewDataDelegate Methods

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSLog(@"Row Index %d", indexPath.row);
    if (indexPath.section == logoutIndexPath.section && indexPath.row == logoutIndexPath.row){
        // Logout Menu Option
        UIAlertView *logoutAlertView = [[UIAlertView alloc] initWithTitle:@"Cierre de Sesión" message:@"¿Desea cerrar la sesión de usuario actual?" delegate:self cancelButtonTitle:@"No" otherButtonTitles:@"Sí", nil];
        logoutAlertView.tag = LogoutAlertViewTag;
        [logoutAlertView show];
    }
    else{
        
        if ([self userCanSelectOperation:indexPath]){
            
            UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
            if (userInfo.sessionInfo.currentTransactionInfo == nil || isReselectingOldSelection){
                lastIndexPathSelected = indexPath;
                MenuSection *menuSection = [menuOptionsSections objectAtIndex:indexPath.section];
                MenuOption *menuOption = [menuSection.menuOptions objectAtIndex:indexPath.row];
                if (!isReselectingOldSelection){
                    UINavigationController *menuRootNavController = (UINavigationController *)menuOption.menuOptionViewController;
                    [menuRootNavController popToRootViewControllerAnimated:NO];
                }
                isReselectingOldSelection = NO;
                self.viewDeckController.centerController = menuOption.menuOptionViewController;
                [self.viewDeckController closeLeftViewBouncing:^(IIViewDeckController *controller) {
                    [NSThread sleepForTimeInterval:(300+arc4random()%700)/1000000.0]; // mimic delay... not really necessary
                }];
            }else{
                UIAlertView *transactionInProgessAlertView = [[UIAlertView alloc] initWithTitle:@"Transacción en Progreso" message:@"Actualmente posee una transacción en progreso. Si continua perderá estos datos. ¿Desea continuar?" delegate:self cancelButtonTitle:@"Cancelar" otherButtonTitles:@"Sí, continuar.", nil];
                transactionInProgessAlertView.tag = TransactionInProgressAlertViewTag;
                [transactionInProgessAlertView show];
            }
        }else{
            UIAlertView *cantMakeOperationAlertView = [[UIAlertView alloc] initWithTitle:@"Permisos de Usuario" message:@"Su usuario no posee los permisos para realizar la operación seleccionada. Por favor contacte a soporte técnico." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
            cantMakeOperationAlertView.tag = 1;
            [cantMakeOperationAlertView show];
        }
    }

}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    MenuOptionsSectionViewController *menuOptionsSectionViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"MenuOptionsSectionViewController"];
    menuOptionsSectionViewController.sectionTitle = [self tableView:menuOptionsTableView titleForHeaderInSection:section];
    return menuOptionsSectionViewController.view;
}

#pragma mark UIAlertViewDelegate Methods

-(void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex{
    if (alertView.tag == LogoutAlertViewTag){
        if (buttonIndex != alertView.cancelButtonIndex){
            self.HUD.labelText = @"Cerrando Sesión";
            [self.HUD show:YES];
            // Do Logout
            LoginManager *loginManager = [[LoginManager alloc] init];
            loginManager.loginManagerDelegate = self;
            [loginManager doLogout];
        }else{
            // Cancel Button Pressed
            isReselectingOldSelection = YES;
            [menuOptionsTableView selectRowAtIndexPath:lastIndexPathSelected animated:YES scrollPosition:UITableViewScrollPositionMiddle];
            [self tableView:menuOptionsTableView didSelectRowAtIndexPath:lastIndexPathSelected];
        }
    }else if (alertView.tag == ErrorAlertViewTag){
        isReselectingOldSelection = YES;
        [menuOptionsTableView selectRowAtIndexPath:lastIndexPathSelected animated:YES scrollPosition:UITableViewScrollPositionMiddle];
        [self tableView:menuOptionsTableView didSelectRowAtIndexPath:lastIndexPathSelected];
    }else if (alertView.tag == TransactionInProgressAlertViewTag){
        if (buttonIndex != alertView.cancelButtonIndex){
            // Change the selection and erase the current transaction information
            isReselectingOldSelection = NO;
            UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
            userInfo.sessionInfo.currentTransactionInfo = nil;
            [menuOptionsTableView selectRowAtIndexPath:menuOptionsTableView.indexPathForSelectedRow animated:YES scrollPosition:UITableViewScrollPositionMiddle];
            [self tableView:menuOptionsTableView didSelectRowAtIndexPath:menuOptionsTableView.indexPathForSelectedRow];
        }else{
            isReselectingOldSelection = YES;
            [menuOptionsTableView selectRowAtIndexPath:lastIndexPathSelected animated:YES scrollPosition:UITableViewScrollPositionMiddle];
            [self tableView:menuOptionsTableView didSelectRowAtIndexPath:lastIndexPathSelected];
        }
    }
}

#pragma mark LoginManagerDelegate Method

- (void)logoutResponseReceived:(BOOL)logoutResult error:(NSError *)error{
    [self.HUD hide:YES];
    NSLog(@"LogoutResultReceived: %d", logoutResult);
    
    /*if (logoutResult){
        [self performSegueWithIdentifier:@"MainToLoginSegue" sender:self];
    }else{
        UIAlertView *errorAlertView = [[UIAlertView alloc] initWithTitle:@"Cierre de Sesión" message:error.localizedDescription delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        errorAlertView.delegate = self;
        errorAlertView.tag = ErrorAlertViewTag;
        [errorAlertView show];
    }*/
    
    // No matter what's the response from the server, take the user to the login view
    [self performSegueWithIdentifier:@"MainToLoginSegue" sender:self];
}

-(void)viewDeckController:(IIViewDeckController *)viewDeckController didCloseViewSide:(IIViewDeckSide)viewDeckSide animated:(BOOL)animated{
    if (viewDeckSide == IIViewDeckLeftSide){
        NSLog(@"Close Left");
        MenuSection *menuSection = [menuOptionsSections objectAtIndex:lastIndexPathSelected.section];
        MenuOption *menuOption = [menuSection.menuOptions objectAtIndex:lastIndexPathSelected.row];
        if (menuOption.menuOptionViewController.class == [UINavigationController class]){
            // The real view controller is at index 0 of the navigation stack
            UINavigationController *navController = (UINavigationController *)menuOption.menuOptionViewController;
            UIViewController *viewController = [navController.viewControllers objectAtIndex:[navController.viewControllers count]-1];
            if ([viewController isKindOfClass:[BaseViewController class]]){
                BaseViewController *baseViewController = (BaseViewController *)viewController;
                [baseViewController continueEditingAfterLeftMenuCloses];
                
                if ([baseViewController respondsToSelector:@selector(setNeedsStatusBarAppearanceUpdate)]){
                    baseViewController.currentStatusBarStyle = UIStatusBarStyleLightContent;
                    [baseViewController setNeedsStatusBarAppearanceUpdate];
                }
            }
        }
    }
}

-(void)viewDeckController:(IIViewDeckController *)viewDeckController didOpenViewSide:(IIViewDeckSide)viewDeckSide animated:(BOOL)animated{

}

- (void)viewDeckController:(IIViewDeckController *)viewDeckController willOpenViewSide:(IIViewDeckSide)viewDeckSide animated:(BOOL)animated{
    if (viewDeckSide == IIViewDeckLeftSide){
        NSLog(@"Open Left");
        MenuSection *menuSection = [menuOptionsSections objectAtIndex:lastIndexPathSelected.section];
        MenuOption *menuOption = [menuSection.menuOptions objectAtIndex:lastIndexPathSelected.row];
        if (menuOption.menuOptionViewController.class == [UINavigationController class]){
            // The real view controller is at index 0 of the navigation stack
            UINavigationController *navController = (UINavigationController *)menuOption.menuOptionViewController;
            UIViewController *viewController = [navController.viewControllers objectAtIndex:[navController.viewControllers count]-1];
            if ([viewController isKindOfClass:[BaseViewController class]]){
                BaseViewController *baseViewController = (BaseViewController *)viewController;
                [baseViewController.view endEditing:YES];
                
                if ([baseViewController respondsToSelector:@selector(setNeedsStatusBarAppearanceUpdate)]){
                    baseViewController.currentStatusBarStyle = UIStatusBarStyleDefault;
                    [baseViewController setNeedsStatusBarAppearanceUpdate];
                }
            }
        }
    }
}

- (void)viewDeckController:(IIViewDeckController *)viewDeckController willCloseViewSide:(IIViewDeckSide)viewDeckSide animated:(BOOL)animated{
}

@end
