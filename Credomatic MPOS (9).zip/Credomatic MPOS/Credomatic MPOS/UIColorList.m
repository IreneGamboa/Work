/*
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  UIColorList.m
//  Zimple POS
//

#import "UIColorList.h"

@implementation UIColorList

+ (UIColor *)textFieldTextColor{
    return [UIColorList credomaticBlueColor];
}

+ (UIColor *)textFieldPlaceholderColor{
    return [UIColor colorWithR:87 G:116 B:173 A:1];
}

+ (UIColor *)textFieldBorderColor{
    return [UIColor colorWithR:119 G:141 B:185 A:1];
}

+ (UIColor *)credomaticBlueColor{
    return [UIColor colorWithR:10 G:51 B:139 A:1];
}

+ (UIColor *)credomaticGrayColor{
    return [UIColor colorWithR:119 G:119 B:119 A:1];
}

+ (UIColor *)lightBlueColor{
    return [UIColor colorWithR:90 G:115 B:180 A:1];
}

+ (UIColor *)transactionColorSale{
    // Sales are represented by a Green Color
    return [UIColor colorWithR:40 G:177 B:86 A:1];
}

+ (UIColor *)transactionColorVoid{
    // Voids are represented by a Purple Color
    return [UIColor colorWithR:96 G:92 B:161 A:1];
}

+ (UIColor *)transactionColorSettlement{
    // Settlements are represented by a Red Color
    return [UIColor colorWithR:159 G:0 B:18 A:1];
}

+ (UIColor *)transactionColorRefund{
    // Refunds are represented by a Orange Color
    return [UIColor colorWithR:241 G:96 B:47 A:1];
}

+ (UIColor *)transactionColorTipAdjustement{
    // Refunds are represented by a Yellow Color
    return [UIColor colorWithR:255 G:244 B:30 A:1];
}

+ (UIColor *)barButtonTintColor{
    return [UIColor colorWithR:0 G:143 B:197 A:1];
}

@end
