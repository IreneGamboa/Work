/********************************************** 
 * CONFIDENTIAL AND PROPRIETARY 
 *
 * The source code and other information contained herein is the confidential and the exclusive property of
 * ZIH Corp. and is subject to the terms and conditions in your end user license agreement.
 * This source code, and any other information contained herein, shall not be copied, reproduced, published, 
 * displayed or distributed, in whole or in part, in any medium, by any means, for any purpose except as
 * expressly permitted under such license agreement.
 * 
 * Copyright ZIH Corp. 2012
 *
 * ALL RIGHTS RESERVED 
 ***********************************************/

#import <Foundation/Foundation.h>
#import "LineaSDK.h"
#import "ZebraPrinterConnection.h"

/**
 * Establishes a Bluetooth connection to a printer using an IPC sled.
 * \remarks You need to include the External Accessory framework in your project to be able to use this class
 * \remarks You need to include the IPC protocol strings "com.datecs.linea.pro.msr" and "com.datecs.linea.pro.bar" in your info.plist file under "Supported external accessory protocols"
 * \remarks You need to include the IPC static library in your app for the class to work.
 * \remarks You need to Set the key "Required Background modes" to "App Communicates with an accessory" in your app's plist file
 * \code
 #import <ExternalAccessory/ExternalAccessory.h>
 #import "LineaBtPrinterConnection.h"
 -(void)sendZplOverBluetooth{
 
    // Instantiate connection to Zebra Bluetooth printer through a Linea IPC Sled
     id<ZebraPrinterConnection, NSObject> thePrinterConn = [[LineaBtPrinterConnection alloc] initWithMacAddress:@"001122334455" andWithPin:@"1234"];
     
     // Open the connection - physical connection is established here.
     BOOL success = [thePrinterConn open];
     
     // This example prints "This is a ZPL test." near the top of the label.
     NSString *zplData = @"^XA^FO20,20^A0N,25,25^FDThis is a ZPL test.^FS^XZ";
     
     NSError *error = nil;
     // Send the data to printer as a byte array.
     success = success && [thePrinterConn write:[zplData dataUsingEncoding:NSUTF8StringEncoding] error:&error];
     
     if (success != YES || error != nil) {
         UIAlertView *errorAlert = [[UIAlertView alloc] initWithTitle:@"Error" message:[error localizedDescription] delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
         [errorAlert show];
         [errorAlert release];
     }
     // Close the connection to release resources.
     [thePrinterConn close];
     
     [thePrinterConn release];
 }
 
 -(void)sendCpclOverBluetooth {
 
    // Instantiate connection to Zebra Bluetooth printer through a Linea IPC Sled
     id<ZebraPrinterConnection, NSObject> thePrinterConn = [[LineaBtPrinterConnection alloc] initWithMacAddress:@"001122334455" andWithPin:@"1234"];
     
     // Open the connection - physical connection is established here.
     BOOL success = [thePrinterConn open];
     
     // This example prints "This is a CPCL test." near the top of the label.
     NSString *cpclData = @"! 0 200 200 210 1\r\nTEXT 4 0 30 40 This is a CPCL test.\r\nFORM\r\nPRINT\r\n";
     
     NSError *error = nil;
     // Send the data to printer as a byte array.
     success = success && [thePrinterConn write:[cpclData dataUsingEncoding:NSUTF8StringEncoding] error:&error];
     
     if (success != YES || error != nil) {
         UIAlertView *errorAlert = [[UIAlertView alloc] initWithTitle:@"Error" message:[error localizedDescription] delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
         [errorAlert show];
         [errorAlert release];
     }
     
     // Close the connection to release resources.
     [thePrinterConn close];
     
     [thePrinterConn release];
 }
 
-(void)sampleWithGCD {
    //Dispatch this task to the default queue
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^ {
         // Instantiate connection to Zebra Bluetooth printer through a Linea IPC Sled
         id<ZebraPrinterConnection, NSObject> thePrinterConn = [[LineaBtPrinterConnection alloc] initWithMacAddress:@"001122334455" andWithPin:@"1234"];

        // Open the connection - physical connection is established here.
        BOOL success = [thePrinterConn open];

        // This example prints "This is a ZPL test." near the top of the label.
        NSString *zplData = @"^XA^FO20,20^A0N,25,25^FDThis is a ZPL test.^FS^XZ";

        NSError *error = nil;
        // Send the data to printer as a byte array.
        success = success && [thePrinterConn write:[zplData dataUsingEncoding:NSUTF8StringEncoding] error:&error];

        //Dispath GUI work back on to the main queue!
        dispatch_async(dispatch_get_main_queue(), ^{
            if (success != YES || error != nil) {
                UIAlertView *errorAlert = [[UIAlertView alloc] initWithTitle:@"Error" message:[error localizedDescription] delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                [errorAlert show];
                [errorAlert release];
            }
        });

        // Close the connection to release resources.
        [thePrinterConn close];

        [thePrinterConn release];

    });
}
 * \endcode
 */
@interface LineaBtPrinterConnection : NSObject<ZebraPrinterConnection,LineaDelegate>
{
    @private BOOL didLineaConnect;
    @private BOOL m_isConnected;
    @private NSInteger maxTimeoutForRead;
    @private NSInteger timeToWaitForMoreData;
    @private NSInteger timeToWaitAfterWrite;
}


/**
 * Initializes a new instance of the LineaBtPrinterConnection class. This constructor will use the default timeouts for
 * ZebraPrinterConnection::read:. The default timeout is a maximum of 5 seconds for any data to be
 * received. If no more data is available after 500 milliseconds the read operation is assumed to be complete.<br/>
 * To specify timeouts other than the defaults, use:<br/>
 * LineaBtPrinterConnection::initWithMacAddress:withPin:withMaxTimeoutForRead:andWithTimeToWaitForMoreData:
 * 
 * @param aMacAddress The device's MAC address.
 * @param pinCode The device's pin code.
 */
-(id)initWithMacAddress:(NSString*)aMacAddress andWithPin:(NSString*)pinCode;

/**
 * Initializes a new instance of the LineaBtPrinterConnection class. This constructor will use the specified timeouts
 * for ZebraPrinterConnection::read:. The timeout is a maximum of <c>maxTimeoutForRead</c> milliseconds for any data to be received.
 * If no more data is available after <c>timeToWaitForMoreData</c> milliseconds the read operation is assumed to be complete.
 * 
 * @param aMacAddress The device's MAC address.
 * @param pinCode The device's pin code.
 * @param aMaxTimeoutForRead The maximum time, in milliseconds, to wait for any data to be received.
 * @param aTimeToWaitForMoreData The maximum time, in milliseconds, to wait in-between reads after the initial read.
 */
-(id)initWithMacAddress:(NSString*)aMacAddress withPin:(NSString*)pinCode withMaxTimeoutForRead:(NSInteger)aMaxTimeoutForRead andWithTimeToWaitForMoreData:(NSInteger)aTimeToWaitForMoreData;

/**
 * Overrides the time the write: method will wait after writing data to the stream. The default time is 10ms. This method is used to adapt to different
 * Bluetooth radio performance requirements. If you notice an issue writing bytes, try increasing this time.
 *
 * @param aTimeInMs Time in milliseconds to wait between writes.
 */
-(void)setTimeToWaitAfterWriteInMilliseconds:(NSInteger)aTimeInMs;

@end
