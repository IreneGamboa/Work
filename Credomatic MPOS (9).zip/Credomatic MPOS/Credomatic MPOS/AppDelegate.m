/*
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  AppDelegate.m
//  Zimple POS
//

#import "AppDelegate.h"

@implementation AppDelegate

@synthesize locationManager;
@synthesize locationDelegate;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    // Override point for customization after application launch.
    
    // Configure Localytics account
    [[LocalyticsSession shared] startSession:LocalyticsKey];
    
    // Configure Crashlytics account
    [Crashlytics startWithAPIKey:CrashlyticsKey];
    
    
    if (floor(NSFoundationVersionNumber) <= NSFoundationVersionNumber_iOS_6_1) {
        // Load resources for iOS 6.1 or earlier
        [[UIBarButtonItem appearance] setTintColor:[UIColorList credomaticBlueColor]];
        
        [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"Blue_NavBar"] forBarMetrics:UIBarMetricsDefault];
        if (IS_IPHONE_5){
            // The iPhone 5 needs a separate image for the nav var (the screen is wider in landscape mode)
            [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"Blue_NavBar_Landscape_Widescreen"] forBarMetrics:UIBarMetricsLandscapePhone];
        }else{
            [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"Blue_NavBar_Landscape"] forBarMetrics:UIBarMetricsLandscapePhone];
        }
        
    } else {
        // Load resources for iOS 7 or later
        //self.window.tintColor = [UIColorList credomaticBlueColor];
        
        [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"Blue_NavBar_iOS7"] forBarMetrics:UIBarMetricsDefault];
        if (IS_IPHONE_5){
            // The iPhone 5 needs a separate image for the nav var (the screen is wider in landscape mode)
            [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"Blue_NavBar_Landscape_Widescreen_iOS7"] forBarMetrics:UIBarMetricsLandscapePhone];
        }else{
            [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"Blue_NavBar_Landscape_iOS7"] forBarMetrics:UIBarMetricsLandscapePhone];
        }
        
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
        // All the elements in a Navigation Bar, including Back Button and Bar Buttons, the color must be white.
        [[UINavigationBar appearance] setTintColor:[UIColor whiteColor]];
        // All the Bar Buttons must be set to white.
        [[UIBarButtonItem appearance] setTintColor:[UIColor whiteColor]];
    }
    
    // Check if the device is Jailbroken
    //if ([self isJailbreakDevice]){
        //self.window.hidden = NO;
        //[self.window.rootViewController performSegueWithIdentifier:@"ActivateTerminalToJailbreakSegue" sender:self.window.rootViewController];
    //}else{
        // The device is not Jailbroken, continue.
        // Check if the terminal name has been saved before
        // If the terminal name saved in the defaults is empty, the terminal must be activated in order to continue.
        NSString *terminalName = [SettingsManager getTerminalNameUserDefault];
        if (terminalName == nil || [terminalName isEqualToString:@""]){
            // Terminal not registered yet, follow the regular app startup flow
        }else{
            // Terminal already registered, break the regular app startup flow and load the login controller
            NSLog(@"Terminal already registered as %@", [SettingsManager getTerminalNameUserDefault]);
            // Set the TerminalId in the UserInfo with the terminal name saved in the user defaults
            UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
            userInfo.terminalId = terminalName;
            self.window.hidden = NO;
            [self.window.rootViewController performSegueWithIdentifier:@"TerminalActivationToLoginSegueNoAnimation" sender:self.window.rootViewController];
             
        }
    //}
    
    // Create the location manager if this object does not
    // already have one.
    if (locationManager == nil){
        locationManager = [[CLLocationManager alloc] init];
    }
    if (locationDelegate == nil){
        locationDelegate = [[LocationDelegate alloc] init];
    }
    locationManager.delegate = locationDelegate;
    if (CLLocationManager.significantLocationChangeMonitoringAvailable){
        [locationManager startMonitoringSignificantLocationChanges];
    }else{
        [locationManager startUpdatingLocation];
    }
    
    [self.window makeKeyAndVisible];

    return YES;
}
							
- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    
    [[LocalyticsSession shared] close];
    [[LocalyticsSession shared] upload];
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    
    [[LocalyticsSession shared] close];
    [[LocalyticsSession shared] upload];
    
    if (CLLocationManager.significantLocationChangeMonitoringAvailable){
        [locationManager stopMonitoringSignificantLocationChanges];
    }else{
        [locationManager stopUpdatingLocation];
    }
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    
    [[LocalyticsSession shared] resume];
    [[LocalyticsSession shared] upload];
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    
    [[LocalyticsSession shared] resume];
    [[LocalyticsSession shared] upload];
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    
    [[LocalyticsSession shared] close];
    [[LocalyticsSession shared] upload];
}

- (BOOL)isJailbreakDevice{
    FILE *f = fopen("/bin/bash", "r");
    BOOL isbash = NO;
    if (f != NULL)
    {
        //Device is jailbroken
        isbash = YES;
    }
    fclose(f);
    
    return isbash;
}

- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations {
    // If it's a relatively recent event, turn off updates to save power
    CLLocation* location = [locations lastObject];
    NSLog(@"latitude %+.6f, longitude %+.6f\n", location.coordinate.latitude, location.coordinate.longitude);
    NSDate* eventDate = location.timestamp;
    NSTimeInterval howRecent = [eventDate timeIntervalSinceNow];
    if (abs(howRecent) < 15.0) {
        // If the event is recent, do something with it.
        NSLog(@"New latitude %+.6f, longitude %+.6f\n", location.coordinate.latitude, location.coordinate.longitude);
        UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
        userInfo.userLocation = location;
    }
}


@end
