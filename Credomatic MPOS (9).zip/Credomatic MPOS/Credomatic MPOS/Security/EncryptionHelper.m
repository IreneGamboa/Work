/*
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  EncryptionHelper.m
//  Zimple POS
//

// Set the Public Key Certificate File Name. When is compiled as Debug, use the Development Environment Public Key.
// When compiled as Release, use the Production Environment Public Key.
#ifdef DEBUG
#define PublicKeyFileName @"SeverRSA_x509PublicKey_Development.pem"
#else
#define PublicKeyFileName @"SeverRSA_x509PublicKey_Production.pem"
#endif

#import "EncryptionHelper.h"

@implementation EncryptionHelper

#pragma mark -
#pragma mark RSA Encryption

+ (NSString *)getRSAPublicEncryptionKey{

    RSA *rsaManager = [[RSA alloc] init];
    
    return [rsaManager getX509FormattedPublicKey];
    
}

+ (NSString *)getRSAPrivateEncryptionKey{
    RSA *rsaManager = [[RSA alloc] init];
    
    return [rsaManager getPEMFormattedPrivateKey];
}

+ (BOOL)isRSAPublicKeyInKeyChain{
    RSA *rsaManager = [[RSA alloc] init];
    
    NSString *publicKeyInKeychain = [rsaManager getX509FormattedPublicKey];
    
    if ([publicKeyInKeychain compare:@""] == 0){
        return FALSE;
    }
    return TRUE;
}

+ (BOOL)isRSAPrivateKeyInKeyChain{
    RSA *rsaManager = [[RSA alloc] init];
    
    NSString *privateKeyInKeychain = [rsaManager getPEMFormattedPrivateKey];
    
    if ([privateKeyInKeychain compare:@""] == 0){
        return FALSE;
    }
    return TRUE;
}

+ (NSString *)configureRSAEncryption{
    NSString *localRSAPublicKey = @"";
    RSA *rsaManager = [[RSA alloc] init];
    // First, check if the Public and Private Keys are stored in the Keychain
    if ([self isRSAPublicKeyInKeyChain] == TRUE && [self isRSAPrivateKeyInKeyChain] == TRUE){
    }else{
        // This is a new device, must generate the keys and sent them to the backend
        // The Public Key is not available, must generate a pair and save it into the Keychain for later use.
        [rsaManager generateKeyPair];
    }
    localRSAPublicKey = [rsaManager getX509FormattedPublicKey];
    return localRSAPublicKey;
}

+ (NSString *)decryptRSA:(NSString *)messageToDecrypt{
    RSA *rsaManager = [[RSA alloc] init];
    
    return [rsaManager decryptWithPrivateKey:messageToDecrypt];
}

+ (NSString *)encryptRSAWithPublicKeyFromServer:(NSString *)messageToEncrypt{
    RSA *rsaManager = [[RSA alloc] init];
    
    // Import Public Key string from bundle:
    NSError *error = nil;
     NSString *publicKeyString = [NSString stringWithContentsOfFile:[[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:PublicKeyFileName] encoding:NSUTF8StringEncoding error:&error];
     // Add public key to keychain:
     [rsaManager setServerPublicKey:publicKeyString];
    
    return [rsaManager encryptWithServerPublicKey:messageToEncrypt];
}

+ (NSString *)encryptUsingSymmetricAES256:(NSString *)message{
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    // Encrypt AES 256
    NSData *data = [message dataUsingEncoding:NSUTF8StringEncoding];
    NSData *encrypted = [data AES256EncryptWithKey:userInfo.sessionInfo.aes256SymmetricEncryptionKey initVect:userInfo.sessionInfo.aes256SymmetricEncryptionIV];
    if (encrypted != nil){
        //NSLog(@"Encrypted");
        NSString *encryptedStr = [encrypted base64EncodedString];
        return encryptedStr;
    }else{
        //NSLog(@"Encryption Failed");
    }
    return @"";
}

+ (NSString *)decryptUsingSymmetricAES256:(NSString *)message{
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    // Decrypt AES 256
    NSData *data = [NSData dataFromBase64String:message];
    NSData *Decrypted = [data AES256DecryptWithKey:userInfo.sessionInfo.aes256SymmetricEncryptionKey initVect:userInfo.sessionInfo.aes256SymmetricEncryptionIV];
    if (Decrypted != nil){
        //NSLog(@"Decrypted");
        NSString *decryptedStr = [[NSString alloc] initWithData:Decrypted encoding:NSUTF8StringEncoding];
        return decryptedStr;
    }else{
        //NSLog(@"Decryption Failed");
    }
    return @"";
}

@end
