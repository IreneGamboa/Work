/*
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  ChangePasswordViewController.m
//  Zimple POS
//

#import "ChangePasswordViewController.h"

#define CurrentPasswordTextFieldTag 0
#define NewPasswordTextFieldTag 1
#define NewPasswordConfirmationTextFieldTag 2
#define ChangePasswordButtonTag 3
#define PasswordsDontMatchAlertViewTag 4
#define PasswordChangedAlertViewTag 5
#define ErrorAlertViewTag 100

@interface ChangePasswordViewController ()

@property (weak, nonatomic) UITextField *activeField;

@end

@implementation ChangePasswordViewController

@synthesize scrollView;
@synthesize contentView;
@synthesize titleLabel;
@synthesize descriptionLabel;
@synthesize currentPasswordTextField;
@synthesize passwordNewTextField;
@synthesize passwordNewConfirmationTextField;
@synthesize changePasswordButton;
@synthesize activeField;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    changePasswordButton.enabled = FALSE;
    [self registerForKeyboardNotifications];
    
    scrollView.backgroundColor = [UIColor clearColor];
    contentView.backgroundColor = [UIColor clearColor];
    
    titleLabel.textColor = [UIColorList credomaticBlueColor];
    descriptionLabel.textColor = [UIColorList credomaticGrayColor];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)changePasswordButtonTouchUpInside:(id)sender {
    [self.view endEditing:YES];
    [currentPasswordTextField resignFirstResponder];
    [passwordNewTextField resignFirstResponder];
    [passwordNewConfirmationTextField resignFirstResponder];
    
    // Check that both the new password, and the confirmation, match each other
    if ([passwordNewTextField.text isEqualToString:passwordNewConfirmationTextField.text]){
        self.HUD.labelText = @"Cambiando Contraseña";
        [self.HUD show:YES];
        LoginManager *loginManager = [[LoginManager alloc] init];
        loginManager.loginManagerDelegate = self;
        [loginManager changeUserPassword:currentPasswordTextField.text newPassword:passwordNewTextField.text];
    }else{
        // Passwords dont match
        UIAlertView *passwordsDontMatchAlertView = [[UIAlertView alloc] initWithTitle:@"Cambio de Contraseña" message:@"La nueva contraseña no coincide con la confirmación de la misma. Por favor revise que ambas coinciden e intente nuevamente." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        passwordsDontMatchAlertView.tag = PasswordsDontMatchAlertViewTag;
        [passwordsDontMatchAlertView show];
    }
}

- (void)registerForKeyboardNotifications
{
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWasShown:)
                                                 name:UIKeyboardDidShowNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillBeHidden:)
                                                 name:UIKeyboardWillHideNotification object:nil];
    
}

// Called when the UIKeyboardDidShowNotification is sent.
- (void)keyboardWasShown:(NSNotification*)aNotification
{
    NSDictionary* info = [aNotification userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    NSLog(@"%f %f", kbSize.width, kbSize.height);
    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0.0, 0.0, kbSize.height, 0.0);
    scrollView.contentInset = contentInsets;
    scrollView.scrollIndicatorInsets = contentInsets;
    
    CGRect aRect = self.view.frame;
    aRect.size.height -= kbSize.height;
    CGPoint origin = activeField.frame.origin;
    origin.y -= scrollView.contentOffset.y;
    
    origin.y += self.activeField.frame.size.height;
    origin.y +=self.activeField.frame.origin.y + self.activeField.frame.size.height;
    
    if (!CGRectContainsPoint(aRect, origin) ) {
        CGPoint scrollPoint = CGPointMake(0.0, activeField.frame.origin.y-(aRect.size.height) + 44);
        [scrollView setContentOffset:scrollPoint animated:YES];
    }
}

// Called when the UIKeyboardWillHideNotification is sent
- (void)keyboardWillBeHidden:(NSNotification*)aNotification
{
    UIEdgeInsets contentInsets = UIEdgeInsetsZero;
    scrollView.contentInset = contentInsets;
    scrollView.scrollIndicatorInsets = contentInsets;
}

- (void)checkParameters:(NSString *)password passwordNew:(NSString *)passwordNew passwordNewConfirmation:(NSString *)passwordNewConfirmation{
    BOOL correctParameters = TRUE;
    
    if (![RegularExpressionsValidator matchRegExWithValue:PasswordRegEx value:password]){
        correctParameters = FALSE;
        [currentPasswordTextField hasCorrectValues:NO];
    }else{
        [currentPasswordTextField hasCorrectValues:YES];
    }
    
    if (![RegularExpressionsValidator matchRegExWithValue:PasswordRegEx value:passwordNew]){
        correctParameters = FALSE;
        [passwordNewTextField hasCorrectValues:NO];
    }else{
        [passwordNewTextField hasCorrectValues:YES];
    }
    
    if (![RegularExpressionsValidator matchRegExWithValue:PasswordRegEx value:passwordNewConfirmation]){
        correctParameters = FALSE;
        [passwordNewConfirmationTextField hasCorrectValues:NO];
    }else{
        [passwordNewConfirmationTextField hasCorrectValues:YES];
    }
    
    changePasswordButton.enabled = correctParameters;
}

#pragma mark - UITextField Delegate Methods

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    
    if (textField.tag == CurrentPasswordTextFieldTag){
        [self checkParameters:newString passwordNew:passwordNewTextField.text passwordNewConfirmation:passwordNewConfirmationTextField.text];
    }else if (textField.tag == NewPasswordTextFieldTag){
        [self checkParameters:currentPasswordTextField.text passwordNew:newString passwordNewConfirmation:passwordNewConfirmationTextField.text];
    }else if (textField.tag == NewPasswordConfirmationTextFieldTag){
        [self checkParameters:currentPasswordTextField.text passwordNew:passwordNewTextField.text passwordNewConfirmation:newString];
    }
    
    return YES;
}

- (BOOL)textFieldShouldClear:(UITextField *)textField{
    
    if (textField.tag == CurrentPasswordTextFieldTag){
        [self checkParameters:@"" passwordNew:passwordNewTextField.text passwordNewConfirmation:passwordNewConfirmationTextField.text];
    }else if (textField.tag == NewPasswordTextFieldTag){
        [self checkParameters:currentPasswordTextField.text passwordNew:@"" passwordNewConfirmation:passwordNewConfirmationTextField.text];
    }
    else if (textField.tag == NewPasswordConfirmationTextFieldTag){
        [self checkParameters:currentPasswordTextField.text passwordNew:passwordNewTextField.text passwordNewConfirmation:@""];
    }
    
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    activeField = textField;
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    activeField = nil;
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    
    if (textField.tag == CurrentPasswordTextFieldTag){
        // Switch to New Password Textfield
        [passwordNewTextField becomeFirstResponder];
    }else if (textField.tag == NewPasswordTextFieldTag){
        // Switch to New Password Confirmation Textfield
        [passwordNewConfirmationTextField becomeFirstResponder];
    }else if (textField.tag == NewPasswordConfirmationTextFieldTag){
        // Change Password
        if (changePasswordButton.enabled == YES){
            [self changePasswordButtonTouchUpInside:changePasswordButton];
        }
    }
    
    return YES;
}

#pragma mark UIAlertViewDelegate Methods

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView.tag == PasswordsDontMatchAlertViewTag){
        // Do nothing
    }else if (alertView.tag == PasswordChangedAlertViewTag){
        currentPasswordTextField.text = @"";
        passwordNewTextField.text = @"";
        passwordNewConfirmationTextField.text = @"";
        [currentPasswordTextField resignFirstResponder];
        [passwordNewTextField resignFirstResponder];
        [passwordNewConfirmationTextField resignFirstResponder];
        
        UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
        if (userInfo.terminalInfo.mustChangePassword){
            // Password changed
            userInfo.terminalInfo.mustChangePassword = NO;
            [self performSegueWithIdentifier:@"ChangePasswordToMainSegue" sender:self];
        }else{
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
    }else if (alertView.tag == ErrorAlertViewTag){
        currentPasswordTextField.text = @"";
        passwordNewTextField.text = @"";
        passwordNewConfirmationTextField.text = @"";
    }
}

#pragma mark LoginManagerDelegate Methods

- (void)changeUserPasswordResponseReceived:(BOOL)changeUserPasswordResult error:(NSError *)error{
    [self.HUD hide:YES];
    //NSLog(@"ChangeUserPasswordResultReceived: %d", changeUserPasswordResult);
    
    if (changeUserPasswordResult){
        UIAlertView *passwordChangedAlertView = [[UIAlertView alloc] initWithTitle:@"Cambio de Contraseña" message:@"Su contraseña se ha cambiado de forma exitosa." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        passwordChangedAlertView.tag = PasswordChangedAlertViewTag;
        [passwordChangedAlertView show];
    }else{
        if (![super checkSessionExpiration:error]){
            UIAlertView *errorAlertView = [[UIAlertView alloc] initWithTitle:@"Cambio de Contraseña" message:error.localizedDescription delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
            errorAlertView.delegate = self;
            errorAlertView.tag = ErrorAlertViewTag;
            [errorAlertView show];
        }
    }
}

- (void)viewDidUnload {
    [self setTitleLabel:nil];
    [self setContentView:nil];
    [self setDescriptionLabel:nil];
    [super viewDidUnload];
}
@end
