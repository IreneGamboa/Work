/*
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  LoginManager.m
//  Zimple POS
//

#import "LoginManager.h"

#define SuppressPerformSelectorLeakWarning(Stuff) \
do { \
_Pragma("clang diagnostic push") \
_Pragma("clang diagnostic ignored \"-Warc-performSelector-leaks\"") \
Stuff; \
_Pragma("clang diagnostic pop") \
} while (0)

@implementation LoginManager

@synthesize loginManagerDelegate;
@synthesize sessionHandshakeContinueSelector;
@synthesize sessionHandshakeContinueErrorSelector;
@synthesize continueValues;

- (BOOL)isSessionHandshakeDone{
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    if (userInfo.sessionInfo.aes256SymmetricEncryptionKey != nil && ![userInfo.sessionInfo.aes256SymmetricEncryptionKey isEqualToString:@""]){
        return YES;
    }
    return NO;
}

- (void)activateTerminal:(NSString *)terminalId activationToken:(NSString *)activationToken{

    NSString *localPublicKey = [EncryptionHelper configureRSAEncryption];
    //NSLog(@"Public Key: %@", localPublicKey);
    
    ZimpleServices *zimpleServices = [[ZimpleServices alloc] init];
    zimpleServices.zimpleBackendServicesDelegate = self;
    [zimpleServices activateTerminal:terminalId localPublicKey:localPublicKey activationToken:activationToken];
}

- (void)doLogin:(NSString *)username password:(NSString *)password{
    continueValues = [[NSMutableArray alloc] init];
    [continueValues addObject:username];
    [continueValues addObject:password];
    NSLog(@"=====================\nStarting Login Process:");
    /*
     The Login Process is:
     
     1 - Start the Session Handshake
     2 - Finish the Session Handshake
     3 - Send the Login Request to the server.
     */
    
    /*if ([self isSessionHandshakeDone]){
        // Session Handshake already done, just call the continueLoginMethod
        [self continueLoginProcess:continueValues];
    }else{
        // Session Handshake not done yet, done it before continuing with login
        // Tell that when the handshake is done, call continueLoginProcess
        sessionHandshakeContinueSelector = @selector(continueLoginProcess:);
        // 1
        [self startSessionHandshake];
    }*/
    sessionHandshakeContinueSelector = @selector(continueLoginProcess:);
    sessionHandshakeContinueErrorSelector = @selector(sessionHandshakeErrorForLogin:);
    // 1
    [self startSessionHandshake];
}

- (void)startSessionHandshake{
    NSLog(@"=====================\n\tStarting Session Handshake:");
    /*
     1 - The Start of the Session Handshake Process is:
     
     1.1 - Generate a GUID and remove the dashes. The first half of this GUID is the first half of the Symmetric encryption key (AES 256) and the whole GUID is the IV for the first block in AES 256.
     1.1 - This GUID must be RSA-encrypted using the server RSA Public Key for transport.
     1.1 - Send the encrypted values to the server to make the session handshake.
     
    */
    // 1.1
    NSString *uuid = [NSString GenerateUUID];
    uuid = [uuid stringByReplacingOccurrencesOfString:@"-" withString:@""];
    //NSLog(@"Session GUID: %@", uuid);
    // Save the values in the Session Info for later use
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    // Set the AES 256 Symmetric Encryption Key as the whole uuid for the moment (will me update with values from the server later)
    userInfo.sessionInfo.aes256SymmetricEncryptionKey = uuid;
    userInfo.sessionInfo.aes256SymmetricEncryptionIV = uuid;
    
    // 1.1
    NSString *encryptedKeyFirstHalfAndIV = [EncryptionHelper encryptRSAWithPublicKeyFromServer:uuid];
    //NSLog(@"Encrypted Session GUID: %@", encryptedKeyFirstHalfAndIV);
    
    // 1.1
    ZimpleServices *zimpleServices = [[ZimpleServices alloc] init];
    zimpleServices.zimpleBackendServicesDelegate = self;
    [zimpleServices getSessionHandshake:userInfo.terminalId encryptedKeyFirstHalfAndIV:encryptedKeyFirstHalfAndIV];
}

- (void)finishSessionHandshakeProcess:(NSString *)encryptedSecondHalfKey{
    NSLog(@"=====================\n\tContinuing Session Handshake:");
    /*
     2 - The Finish of the Session Handshake Process is:
     
     2.1 - Get the handshake response from the server, which is encrypted using the Server RSA private key, and decrypt it using the Server RSA public key.
     2.2 - Generate the AES 256 Symmetric encryption key by using the first half of the generated GUID and the value returned from the handshake by the server.
     2.2 - Encrypt with AES 256 the Login Request and send it to the server.
     */
    
    //NSLog(@"Server Half Key: %@", encryptedSecondHalfKey);
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    // 2.1
    // Decrypt the Second Half Key using the Server Public Key
    RSA *rsaManager = [[RSA alloc] init];
    NSString *decryptedSecondHalfKey = [rsaManager decryptWithPrivateKey:encryptedSecondHalfKey];
    //NSLog(@"Decrypted Second Half Key: %@", decryptedSecondHalfKey);
    //NSLog(@"SecondHalf: %d", [decryptedSecondHalfKey length]);
     
    // 2.2
    NSString *symmetricFirstHalfKey = [userInfo.sessionInfo.aes256SymmetricEncryptionKey substringToIndex:16];
    //NSLog(@"FirstHalf: %d", [symmetricFirstHalfKey length]);
    NSString *symmetricEncriptionKey = [NSString stringWithFormat:@"%@%@", symmetricFirstHalfKey, decryptedSecondHalfKey];
    // 2.2
    //NSLog(@"Symmetric Encryption Key: %@",  symmetricEncriptionKey);
    userInfo.sessionInfo.aes256SymmetricEncryptionKey = symmetricEncriptionKey;
    NSLog(@"=====================\nSession Handshake Finished:");
    
    //[self continueLoginProcess];
    SuppressPerformSelectorLeakWarning([self performSelector:sessionHandshakeContinueSelector withObject:continueValues]);
    //[self performSelector:sessionHandshakeContinueSelector];
}

- (void)continueLoginProcess:(NSMutableArray *)values{
    NSLog(@"=====================\n\tContinuing Login Process:");
    /*
     3 - With the Session Handshake established, continue the Login Process:
     
     3.1 - Encrypt the payload message using the AES 256 Symmetric Key for the session.
     3.2 - Sent the request to the server.
     */
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    ZimpleServices *zimpleServices = [[ZimpleServices alloc] init];
    zimpleServices.zimpleBackendServicesDelegate = self;
    
    NSString *username = [values objectAtIndex:0];
    NSString *password = [values objectAtIndex:1];
    [zimpleServices login:userInfo.terminalId username:username password:password];
}

- (void)sessionHandshakeErrorForLogin:(NSError *)error{
    NSLog(@"=====================\n\Error In Session Handshake for Login Process:");
    [loginManagerDelegate loginResponseReceived:NO error:error];
}

- (void)doLogout{
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    ZimpleServices *zimpleServices = [[ZimpleServices alloc] init];
    zimpleServices.zimpleBackendServicesDelegate = self;
    [zimpleServices logout:userInfo.terminalId];
}

- (void)changeUserPassword:(NSString *)currentPassword newPassword:(NSString *)newPassword{
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    ZimpleServices *zimpleServices = [[ZimpleServices alloc] init];
    zimpleServices.zimpleBackendServicesDelegate = self;
    [zimpleServices changeUserPassword:userInfo.terminalId password:currentPassword newPassword:newPassword];
}

- (void)resetUserPassword:(NSString *)email{
    continueValues = [[NSMutableArray alloc] init];
    [continueValues addObject:email];
    /*if ([self isSessionHandshakeDone]){
        // Session Handshake already done, just call the continueResetPasswordProcess
        [self continueResetPasswordProcess:continueValues];
    }else{
        // Session Handshake not done yet, done it before continuing with Reset User Password
        // Tell that when the handshake is done, call continueResetPasswordProcess
        sessionHandshakeContinueSelector = @selector(continueResetPasswordProcess:);
        // 1
        [self startSessionHandshake];
    }*/
    
    // Tell that when the handshake is done, call continueResetPasswordProcess
    sessionHandshakeContinueSelector = @selector(continueResetPasswordProcess:);
    sessionHandshakeContinueErrorSelector = @selector(sessionHandshakeErrorForResetPassword:);
    // 1
    [self startSessionHandshake];
}

- (void)continueResetPasswordProcess:(NSMutableArray *)values{
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    ZimpleServices *zimpleServices = [[ZimpleServices alloc] init];
    zimpleServices.zimpleBackendServicesDelegate = self;
    NSString *email = [values objectAtIndex:0];
    [zimpleServices resetUserPassword:userInfo.terminalId email:email];
}

- (void)sessionHandshakeErrorForResetPassword:(NSError *)error{
    NSLog(@"=====================\n\Error In Session Handshake for Reset Password Process:");
    [loginManagerDelegate resetUserPasswordResponseReceived:NO error:error];
}

- (void)changeUserPIN:(NSString *)password pin:(NSString *)pin{
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    ZimpleServices *zimpleServices = [[ZimpleServices alloc] init];
    zimpleServices.zimpleBackendServicesDelegate = self;
    [zimpleServices changeUserPIN:userInfo.terminalId password:password pin:pin];
}

#pragma mark ZimpleBackendServicesDelegate Methods

- (void)terminalActivationResponseReceived:(NSData *)responseData error:(NSError *)error{
    NSError *myError;
    if (error == nil){
        NSDictionary* json = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONWritingPrettyPrinted error:&myError];
        
        NSNumber *reasonCode = [json objectForKey:ReasonCodeResponseParameterName];
        //NSLog(@"Reason Code: %@", reasonCode);
        if (reasonCode.intValue == 0){
            [loginManagerDelegate terminalActivationResponseReceived:YES error:nil];
            return;
        }
    }
    
    NSMutableDictionary *details = [NSMutableDictionary dictionary];
    //NSString *reasonCodeStr = [NSString stringWithFormat:@"%d", error.code];
    NSString *reasonCodeStr = [error.userInfo objectForKey:NSLocalizedDescriptionKey];
    [details setValue:NSLocalizedString(reasonCodeStr, @"") forKey:NSLocalizedDescriptionKey];
    error = [NSError errorWithDomain:@"Zimple" code:error.code userInfo:details];
    [loginManagerDelegate terminalActivationResponseReceived:NO error:error];
}

- (void)sessionHandshakeResponseReceived:(NSData *)responseData error:(NSError *)error{
    // When the response of the Session Handshake arrives:
    //  Parse the response
    //  Continue with the login process.
    
    NSError *myError;
    if (error == nil){
        NSDictionary* json = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONWritingPrettyPrinted error:&myError];
        
        NSNumber *reasonCode = [json objectForKey:ReasonCodeResponseParameterName];
        //NSLog(@"Reason Code: %@", reasonCode);
        if (reasonCode.intValue == 0){
            // Continue the Login Process.
            NSString *encryptedKey = [json objectForKey:KeyResponseParameterName];
            [self finishSessionHandshakeProcess:encryptedKey];
            return;
        }
    }

    NSMutableDictionary *details = [NSMutableDictionary dictionary];
    //NSString *reasonCodeStr = [NSString stringWithFormat:@"%d", error.code];
    NSString *reasonCodeStr = [error.userInfo objectForKey:NSLocalizedDescriptionKey];
    [details setValue:NSLocalizedString(reasonCodeStr, @"") forKey:NSLocalizedDescriptionKey];
    error = [NSError errorWithDomain:@"Zimple" code:error.code userInfo:details];
    SuppressPerformSelectorLeakWarning([self performSelector:sessionHandshakeContinueErrorSelector withObject:error]);
    //[loginManagerDelegate loginResponseReceived:NO error:error];
}

- (void)loginResponseReceived:(NSData *)responseData error:(NSError *)error{
    if (responseData != nil){
        NSError *myError;
        if (error == nil){
            NSDictionary* json = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONWritingPrettyPrinted error:&myError];
            
            NSString *messageEncryptedData = [json objectForKey:MessageResponseParameterName];
            //NSLog(@"MessageEncryptedData: %@",messageEncryptedData);
            
            NSString *decryptedJSONString = [EncryptionHelper decryptUsingSymmetricAES256:messageEncryptedData];
            NSLog(@"Decrypted Response: %@", decryptedJSONString);
            
            NSData *decryptedJSONData = [decryptedJSONString dataUsingEncoding:NSUTF8StringEncoding];
            NSDictionary *jsonMessage = [NSJSONSerialization JSONObjectWithData:decryptedJSONData options:NSJSONWritingPrettyPrinted error:nil];
            
            
            NSNumber *reasonCode = [jsonMessage objectForKey:ReasonCodeResponseParameterName];
            //NSLog(@"Reason Code: %@", reasonCode);
            
            if (reasonCode.intValue == 0){
                // Get the Session Key Value from the first level of the message
                NSString *sessionKey = [jsonMessage objectForKey:SessionKeyResponseParameterName];
                UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
                userInfo.sessionInfo.sessionKey = sessionKey;
                
                // Get the terminal_info part of the message (required as a different json to parse automatically with JSONModel)
                NSDictionary *terminalInfoDictionary = [jsonMessage objectForKey:TerminalInfoResponseParameterName] ;
                userInfo.terminalInfo = [[TerminalInfo alloc] initWithDictionary:terminalInfoDictionary error:nil];
                
                /*NSLog(@"Affiliates: %d", [userInfo.terminalInfo.terminal.affiliates count]);
                for (Affiliate *af in userInfo.terminalInfo.terminal.affiliates){
                    NSLog(@"%@", af.currencyCode);
                }
                
                NSLog(@"Terminal Rol Permissions: %d", [userInfo.terminalInfo.terminalRole.terminalPermissions count]);
                for (TerminalPermission *tp in userInfo.terminalInfo.terminalRole.terminalPermissions){
                    NSLog(@"%@", tp.name);
                    NSLog(@"%@", tp.action);
                }*/
                
                [loginManagerDelegate loginResponseReceived:YES error:nil];
                return;
            }
        }
    }
    NSMutableDictionary *details = [NSMutableDictionary dictionary];
    //NSString *reasonCodeStr = [NSString stringWithFormat:@"%d", error.code];
    NSString *reasonCodeStr = [error.userInfo objectForKey:NSLocalizedDescriptionKey];
    [details setValue:NSLocalizedString(reasonCodeStr, @"") forKey:NSLocalizedDescriptionKey];
    error = [NSError errorWithDomain:@"Zimple" code:error.code userInfo:details];
    [loginManagerDelegate loginResponseReceived:NO error:error];
}

- (void)logoutResponseReceived:(NSData *)responseData error:(NSError *)error{
    if (responseData != nil){
        NSError *myError;
        if (error == nil){
            NSDictionary* json = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONWritingPrettyPrinted error:&myError];
            
            NSString *messageEncryptedData = [json objectForKey:MessageResponseParameterName];
            //NSLog(@"MessageEncryptedData: %@",messageEncryptedData);
            
            NSString *decryptedJSONString = [EncryptionHelper decryptUsingSymmetricAES256:messageEncryptedData];
            //NSLog(@"Decrypted Response: %@", decryptedJSONString);
            
            NSData *decryptedJSONData = [decryptedJSONString dataUsingEncoding:NSUTF8StringEncoding];
            NSDictionary *jsonMessage = [NSJSONSerialization JSONObjectWithData:decryptedJSONData options:NSJSONWritingPrettyPrinted error:nil];
            
            
            NSNumber *reasonCode = [jsonMessage objectForKey:ReasonCodeResponseParameterName];
            //NSLog(@"Reason Code: %@", reasonCode);
            
            if (reasonCode.intValue == 0){
                [loginManagerDelegate logoutResponseReceived:YES error:nil];
                return;
            }
        }
    }
    
    NSMutableDictionary *details = [NSMutableDictionary dictionary];
    //NSString *reasonCodeStr = [NSString stringWithFormat:@"%d", error.code];
    NSString *reasonCodeStr = [error.userInfo objectForKey:NSLocalizedDescriptionKey];
    [details setValue:NSLocalizedString(reasonCodeStr, @"") forKey:NSLocalizedDescriptionKey];
    error = [NSError errorWithDomain:@"Zimple" code:error.code userInfo:details];
    [loginManagerDelegate logoutResponseReceived:NO error:error];
}

- (void)changeUserPasswordResponseReceived:(NSData *)responseData error:(NSError *)error{
    if (responseData != nil){
        NSError *myError;
        if (error == nil){
            NSDictionary* json = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONWritingPrettyPrinted error:&myError];
            
            NSString *messageEncryptedData = [json objectForKey:MessageResponseParameterName];
            //NSLog(@"MessageEncryptedData: %@",messageEncryptedData);
            
            NSString *decryptedJSONString = [EncryptionHelper decryptUsingSymmetricAES256:messageEncryptedData];
            //NSLog(@"Decrypted Response: %@", decryptedJSONString);
            
            NSData *decryptedJSONData = [decryptedJSONString dataUsingEncoding:NSUTF8StringEncoding];
            NSDictionary *jsonMessage = [NSJSONSerialization JSONObjectWithData:decryptedJSONData options:NSJSONWritingPrettyPrinted error:nil];
            
            
            NSNumber *reasonCode = [jsonMessage objectForKey:ReasonCodeResponseParameterName];
            //NSLog(@"Reason Code: %@", reasonCode);
            
            if (reasonCode.intValue == 0){
                [loginManagerDelegate changeUserPasswordResponseReceived:YES error:nil];
                return;
            }
        }
    }
    
    NSMutableDictionary *details = [NSMutableDictionary dictionary];
    //NSString *reasonCodeStr = [NSString stringWithFormat:@"%d", error.code];
    NSString *reasonCodeStr = [error.userInfo objectForKey:NSLocalizedDescriptionKey];
    [details setValue:NSLocalizedString(reasonCodeStr, @"") forKey:NSLocalizedDescriptionKey];
    error = [NSError errorWithDomain:@"Zimple" code:error.code userInfo:details];
    [loginManagerDelegate changeUserPasswordResponseReceived:NO error:error];
}

- (void)resetPasswordResponseReceived:(NSData *)responseData error:(NSError *)error{
    if (responseData != nil){
        NSError *myError;
        if (error == nil){
            NSDictionary* json = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONWritingPrettyPrinted error:&myError];
            
            NSString *messageEncryptedData = [json objectForKey:MessageResponseParameterName];
            //NSLog(@"MessageEncryptedData: %@",messageEncryptedData);
            
            NSString *decryptedJSONString = [EncryptionHelper decryptUsingSymmetricAES256:messageEncryptedData];
            //NSLog(@"Decrypted Response: %@", decryptedJSONString);
            
            NSData *decryptedJSONData = [decryptedJSONString dataUsingEncoding:NSUTF8StringEncoding];
            NSDictionary *jsonMessage = [NSJSONSerialization JSONObjectWithData:decryptedJSONData options:NSJSONWritingPrettyPrinted error:nil];
            
            
            NSNumber *reasonCode = [jsonMessage objectForKey:ReasonCodeResponseParameterName];
            //NSLog(@"Reason Code: %@", reasonCode);
            
            if (reasonCode.intValue == 0){
                [loginManagerDelegate resetUserPasswordResponseReceived:YES error:nil];
                return;
            }
        }
    }
    
    NSMutableDictionary *details = [NSMutableDictionary dictionary];
    //NSString *reasonCodeStr = [NSString stringWithFormat:@"%d", error.code];
    NSString *reasonCodeStr = [error.userInfo objectForKey:NSLocalizedDescriptionKey];
    [details setValue:NSLocalizedString(reasonCodeStr, @"") forKey:NSLocalizedDescriptionKey];
    error = [NSError errorWithDomain:@"Zimple" code:error.code userInfo:details];
    [loginManagerDelegate resetUserPasswordResponseReceived:NO error:error];
}

- (void)changeUserPINResponseReceived:(NSData *)responseData error:(NSError *)error{
    if (responseData != nil){
        NSError *myError;
        if (error == nil){
            NSDictionary* json = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONWritingPrettyPrinted error:&myError];
            
            NSString *messageEncryptedData = [json objectForKey:MessageResponseParameterName];
            //NSLog(@"MessageEncryptedData: %@",messageEncryptedData);
            
            NSString *decryptedJSONString = [EncryptionHelper decryptUsingSymmetricAES256:messageEncryptedData];
            //NSLog(@"Decrypted Response: %@", decryptedJSONString);
            
            NSData *decryptedJSONData = [decryptedJSONString dataUsingEncoding:NSUTF8StringEncoding];
            NSDictionary *jsonMessage = [NSJSONSerialization JSONObjectWithData:decryptedJSONData options:NSJSONWritingPrettyPrinted error:nil];
            
            
            NSNumber *reasonCode = [jsonMessage objectForKey:ReasonCodeResponseParameterName];
            //NSLog(@"Reason Code: %@", reasonCode);
            
            if (reasonCode.intValue == 0){
                [loginManagerDelegate changeUserPINResponseReceived:YES error:nil];
                return;
            }
        }
    }
    
    NSMutableDictionary *details = [NSMutableDictionary dictionary];
    //NSString *reasonCodeStr = [NSString stringWithFormat:@"%d", error.code];
    NSString *reasonCodeStr = [error.userInfo objectForKey:NSLocalizedDescriptionKey];
    [details setValue:NSLocalizedString(reasonCodeStr, @"") forKey:NSLocalizedDescriptionKey];
    error = [NSError errorWithDomain:@"Zimple" code:error.code userInfo:details];
    [loginManagerDelegate changeUserPINResponseReceived:NO error:error];
}

@end
