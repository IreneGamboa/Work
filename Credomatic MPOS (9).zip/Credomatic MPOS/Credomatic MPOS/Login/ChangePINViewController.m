/*
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  ChangePINViewController.m
//  Zimple POS
//

#import "ChangePINViewController.h"

#define PasswordTextFieldTag 0
#define PINTextFieldTag 1
#define ChangePINButtonTag 2
#define PINChangedAlertViewTag 3
#define ErrorAlertViewTag 100

#define PINLength 4

@interface ChangePINViewController ()

@property (weak, nonatomic) UITextField *activeField;

@end

@implementation ChangePINViewController

@synthesize scrollView;
@synthesize contentView;
@synthesize titleLabel;
@synthesize descriptionLabel;
@synthesize passwordTextField;
@synthesize pintextField;
@synthesize changePINButton;
@synthesize activeField;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    changePINButton.enabled = FALSE;
    [self registerForKeyboardNotifications];
    
    contentView.backgroundColor = [UIColor clearColor];
    
    titleLabel.textColor = [UIColorList credomaticBlueColor];
    descriptionLabel.textColor = [UIColorList credomaticGrayColor];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)registerForKeyboardNotifications
{
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWasShown:)
                                                 name:UIKeyboardDidShowNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillBeHidden:)
                                                 name:UIKeyboardWillHideNotification object:nil];
    
}

// Called when the UIKeyboardDidShowNotification is sent.
- (void)keyboardWasShown:(NSNotification*)aNotification
{
    NSDictionary* info = [aNotification userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    
    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0.0, 0.0, kbSize.height, 0.0);
    scrollView.contentInset = contentInsets;
    scrollView.scrollIndicatorInsets = contentInsets;
    
    CGRect aRect = self.view.frame;
    aRect.size.height -= kbSize.height;
    CGPoint origin = activeField.frame.origin;
    origin.y -= scrollView.contentOffset.y;
    
    origin.y += self.activeField.frame.size.height;
    origin.y +=self.activeField.frame.origin.y + self.activeField.frame.size.height;
    
    if (!CGRectContainsPoint(aRect, origin) ) {
        CGPoint scrollPoint = CGPointMake(0.0, activeField.frame.origin.y-(aRect.size.height) + 44);
        [scrollView setContentOffset:scrollPoint animated:YES];
    }
}

// Called when the UIKeyboardWillHideNotification is sent
- (void)keyboardWillBeHidden:(NSNotification*)aNotification
{
    UIEdgeInsets contentInsets = UIEdgeInsetsZero;
    scrollView.contentInset = contentInsets;
    scrollView.scrollIndicatorInsets = contentInsets;
}

- (void)checkParameters:(NSString *)password pin:(NSString *)pin{
    BOOL correctParameters = TRUE;
    
    if (![RegularExpressionsValidator matchRegExWithValue:PasswordRegEx value:password]){
        correctParameters = FALSE;
        [passwordTextField hasCorrectValues:NO];
    }else{
        [passwordTextField hasCorrectValues:YES];
    }
    if ([pin isEqualToString:@""] || pin.length < PINLength){
        correctParameters = FALSE;
        [pintextField hasCorrectValues:NO];
    }else{
        [pintextField hasCorrectValues:YES];
    }
    
    changePINButton.enabled = correctParameters;
}


- (IBAction)changePINButtonTouchUpInside:(id)sender {
    [self.view endEditing:YES];
    self.HUD.labelText = @"Cambiando PIN";
    [self.HUD show:YES];
    LoginManager *loginManager = [[LoginManager alloc] init];
    loginManager.loginManagerDelegate = self;
    
    [loginManager changeUserPIN:passwordTextField.text pin:pintextField.text];

}

#pragma mark - UITextField Delegate Methods

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    NSUInteger newLength = [textField.text length] + [string length] - range.length;
    
    if (textField.tag == PasswordTextFieldTag){
        [self checkParameters:newString pin:pintextField.text];
    }else if (textField.tag == PINTextFieldTag){
        
        if (newLength > PINLength){
            return NO;
        }
        
        [self checkParameters:passwordTextField.text pin:newString];
    }
    
    return YES;
}

- (BOOL)textFieldShouldClear:(UITextField *)textField{
    
    if (textField.tag == PasswordTextFieldTag){
        [self checkParameters:@"" pin:pintextField.text];
    }else if (textField.tag == PINTextFieldTag){
        [self checkParameters:passwordTextField.text pin:@""];
    }
    
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    activeField = textField;
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    activeField = nil;
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    
    if (textField.tag == PasswordTextFieldTag){
        // Switch to PIN Textfield
        [pintextField becomeFirstResponder];
    }else if (textField.tag == PINTextFieldTag){
        // Change the user PIN
        if (changePINButton.enabled == YES){
            [self changePINButtonTouchUpInside:changePINButton];
        }
    }
    
    return YES;
}

#pragma mark LoginManagerDelegate Methods

- (void)changeUserPINResponseReceived:(BOOL)changeUserPINResult error:(NSError *)error{
    [self.HUD hide:YES];
    //NSLog(@"ChangeUserPINResultReceived: %d", changeUserPINResult);
    
    if (changeUserPINResult){
        UIAlertView *pinChangedAlertView = [[UIAlertView alloc] initWithTitle:@"Cambio de PIN" message:@"Su PIN se ha cambiado de forma exitosa." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        pinChangedAlertView.tag = PINChangedAlertViewTag;
        [pinChangedAlertView show];
    }else{
        if (![super checkSessionExpiration:error]){
            UIAlertView *errorAlertView = [[UIAlertView alloc] initWithTitle:@"Cambio de PIN" message:error.localizedDescription delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
            errorAlertView.delegate = self;
            errorAlertView.tag = ErrorAlertViewTag;
            [errorAlertView show];
        }
    }
}

#pragma mark UIAlertViewDelegate Methods


- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    passwordTextField.text = @"";
    pintextField.text = @"";
    [passwordTextField resignFirstResponder];
    [pintextField resignFirstResponder];
}

- (void)viewDidUnload {
    [self setTitleLabel:nil];
    [self setContentView:nil];
    [self setDescriptionLabel:nil];
    [super viewDidUnload];
}
@end
