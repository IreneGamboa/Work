/*
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  ForgotPasswordViewController.m
//  Zimple POS
//

#import "ForgotPasswordViewController.h"

#define EmailTextFieldTag 0
#define ResetPasswordOkAlertViewTag 1
#define ErrorAlertViewTag 100

@interface ForgotPasswordViewController ()

@property (weak, nonatomic) UITextField *activeField;

@end

@implementation ForgotPasswordViewController

@synthesize scrollView;
@synthesize contentView;
@synthesize titleLabel;
@synthesize forgotPasswordDescriptionLabel;
@synthesize emailTextField;
@synthesize resetPasswordButton;
@synthesize activeField;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    resetPasswordButton.enabled = FALSE;
    [self registerForKeyboardNotifications];

    titleLabel.textColor = [UIColorList credomaticBlueColor];
    forgotPasswordDescriptionLabel.textColor = [UIColorList credomaticGrayColor];
    
    contentView.backgroundColor = [UIColor clearColor];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)registerForKeyboardNotifications
{
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWasShown:)
                                                 name:UIKeyboardDidShowNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillBeHidden:)
                                                 name:UIKeyboardWillHideNotification object:nil];
    
}

// Called when the UIKeyboardDidShowNotification is sent.
- (void)keyboardWasShown:(NSNotification*)aNotification
{
    NSDictionary* info = [aNotification userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    
    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0.0, 0.0, kbSize.height, 0.0);
    scrollView.contentInset = contentInsets;
    scrollView.scrollIndicatorInsets = contentInsets;
    
    CGRect aRect = self.view.frame;
    aRect.size.height -= kbSize.height;
    CGPoint origin = activeField.frame.origin;
    origin.y -= scrollView.contentOffset.y;
    
    origin.y += self.activeField.frame.size.height;
    origin.y +=self.activeField.frame.origin.y + self.activeField.frame.size.height;
    
    if (!CGRectContainsPoint(aRect, origin) ) {
        CGPoint scrollPoint = CGPointMake(0.0, activeField.frame.origin.y-(aRect.size.height) + 44);
        [scrollView setContentOffset:scrollPoint animated:YES];
    }
}

// Called when the UIKeyboardWillHideNotification is sent
- (void)keyboardWillBeHidden:(NSNotification*)aNotification
{
    UIEdgeInsets contentInsets = UIEdgeInsetsZero;
    scrollView.contentInset = contentInsets;
    scrollView.scrollIndicatorInsets = contentInsets;
}

- (void)checkParameters:(NSString *)email{
    BOOL correctParameters = TRUE;
    
    if (![RegularExpressionsValidator matchRegExWithValue:EmailRegEx value:email]){
        correctParameters = FALSE;
        [emailTextField hasCorrectValues:NO];
    }else{
        [emailTextField hasCorrectValues:YES];
    }
    
    resetPasswordButton.enabled = correctParameters;
}


- (IBAction)resetPasswordButtonTouchUpInside:(id)sender {
    [self.view endEditing:YES];
    self.HUD.labelText = @"Recuperando Contraseña";
    [self.HUD show:YES];
    LoginManager *loginManager = [[LoginManager alloc] init];
    loginManager.loginManagerDelegate = self;
    
    [loginManager resetUserPassword:emailTextField.text];
}

- (IBAction)cancelBarButtonItemTouchUpInside:(id)sender {
    // Return to Login View
    [self performSegueWithIdentifier:@"ResetPasswordToLoginSegue" sender:self];
}

#pragma mark - UITextField Delegate Methods

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    
    if (textField.tag == EmailTextFieldTag){
        [self checkParameters:newString];
    }
    
    return YES;
}

- (BOOL)textFieldShouldClear:(UITextField *)textField{
    
    if (textField.tag == EmailTextFieldTag){
        [self checkParameters:@""];
    }
    
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    activeField = textField;
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    activeField = nil;
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    if (textField.tag == EmailTextFieldTag){
        // Reset the Password
        if (resetPasswordButton.enabled == YES){
            [self resetPasswordButtonTouchUpInside:resetPasswordButton];
        }
    }
    
    return YES;
}

#pragma mark UIAlertViewDelegate Methods

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView.tag == ResetPasswordOkAlertViewTag){
        [self performSegueWithIdentifier:@"ResetPasswordToLoginSegue" sender:self];
    }else if (alertView.tag == ErrorAlertViewTag){
        emailTextField.text = @"";
    }
}

#pragma mark LoginManagerDelegate Methods

- (void)resetUserPasswordResponseReceived:(BOOL)resetUserPasswordResult error:(NSError *)error{
    [self.HUD hide:YES];
    //NSLog(@"ResetUserPasswordResultReceived: %d", resetUserPasswordResult);
    
    if (resetUserPasswordResult){
        
        UIAlertView *resetPasswordOkAlertView = [[UIAlertView alloc] initWithTitle:@"Recordar Contraseña" message:[NSString stringWithFormat:@"Se ha enviado un correo electrónico a la dirección %@ con los pasos para reestablecer su contraseña.", emailTextField.text] delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        resetPasswordOkAlertView.tag = ResetPasswordOkAlertViewTag;
        [resetPasswordOkAlertView show];
    }else{
        UIAlertView *errorAlertView = [[UIAlertView alloc] initWithTitle:@"Recordar Contraseña" message:error.localizedDescription delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        errorAlertView.delegate = self;
        errorAlertView.tag = ErrorAlertViewTag;
        [errorAlertView show];
    }
}

- (void)viewDidUnload {
    [self setTitleLabel:nil];
    [self setForgotPasswordDescriptionLabel:nil];
    [self setContentView:nil];
    [super viewDidUnload];
}
@end
