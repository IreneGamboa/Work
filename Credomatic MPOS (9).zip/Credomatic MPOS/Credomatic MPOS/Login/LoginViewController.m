/*
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  LoginViewController.m
//  Zimple POS
//

#import "LoginViewController.h"

#define UsernameTextFieldTag 0
#define PasswordTextFieldTag 1
#define RememberUsernameSwitchTag 2
#define LoginButtonTag 3
#define ErrorAlertViewTag 100

@interface LoginViewController ()

@property (weak, nonatomic) UITextField *activeField;

@end

@implementation LoginViewController

@synthesize activeField;
@synthesize scrollView;
@synthesize contentView;
@synthesize backgroundImageView;
@synthesize businessLogoImageView;
@synthesize usernameTextField;
@synthesize passwordTextField;
@synthesize rememberUsernameLabel;
@synthesize rememberUsernameSwitch;
@synthesize loginButton;
@synthesize forgotPasswordButton;
@synthesize appEnvironmentLabel;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    rememberUsernameLabel.textColor = [UIColorList credomaticGrayColor];
    
    loginButton.enabled = FALSE;
    [self registerForKeyboardNotifications];
    
    // Check if theres a saved username in the user defaults
    NSString *savedUsername = [SettingsManager getRememberUsernameUserDefault];
    if (savedUsername == nil || [savedUsername isEqualToString:@""]){
       // No user saved, put the remember username switch in off state.
        rememberUsernameSwitch.on = NO;
    }else{
        // Username saved before, load it into the username textfield and change the switch to on state.
        usernameTextField.text = savedUsername;
        rememberUsernameSwitch.on = YES;
    }
    
    [rememberUsernameSwitch setOnTintColor:[UIColorList credomaticBlueColor]];
    
    // Underline the Forgot your password button text.
    NSMutableAttributedString *mat = [forgotPasswordButton.titleLabel.attributedText mutableCopy];
    [mat addAttributes:@{NSUnderlineStyleAttributeName: @(NSUnderlineStyleSingle)} range:NSMakeRange (0, mat.length)];
    forgotPasswordButton.titleLabel.attributedText = mat;
    forgotPasswordButton.titleLabel.textColor = [UIColorList credomaticBlueColor];
    
    contentView.backgroundColor = [UIColor clearColor];
    
    // When in test mode (Test Environment, compiling in Debug Mode), show a label indicating this.
#ifdef DEBUG
    appEnvironmentLabel.text = @"AMBIENTE DE PRUEBAS";
#else
    appEnvironmentLabel.text = @"";
#endif
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)registerForKeyboardNotifications
{
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWasShown:)
                                                 name:UIKeyboardDidShowNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillBeHidden:)
                                                 name:UIKeyboardWillHideNotification object:nil];
    
}

// Called when the UIKeyboardDidShowNotification is sent.
- (void)keyboardWasShown:(NSNotification*)aNotification
{
    NSDictionary* info = [aNotification userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    
    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0.0, 0.0, kbSize.height, 0.0);
    scrollView.contentInset = contentInsets;
    scrollView.scrollIndicatorInsets = contentInsets;
    
    // If active text field is hidden by keyboard, scroll it so it's visible
    // Your application might not need or want this behavior.
    CGRect aRect = scrollView.frame;
    aRect.size.height -= kbSize.height;
    CGPoint activeFieldOriginPlusHeight = activeField.frame.origin;
    activeFieldOriginPlusHeight.y += activeField.frame.size.height;
    if (!CGRectContainsPoint(aRect, activeFieldOriginPlusHeight)) {
        CGPoint scrollPoint = CGPointMake(0.0, activeField.frame.origin.y-kbSize.height);
        [scrollView setContentOffset:scrollPoint animated:YES];
    }
}

// Called when the UIKeyboardWillHideNotification is sent
- (void)keyboardWillBeHidden:(NSNotification*)aNotification
{
    UIEdgeInsets contentInsets = UIEdgeInsetsZero;
    scrollView.contentInset = contentInsets;
    scrollView.scrollIndicatorInsets = contentInsets;
}

- (void)checkParameters:(NSString *)username password:(NSString *)password{
    BOOL correctParameters = TRUE;
    
    if (![RegularExpressionsValidator matchRegExWithValue:EmailRegEx value:username]){
        correctParameters = FALSE;
        [usernameTextField hasCorrectValues:NO];
    }else{
        [usernameTextField hasCorrectValues:YES];
    }
    if (![RegularExpressionsValidator matchRegExWithValue:PasswordRegEx value:password]){
        correctParameters = FALSE;
        [passwordTextField hasCorrectValues:NO];
    }else{
        [passwordTextField hasCorrectValues:YES];
    }
    
    loginButton.enabled = correctParameters;
}

- (IBAction)loginButtonTouchUpInside:(id)sender {
    [self.view endEditing:YES];
    self.HUD.labelText = @"Iniciando Sesión";
    [self.HUD show:YES];
    LoginManager *loginManager = [[LoginManager alloc] init];
    loginManager.loginManagerDelegate = self;
    
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    userInfo.sessionInfo.sessionUserName = usernameTextField.text;

    [loginManager doLogin:userInfo.sessionInfo.sessionUserName password:passwordTextField.text];
}

- (IBAction)rememberUsernameSwitchValueChanged:(id)sender {
}   

- (IBAction)forgotPasswordButtonTouchUpInside:(id)sender {
    [self performSegueWithIdentifier:@"LoginToForgotPasswordSegue" sender:self];
}

- (void)viewDidUnload {
    [self setContentView:nil];
    [super viewDidUnload];
}

#pragma mark - UITextField Delegate Methods

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    
    if (textField.tag == UsernameTextFieldTag){
        [self checkParameters:newString password:passwordTextField.text];
    }else if (textField.tag == PasswordTextFieldTag){
        [self checkParameters:usernameTextField.text password:newString];
    }
    
    return YES;
}

- (BOOL)textFieldShouldClear:(UITextField *)textField{
    
    if (textField.tag == UsernameTextFieldTag){
        [self checkParameters:@"" password:passwordTextField.text];
    }else if (textField.tag == PasswordTextFieldTag){
        [self checkParameters:usernameTextField.text password:@""];
    }
    
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    activeField = textField;
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    activeField = nil;
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    
    if (textField.tag == UsernameTextFieldTag){
        // Switch to Password Textfield
        [passwordTextField becomeFirstResponder];
    }else if (textField.tag == PasswordTextFieldTag){
        // Do Login
        if (loginButton.enabled == YES){
            [self loginButtonTouchUpInside:loginButton];
        }
    }
    
    return YES;
}

#pragma mark UIAlertViewDelegate Methods

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView.tag == ErrorAlertViewTag){
        // Remove the password
        passwordTextField.text = @"";
    }
}

#pragma mark LoginManagerDelegate Methods

- (void)loginResponseReceived:(BOOL)loginResult error:(NSError *)error{
    [self.HUD hide:YES];
    //NSLog(@"LoginResultReceived: %d", loginResult);
    
    if (loginResult){
        // Login Successful, check if the username must be saved in the user defaults.
        NSString *usernameToRemember = @"";
        if (rememberUsernameSwitch.on){
            // Save username
            usernameToRemember = usernameTextField.text;
        }
        [SettingsManager writeRememberUsernameUserDefault:usernameToRemember];
        
        // Check if the user must change the password or not
        UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
        if(userInfo.terminalInfo.mustChangePassword){
            // Create a Navigation Controller with the Change Password View
            ChangePasswordViewController *changePasswordViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"ChangePasswordViewController"];
            UINavigationController *changePasswordNavController = [[UINavigationController alloc] initWithRootViewController:changePasswordViewController];
            [self presentModalViewController:changePasswordNavController animated:YES];
        }else{
            // Log Localytics event
            NSDictionary *dictionary =
            [NSDictionary dictionaryWithObjectsAndKeys:
             userInfo.terminalId,
             LocalyticsEventParameterNameTerminalId,
             userInfo.sessionInfo.sessionUserName,
             LocalyticsEventParameterNameUser,
             nil];
            [[LocalyticsSession shared] tagEvent:LocalyticsEventNameLogin attributes:dictionary];
            
            // Password doesnt have to be changed, proceed to the Main View
            [self performSegueWithIdentifier:@"LoginToMainSegue" sender:self];
        }
    }else{
        UIAlertView *errorAlertView = [[UIAlertView alloc] initWithTitle:@"Inicio de Sesión" message:error.localizedDescription delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        errorAlertView.delegate = self;
        errorAlertView.tag = ErrorAlertViewTag;
        [errorAlertView show];
        NSLog(@"Error: %@", [error description]);
        NSLog(@"Error: %@", error.localizedDescription);
    }
}

- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleDefault;
}

@end
