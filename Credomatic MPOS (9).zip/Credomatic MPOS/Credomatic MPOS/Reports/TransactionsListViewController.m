/*
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  TransactionsListViewController.m
//  Zimple POS
//

#import "TransactionsListViewController.h"

#define ErrorAlertViewTag 1000

#define ReferenceNumberLabelTag 100
#define DateLabelTag 101
#define AmountLabelTag 102
#define BlueArrowImageViewTag 103
#define TransactionTypeLabelTag 104
#define TransactionTypeViewTag 105

@interface TransactionsListViewController ()

@end

@implementation TransactionsListViewController

@synthesize transactionsTableView;
@synthesize noTransactionsLabel;
@synthesize startDateLabel;
@synthesize startDateValueLabel;
@synthesize endDateLabel;
@synthesize endDateValueLabel;
@synthesize transactionTypesLabel;
@synthesize transactionTypesValueLabel;
@synthesize filterBarButton;
@synthesize refreshBarButton;
@synthesize transactionsByAffiliateCode;
@synthesize filterStartDate;
@synthesize filterEndDate;
@synthesize filterTransactionTypeId;
@synthesize filterTransactionTypeName;
@synthesize transactionsListFiltersNavController;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    UIView *tableViewBackgroundView = [[UIView alloc] initWithFrame:transactionsTableView.frame];
    tableViewBackgroundView.backgroundColor = [UIColor clearColor];
    transactionsTableView.backgroundView = tableViewBackgroundView;
    transactionsTableView.backgroundColor = [UIColor clearColor];
    
    noTransactionsLabel.textColor = [UIColorList credomaticGrayColor];
    noTransactionsLabel.hidden = YES;
    
    transactionsByAffiliateCode = [[NSDictionary alloc] init];
    
    transactionsListFiltersNavController = [self.storyboard instantiateViewControllerWithIdentifier:@"TransactionsListFiltersNavController"];
    TransactionsListFiltersViewController *transactionsListFilterViewController = [[transactionsListFiltersNavController viewControllers] objectAtIndex:0];
    transactionsListFilterViewController.transactionsFiltersDelegate = self;
    self.viewDeckController.rightController = transactionsListFiltersNavController;
    self.viewDeckController.rightSize = 10.0f;
    
    filterBarButton = [[UIBarButtonItem alloc] initWithTitle:@"Filtrar" style:UIBarButtonItemStyleBordered target:self action:@selector(filterButtonTouchUpInside:)];
    refreshBarButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemRefresh target:self action:@selector(refreshButtonTouchUpInside:)];
    
    //self.navigationItem.rightBarButtonItems = [[NSArray alloc] initWithObjects:filterBarButton, refreshBarButton, nil];
    self.navigationItem.rightBarButtonItems = [[NSArray alloc] initWithObjects:filterBarButton, nil];
    
    // Set the default filter for the last 7 days and all the transaction types
    filterStartDate = nil;
    filterEndDate = nil;
    filterTransactionTypeId = @"";
    filterTransactionTypeName = @"";
    
    startDateValueLabel.text = @"";
    endDateValueLabel.text = @"";
    transactionTypesValueLabel.text = @"";
    
    if (NSClassFromString(@"UIRefreshControl") != nil) {
        UIRefreshControl *refreshControl = [[UIRefreshControl alloc] init];
        [refreshControl addTarget:self action:@selector(refresh:) forControlEvents:UIControlEventValueChanged];
        [self.transactionsTableView addSubview:refreshControl];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    noTransactionsLabel.hidden = YES;
    
    [transactionsTableView deselectRowAtIndexPath:transactionsTableView.indexPathForSelectedRow animated:YES];
    
    self.viewDeckController.rightController = transactionsListFiltersNavController;
    
    [self refreshTransactions];
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    self.viewDeckController.rightController = nil;
}

- (void)viewDidUnload {
    [self setTransactionsTableView:nil];
    [self setStartDateLabel:nil];
    [self setStartDateValueLabel:nil];
    [self setEndDateLabel:nil];
    [self setEndDateValueLabel:nil];
    [self setTransactionTypesLabel:nil];
    [self setTransactionTypesValueLabel:nil];
    [super viewDidUnload];
}

- (void)refresh:(UIRefreshControl *)refreshControl {
    [self refreshTransactions];
    [refreshControl endRefreshing];
}

- (IBAction)filterButtonTouchUpInside:(id)sender{
    [self.viewDeckController openRightViewAnimated:YES];
}

- (IBAction)refreshButtonTouchUpInside:(id)sender{
    [self refreshTransactions];
}

- (void)refreshTransactions{
    self.HUD.labelText = @"Cargando Transacciones";
    [self.HUD show:YES];
    SalesManager *salesManager = [[SalesManager alloc] init];
    salesManager.salesManagerDelegate = self;
    // First, get all the transactions types for the last 7 days.
    [salesManager getTransactionsList:filterStartDate endDate:filterEndDate transactionType:filterTransactionTypeId];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([segue.identifier isEqualToString:@"TransactionListToRecipeSegue"]){
        RecipeViewController *recipeViewController = segue.destinationViewController;
        
        NSIndexPath *indexPath = transactionsTableView.indexPathForSelectedRow;
        NSString *affiliateCode = [[transactionsByAffiliateCode allKeys] objectAtIndex:indexPath.section];
        NSMutableArray *transactions = [transactionsByAffiliateCode objectForKey:affiliateCode];
        TransactionRecord *transactionRecord = [transactions objectAtIndex:indexPath.row];
        UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
        Affiliate *affiliate = [userInfo.terminalInfo.terminal affiliateByAffiliateCode:affiliateCode];
        
        recipeViewController.transactionTypeId = [NSString stringWithFormat:@"%d",transactionRecord.transactionTypeId];
        recipeViewController.transactionRecord = transactionRecord;
        recipeViewController.transactionRecordCurrency = affiliate.currencyCode;
        recipeViewController.transactionRecordAffiliateBankTerminal = affiliate.bankTerminal;
    }
}

#pragma mark UITableViewDataSource Methods

-(int)numberOfSectionsInTableView:(UITableView *)tableView{
    return [[transactionsByAffiliateCode allKeys] count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSString *affiliateCode = [[transactionsByAffiliateCode allKeys] objectAtIndex:section];
    NSArray *transactions = [transactionsByAffiliateCode objectForKey:affiliateCode];
    return [transactions count];
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"TransactionsListCell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    }
    
    // Configure the cell.
    NSString *affiliateCode = [[transactionsByAffiliateCode allKeys] objectAtIndex:indexPath.section];
    NSMutableArray *transactions = [transactionsByAffiliateCode objectForKey:affiliateCode];
    TransactionRecord *transactionRecord = [transactions objectAtIndex:indexPath.row];
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    Affiliate *affiliate = [userInfo.terminalInfo.terminal affiliateByAffiliateCode:affiliateCode];
    
    UILabel *referenceNumberLabel = (UILabel *)[cell viewWithTag:ReferenceNumberLabelTag];
    UILabel *dateLabel = (UILabel *)[cell viewWithTag:DateLabelTag];
    UILabel *amountLabel = (UILabel *)[cell viewWithTag:AmountLabelTag];
    UILabel *transactionTypeLabel = (UILabel *)[cell viewWithTag:TransactionTypeLabelTag];
    UIView *transactionTypeView = [cell viewWithTag:TransactionTypeViewTag];
    UIImageView *blueArrowImageView = (UIImageView *)[cell viewWithTag:BlueArrowImageViewTag];
    //referenceNumberLabel.text = transactionRecord.saleReferenceNumber;
    //referenceNumberLabel.text = [NSString stringWithFormat:@"**********%@",transactionRecord.creditCardLastDigits];
    referenceNumberLabel.text = transactionRecord.maskedCreditCard;
    dateLabel.text = transactionRecord.transactionDateAndTimeWithFormat;
    amountLabel.text = [NSString stringWithFormat:@"%@ %@", transactionRecord.saleAmountWithFormat, affiliate.currencyCode];
    amountLabel.textColor = [UIColorList credomaticBlueColor];
    blueArrowImageView.hidden = NO;
    UIColor *transactionTypeColor = nil;
    
    NSLayoutConstraint *verticalAlignConstraint = [NSLayoutConstraint constraintWithItem:transactionTypeLabel attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:blueArrowImageView attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0];
    NSLayoutConstraint *topSpaceConstraint = [NSLayoutConstraint constraintWithItem:transactionTypeLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:cell attribute:NSLayoutAttributeTop multiplier:1.0 constant:0];
    
    if (transactionRecord.transactionTypeId == SaleTransactionTypeId.intValue){
        transactionTypeColor = [UIColorList transactionColorSale];
        transactionTypeLabel.text = SaleTransactionTypeName;
        
        for(NSLayoutConstraint *constraint in cell.constraints){
            if (constraint.firstItem == transactionTypeLabel && constraint.secondItem == blueArrowImageView){
                [cell removeConstraint:constraint];
                [cell addConstraint:topSpaceConstraint];
            }
        }
        
    }else if (transactionRecord.transactionTypeId == VoidTransactionTypeId.intValue){
        transactionTypeColor = [UIColorList transactionColorVoid];
        transactionTypeLabel.text = VoidTransactionTypeName;
        if (transactionRecord.creditCardLastDigits == nil){
            referenceNumberLabel.text = transactionRecord.saleReferenceNumber;
        }
        if (transactionRecord.saleAmount == nil){
            amountLabel.text = @"N/A";
            amountLabel.textColor = [UIColorList credomaticGrayColor];
        }
        
        for(NSLayoutConstraint *constraint in cell.constraints){
            if (constraint.firstItem == transactionTypeLabel && constraint.secondItem == blueArrowImageView){
                [cell removeConstraint:constraint];
                [cell addConstraint:topSpaceConstraint];
            }
        }
    }else if (transactionRecord.transactionTypeId == SettlementTransactionTypeId.intValue){
        transactionTypeColor = [UIColorList transactionColorSettlement];
        transactionTypeLabel.text = SettlementTransactionTypeName;
        referenceNumberLabel.text = transactionRecord.saleReferenceNumber;
        // The Settlement transactions dont have detail (voucher)
        blueArrowImageView.hidden = YES;
        // The Settlement transactions dont have an amount.
        amountLabel.textColor = [UIColorList credomaticGrayColor];
        //amountLabel.text = @"N/A";
        amountLabel.text = @"";
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        for(NSLayoutConstraint *constraint in cell.constraints){
            if (constraint.firstItem == transactionTypeLabel && constraint.secondItem == cell){
                [cell removeConstraint:constraint];
                [cell addConstraint:verticalAlignConstraint];
            }
        }
    }else if (transactionRecord.transactionTypeId == RefundTransactionTypeId.intValue){
        transactionTypeLabel.text = RefundTransactionTypeName;
        transactionTypeColor = [UIColorList transactionColorRefund];
        
        for(NSLayoutConstraint *constraint in cell.constraints){
            if (constraint.firstItem == transactionTypeLabel && constraint.secondItem == blueArrowImageView){
                [cell removeConstraint:constraint];
                [cell addConstraint:topSpaceConstraint];
            }
        }
    }else if (transactionRecord.transactionTypeId == TipAdjustementTransactionTypeId.intValue){
        transactionTypeLabel.text = TipAdjustementTransactionTypeName;
        transactionTypeColor = [UIColorList transactionColorTipAdjustement];
        
        for(NSLayoutConstraint *constraint in cell.constraints){
            if (constraint.firstItem == transactionTypeLabel && constraint.secondItem == blueArrowImageView){
                [cell removeConstraint:constraint];
                [cell addConstraint:topSpaceConstraint];
            }
        }
    }else{
        transactionTypeLabel.text = @"";
        transactionTypeColor = [UIColor clearColor];
        
        for(NSLayoutConstraint *constraint in cell.constraints){
            if (constraint.firstItem == transactionTypeLabel && constraint.secondItem == blueArrowImageView){
                [cell removeConstraint:constraint];
                [cell addConstraint:topSpaceConstraint];
            }
        }
    }
    transactionTypeView.backgroundColor = transactionTypeColor;
    
    return cell;
}

#pragma mark UITableViewDataDelegate Methods
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *affiliateCode = [[transactionsByAffiliateCode allKeys] objectAtIndex:indexPath.section];
    NSMutableArray *transactions = [transactionsByAffiliateCode objectForKey:affiliateCode];
    TransactionRecord *transactionRecord = [transactions objectAtIndex:indexPath.row];
    
    if (transactionRecord.transactionTypeId != SettlementTransactionTypeId.intValue){
        // The Settlement transactions dont have a Voucher
        [self performSegueWithIdentifier:@"TransactionListToRecipeSegue" sender:self];

    }
}

-(UIView *) tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    static NSString *CellIdentifier = @"TableViewAffiliateHeader";
    UITableViewCell *headerView = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    UILabel *sectionTitleLabel = (UILabel *)[headerView viewWithTag:1];
    if (headerView == nil){
        [NSException raise:@"headerView == nil.." format:@"No cells with matching CellIdentifier loaded from your storyboard"];
    }
    // Set the Affiliate Name in the header
    NSString *affiliateCode = [[transactionsByAffiliateCode allKeys] objectAtIndex:section];
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    Affiliate *affiliate = [userInfo.terminalInfo.terminal affiliateByAffiliateCode:affiliateCode];
    sectionTitleLabel.text = [affiliate affiliateTitle];
    
    return headerView;
}

#pragma mark SalesManagerDelegate Methods

- (void)getTransactionsListResponseReceived:(NSDictionary *)transactionsByAffiliateCode error:(NSError *)error{
    [self.HUD hide:YES];
    //NSLog(@"GetVoidableTransactionsResponseReceived: %@", transactionsByAffiliateCode);
    
    if (transactionsByAffiliateCode != nil){
        self.transactionsByAffiliateCode = transactionsByAffiliateCode;
        [transactionsTableView reloadData];
        [transactionsTableView setContentOffset:CGPointZero animated:YES];
        
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"dd/MM/yyyy"];
        if (filterStartDate == nil){
            // Default - Now - 7 days (last week)
            NSDateComponents *dayComponent = [[NSDateComponents alloc] init];
            dayComponent.day = -7;
            
            NSCalendar *theCalendar = [NSCalendar currentCalendar];
            NSDate *todayMinusSevenDays = [theCalendar dateByAddingComponents:dayComponent toDate:[NSDate date] options:0];
            
            startDateValueLabel.text = [dateFormatter stringFromDate:todayMinusSevenDays];
        }else{
            startDateValueLabel.text = [dateFormatter stringFromDate:filterStartDate];
        }
        if (filterEndDate == nil){
            // Default / Now
            endDateValueLabel.text = [dateFormatter stringFromDate:[NSDate date]];
        }else{
            endDateValueLabel.text = [dateFormatter stringFromDate:filterEndDate];
        }
        
        if ([filterTransactionTypeId isEqualToString:@""])  {
            // Default - All Transaction Types
            transactionTypesValueLabel.text = @"Todos los Tipos";
        }else{
            transactionTypesValueLabel.text = filterTransactionTypeName;
        }
        
        BOOL hasTransactions = NO;
        for(id key in self.transactionsByAffiliateCode) {
            NSArray *transactions = [self.transactionsByAffiliateCode objectForKey:key];
            if ([transactions count] != 0){
                noTransactionsLabel.hidden = YES;
                hasTransactions = YES;
                break;
            }
            
        }
        if (!hasTransactions){
            noTransactionsLabel.hidden = NO;
        }
        
    }else{
        if (![super checkSessionExpiration:error]){
            UIAlertView *errorAlertView = [[UIAlertView alloc] initWithTitle:@"Reportes" message:error.localizedDescription delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
            errorAlertView.delegate = self;
            errorAlertView.tag = ErrorAlertViewTag;
            [errorAlertView show];
        }
    }
}

#pragma mark TransactionsFiltersDelegate Methods

- (void)filterTransactionsBy:(NSDate *)startDate endDate:(NSDate *)endDate transactionTypeId:(NSString *)transactionTypeId transactionTypeName:(NSString *)transactionTypeName{
    // Close the filter right-side view.
    [self.viewDeckController closeRightViewAnimated:YES];
    
    filterStartDate = startDate;
    filterEndDate = endDate;
    filterTransactionTypeId = transactionTypeId;
    filterTransactionTypeName = transactionTypeName;
    
    [self refreshTransactions];
}

@end
