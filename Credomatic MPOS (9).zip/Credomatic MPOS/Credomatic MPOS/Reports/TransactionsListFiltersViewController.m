/*
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  TransactionsListFiltersViewController.m
//  Zimple POS
//

#import "TransactionsListFiltersViewController.h"

#define StartDateTableViewSection 0
#define EndDateTableViewSection 1
#define TransactionTypeTableViewSection 2

#define DatePickerTag 0
#define TransactionTypePickerTag 1

@interface TransactionsListFiltersViewController ()

@end

@implementation TransactionsListFiltersViewController

@synthesize transactionsFiltersDelegate;
@synthesize titleLabel;
@synthesize transactionFiltersTableView;
@synthesize pickerView;
@synthesize datePicker;
@synthesize transactionTypePicker;
@synthesize pickerViewCancelBarButton;
@synthesize pickerViewSelectBarButton;
@synthesize pickerViewVerticalSpaceToBottomConstraint;
@synthesize transactionTypes;
@synthesize selectedIndexPath;
@synthesize startDate;
@synthesize endDate;
@synthesize transactionTypeKey;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    if (floor(NSFoundationVersionNumber) <= NSFoundationVersionNumber_iOS_6_1) {
        [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"Gray_NavBar"] forBarMetrics:UIBarMetricsDefault];
    }else{
        [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"Gray_NavBar_iOS7"] forBarMetrics:UIBarMetricsDefault];
    }
    
    pickerViewCancelBarButton.tintColor = nil;
    pickerViewSelectBarButton.tintColor = nil;
    
    UIView *tableViewBackgroundView = [[UIView alloc] initWithFrame:transactionFiltersTableView.frame];
    tableViewBackgroundView.backgroundColor = [UIColor clearColor];
    transactionFiltersTableView.backgroundView = tableViewBackgroundView;
    transactionFiltersTableView.backgroundColor = [UIColor clearColor];
    
    titleLabel.textColor = [UIColorList credomaticBlueColor];
    
    transactionFiltersTableView.separatorColor = [UIColorList lightBlueColor];
    transactionFiltersTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    transactionFiltersTableView.backgroundView.hidden = YES;
    
    [self hidePickerView:NO];
    
    transactionTypes = [[NSMutableDictionary alloc] init];
    [transactionTypes setObject:AllTransactionTypesId forKey:AllTransactionTypesName];
    [transactionTypes setObject:SaleTransactionTypeId forKey:SaleTransactionTypeName];
    [transactionTypes setObject:VoidTransactionTypeId forKey:VoidTransactionTypeName];
    [transactionTypes setObject:RefundTransactionTypeId forKey:RefundTransactionTypeName];
    [transactionTypes setObject:SettlementTransactionTypeId forKey:SettlementTransactionTypeName];
    [transactionTypes setObject:TipAdjustementTransactionTypeId forKey:TipAdjustementTransactionTypeName];
    
    selectedIndexPath = nil;
    // By deafult, the start and end date are today, and all the transaction types are selected.
    startDate = [NSDate date];
    endDate = [NSDate date];
    transactionTypeKey = AllTransactionTypesName;
    
    self.navigationItem.rightBarButtonItem.tintColor = [UIColorList credomaticBlueColor];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
    [self setTransactionFiltersTableView:nil];
    [self setPickerView:nil];
    [self setDatePicker:nil];
    [self setTransactionTypePicker:nil];
    [self setPickerViewVerticalSpaceToBottomConstraint:nil];
    [self setTitleLabel:nil];
    [self setPickerViewCancelBarButton:nil];
    [self setPickerViewSelectBarButton:nil];
    [super viewDidUnload];
}

-(IBAction)cancelButtonTouchUpInside{
    //NSLog(@"Cancel");
    [transactionFiltersTableView reloadData];
    [self hidePickerView:YES];
}

-(IBAction)doneButtonTouchUpInside{
    //NSLog(@"Done");
    [self hidePickerView:YES];
    if (selectedIndexPath.section == StartDateTableViewSection){
        startDate = datePicker.date;
        // If startDate is later than the end date, set the start date as the end date, since the end date cannot be earlier than the start date
        endDate = [endDate laterDate:startDate];
    }else if(selectedIndexPath.section == EndDateTableViewSection){
        // If startDate is later than the end date, set the start date as the end date, since the end date cannot be earlier than the start date
        endDate = [datePicker.date laterDate:startDate];
    }else if (selectedIndexPath.section == TransactionTypeTableViewSection){
        int selectedIndex = [transactionTypePicker selectedRowInComponent:0];
        transactionTypeKey = [[transactionTypes allKeys] objectAtIndex:selectedIndex];
    }
    
    [transactionFiltersTableView reloadData];
}

-(IBAction)filterBarButtonTouchUpInside{
    // Filter the report with the selected values
    [transactionsFiltersDelegate filterTransactionsBy:startDate endDate:endDate transactionTypeId:[transactionTypes objectForKey:transactionTypeKey] transactionTypeName:transactionTypeKey];
}

- (void)showPickerView:(BOOL)animated{
    // Set the picker dock to the bottom of the screen, setting the bottom vertical space to the self.view to a 0.
    pickerViewVerticalSpaceToBottomConstraint.constant = 0;
    [self.view setNeedsUpdateConstraints];
    
    if (animated){
        [UIView animateWithDuration:0.5f
                         animations:^{
                             [self.view layoutIfNeeded];
                         }];
    }
}

- (void)hidePickerView:(BOOL)animated{
    // Set the picker view off the screen, setting the bottom vertical space to the self.view to a value larger than the picker view itself.
    pickerViewVerticalSpaceToBottomConstraint.constant = -260;
    [self.view setNeedsUpdateConstraints];
    
    if (animated){
        [UIView animateWithDuration:0.5f
                        animations:^{
                            [self.view layoutIfNeeded];
                        }];
    }
}

- (void)chooseStartDate{
    datePicker.hidden = NO;
    transactionTypePicker.hidden = YES;
    [datePicker setDate:startDate animated:YES];
    [self showPickerView:YES];
}

- (void)chooseEndDate{
    datePicker.hidden = NO;
    transactionTypePicker.hidden = YES;
    // If startDate is later than the end date, set the start date as the end date, since the end date cannot be earlier than the start date
    [datePicker setDate:endDate animated:YES];
    [self showPickerView:YES];
}

- (void)chooseTransactionType{
    transactionTypePicker.hidden = NO;
    datePicker.hidden = YES;
    NSArray *keys = [transactionTypes allKeys];
    int index = [keys indexOfObject:transactionTypeKey];
    [transactionTypePicker selectRow:index inComponent:0 animated:YES];
    [self showPickerView:YES];
}

#pragma mark UITableViewDataSource Methods

-(int)numberOfSectionsInTableView:(UITableView *)tableView{
    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"TransactionsListFilterCell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    }
    
    // Configure the cell.
    NSString *cellText = @"";
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"dd/MM/yyyy"];
    if (indexPath.section == StartDateTableViewSection){
        cellText = [dateFormatter stringFromDate:startDate];
    }else if (indexPath.section == EndDateTableViewSection){
        cellText = [dateFormatter stringFromDate:endDate];
    }else if (indexPath.section == TransactionTypeTableViewSection){
        cellText = transactionTypeKey;
    }
    cellText = [NSString stringWithFormat:@"  %@", cellText];
    cell.textLabel.text = cellText;
    cell.textLabel.textColor = [UIColorList lightBlueColor];
    cell.accessoryView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Blue_Arrow"]];
    
    return cell;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    NSString  *sectionTitle = @"  ";
    if (section == StartDateTableViewSection){
        sectionTitle = [NSString stringWithFormat:@"%@Fecha de Inicio", sectionTitle];
    }else if (section == EndDateTableViewSection){
        sectionTitle = [NSString stringWithFormat:@"%@Fecha de Fin", sectionTitle];
    }else if (section == TransactionTypeTableViewSection){
        sectionTitle = [NSString stringWithFormat:@"%@Tipos de Transacciones", sectionTitle];
    }
    return sectionTitle;
}

#pragma mark UITableViewDataDelegate Methods
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    selectedIndexPath = indexPath;
    if (indexPath.section == StartDateTableViewSection){
        [self chooseStartDate];
    }else if (indexPath.section == EndDateTableViewSection){
        [self chooseEndDate];
    }else if (indexPath.section == TransactionTypeTableViewSection){
        [self chooseTransactionType];
    }
}

#pragma mark UIPickerViewDataSource

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    int numberOfColumns = 0;
    if (pickerView.tag == DatePickerTag){
    
    }else if (pickerView.tag == TransactionTypePickerTag){
        numberOfColumns = 1;
    }
    return numberOfColumns;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    int numberOfRows = 0;
    if (pickerView.tag == DatePickerTag){
        
    }else if (pickerView.tag == TransactionTypePickerTag){
        numberOfRows = [[transactionTypes allKeys] count];
    }
    return numberOfRows;
}

#pragma mark UIPickerViewDelegate Methods

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    NSArray *keys = [transactionTypes allKeys];
    return [keys objectAtIndex:row];
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{

}

@end
