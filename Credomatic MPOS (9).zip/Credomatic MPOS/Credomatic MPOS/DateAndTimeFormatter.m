//
//  DateAndTimeFormatter.m
//  Credomatic MPOS
//
//  Created by Jose Saurez on 11/22/13.
//  Copyright (c) 2013 Mobtion. All rights reserved.
//

#import "DateAndTimeFormatter.h"

#define BackendDateFormat @"MMddyyyy"
#define BackendTimeFormat @"HHmmss"

#define AppDateFormat @"dd/MM/yy"
#define AppTimeFormat @"HH:mm:ss"

@implementation DateAndTimeFormatter

+ (NSDate *)convertDateFromBackend:(NSString *)dateStr{
    // Convert string to date object
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:BackendDateFormat];
    NSDate *date = [dateFormat dateFromString:dateStr];
    return date;
}

+ (NSDate *)convertTimeFromBackend:(NSString *)timeStr{
    // Convert string to date object
    NSDateFormatter *timeFormat = [[NSDateFormatter alloc] init];
    [timeFormat setDateFormat:BackendTimeFormat];
    timeFormat.locale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
    NSDate *time = [timeFormat dateFromString:timeStr];
    return time;
}

+ (NSString *)formatDate:(NSDate *)date{
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:AppDateFormat];
    return [NSString stringWithFormat:@"%@", [dateFormat stringFromDate:date]];
}

+ (NSString *)formatTime:(NSDate *)time{
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:AppTimeFormat];
    return [NSString stringWithFormat:@"%@", [dateFormat stringFromDate:time]];
}

+ (NSString *)formatDateAndTime:(NSDate *)date time:(NSDate *)time separatedBy:(NSString *)separatedBy{
    NSString *dateStr = [DateAndTimeFormatter formatDate:date];
    NSString *timeStr = [DateAndTimeFormatter formatTime:time];
    NSString *dateAndTimeStr = [NSString stringWithFormat:@"%@ %@", dateStr, timeStr];
    if (![separatedBy isEqualToString:@""]){
        dateAndTimeStr = [NSString stringWithFormat:@"%@ %@ %@", dateStr, separatedBy,timeStr];
    }
    return dateAndTimeStr;
}

@end
