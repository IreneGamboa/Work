/*
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  SettlementMainViewController.m
//  Zimple POS
//

#import "SettlementMainViewController.h"

#define SettlementConfirmationAllAffiliatesAlertViewTag 0
#define SettlementConfirmationAlertViewTag 1
#define SettlementResultAlertViewTag 2
#define SettlementAllTerminalsResultAlertViewTag 3
#define NoAffiliatesAlertViewTag 4

#define ErrorAlertViewTag 100

@interface SettlementMainViewController ()

@property (nonatomic) BOOL settlingAllTerminals;
@property (nonatomic) int settlingAllTerminalsCurrentIndex;

@end

@implementation SettlementMainViewController

@synthesize titleLabel;
@synthesize affiliatesTableView;
@synthesize settlingAllTerminals;
@synthesize settlingAllTerminalsCurrentIndex;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    UIView *tableViewBackgroundView = [[UIView alloc] initWithFrame:affiliatesTableView.frame];
    tableViewBackgroundView.backgroundColor = [UIColor clearColor];
    affiliatesTableView.backgroundView = tableViewBackgroundView;
    affiliatesTableView.backgroundColor = [UIColor clearColor];
    titleLabel.textColor = [UIColorList credomaticBlueColor];
    
    settlingAllTerminals = NO;
    settlingAllTerminalsCurrentIndex = 0;
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    if([userInfo.terminalInfo.terminal.affiliatesWithSettlementPermissions count] <= 0){
        UIAlertView *noAffiliatesAlertView = [[UIAlertView alloc] initWithTitle:@"Cierre de Terminal" message:@"Su cuenta no posee afiliados con permisos de cierre." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        noAffiliatesAlertView.tag = NoAffiliatesAlertViewTag;
        [noAffiliatesAlertView show];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
    [self setAffiliatesTableView:nil];
    [self setTitleLabel:nil];
    [super viewDidUnload];
}

- (void)settleTerminal:(Affiliate *)affiliate{
    self.HUD.labelText = [NSString stringWithFormat:@"Cerrando Terminal \"%@\"", affiliate.affiliateTitle];
    [self.HUD show:YES];
    SalesManager *salesManager = [[SalesManager alloc] init];
    salesManager.salesManagerDelegate = self;
    [salesManager settleTerminal:affiliate];
}

- (void)settleAllTerminals:(int)currenTerminalIndex{
    settlingAllTerminals = YES;
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    if (currenTerminalIndex < [userInfo.terminalInfo.terminal.affiliatesWithSettlementPermissions count]){
        // Settle the current terminal
        Affiliate *affiliate = [userInfo.terminalInfo.terminal.affiliatesWithSettlementPermissions objectAtIndex:currenTerminalIndex];
        [self settleTerminal:affiliate];
    }else{
        settlingAllTerminals = NO;
        // Settling done
        UIAlertView *settlingAllTerminalsDone = [[UIAlertView alloc] initWithTitle:@"Cierre de Afiliados" message:@"El cierre para todos los afiliados ha concluido." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        settlingAllTerminalsDone.tag = SettlementAllTerminalsResultAlertViewTag;
        [settlingAllTerminalsDone show];
    }
}

#pragma mark UITableViewDataSource Methods

-(int)numberOfSectionsInTableView:(UITableView *)tableView{
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    // Return all the Affiliates + 1 cell for closing all Affiliates
    return [userInfo.terminalInfo.terminal.affiliatesWithSettlementPermissions count] + 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    NSString *sectionTitle = @"";
    if (section == 0){
        sectionTitle = @"Afiliados";
    }
    return sectionTitle;
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    
    static NSString *CellIdentifier = @"SettleAffiliateCell";
    if (indexPath.section == [userInfo.terminalInfo.terminal.affiliatesWithSettlementPermissions count]){
        CellIdentifier = @"SettleAllAffiliatesCell";
    }
    SettlementTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[SettlementTableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    }
    
    // Configure the cell.
    cell.backgroundColor = [UIColor clearColor];
    cell.textLabel.textColor = [UIColor whiteColor];
    if (indexPath.section == [userInfo.terminalInfo.terminal.affiliatesWithSettlementPermissions count]){
        cell.backgroundColor = [UIColorList credomaticBlueColor];
        cell.cellTextLabel.text = @"Cerrar Todos";
    }else
    {
        cell.backgroundColor = [UIColorList lightBlueColor];
        UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
        Affiliate *affiliate = [userInfo.terminalInfo.terminal.affiliatesWithSettlementPermissions objectAtIndex:indexPath.section];
        cell.cellTextLabel.text = affiliate.affiliateTitle;
    }
    
    return cell;
}

#pragma mark UITableViewDataDelegate Methods

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    if (indexPath.section != [userInfo.terminalInfo.terminal.affiliatesWithSettlementPermissions count]){
        UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
        Affiliate *affiliate = [userInfo.terminalInfo.terminal.affiliatesWithSettlementPermissions objectAtIndex:indexPath.section];
        UIAlertView *affiliateSettlementConfirmationAlertView = [[UIAlertView alloc] initWithTitle:@"Cierre de Terminal" message:[NSString stringWithFormat:@"¿Está seguro que desea realizar el cierre para el afiliado \"%@\". Este proceso no se puede reversar.", affiliate.affiliateTitle] delegate:self cancelButtonTitle:@"No" otherButtonTitles:@"Sí", nil];
        affiliateSettlementConfirmationAlertView.tag = SettlementConfirmationAlertViewTag;
        [affiliateSettlementConfirmationAlertView show];
    }else{
        UIAlertView *settlementConfirmationAlertView = [[UIAlertView alloc] initWithTitle:@"Cierre de Terminal" message:@"¿Está seguro que desea realizar el cierre para todos los afiliados de la terminal?. Este proceso no se puede reversar." delegate:self cancelButtonTitle:@"No" otherButtonTitles:@"Sí", nil];
        settlementConfirmationAlertView.tag = SettlementConfirmationAllAffiliatesAlertViewTag;
        [settlementConfirmationAlertView show];
    }
}

#pragma mark - UIAlertViewDelegate Methods

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView.tag == SettlementConfirmationAllAffiliatesAlertViewTag){
        if (buttonIndex != alertView.cancelButtonIndex){
            // Yes, proceed to settle all the affiliates in the terminal
            [self settleAllTerminals:settlingAllTerminalsCurrentIndex];
            
        }
    }else if (alertView.tag == SettlementConfirmationAlertViewTag){
        if (buttonIndex != alertView.cancelButtonIndex){
            // Yes, proceed to settle the selected affiliate in the terminal
            // Obtain the selected affiliate in the tableview
            UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
            Affiliate *affiliate = [userInfo.terminalInfo.terminal.affiliatesWithSettlementPermissions objectAtIndex:affiliatesTableView.indexPathForSelectedRow.section];
            [self settleTerminal:affiliate];
        }
    }else if (alertView.tag == SettlementResultAlertViewTag){
        if (buttonIndex != alertView.cancelButtonIndex){
            
        }
    }else if (alertView.tag == SettlementAllTerminalsResultAlertViewTag){
    
    }else if (alertView.tag == NoAffiliatesAlertViewTag){
        [self.viewDeckController openLeftView];
    }
}

#pragma mark SalesManagerDelegate Methods

- (void)settleTerminalResponseReceived:(BOOL)terminalSettlementResult error:(NSError *)error{
    [self.HUD hide:YES];
    //NSLog(@"SettleTerminalResponseReceived: %d", terminalSettlementResult);
    
    if (terminalSettlementResult){
        if (!settlingAllTerminals){
            UIAlertView *affiliateSettlementCompletedAlertView = [[UIAlertView alloc] initWithTitle:@"Cierre de Terminal" message:@"El proceso de cierre ha concluido con éxito." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
            affiliateSettlementCompletedAlertView.tag = SettlementResultAlertViewTag;
            [affiliateSettlementCompletedAlertView show];
        }else{
            ++settlingAllTerminalsCurrentIndex;
            [self settleAllTerminals:settlingAllTerminalsCurrentIndex];
        }
    }else{
        if (![super checkSessionExpiration:error]){
            UIAlertView *errorAlertView = [[UIAlertView alloc] initWithTitle:@"Cierre de Afiliado" message:error.localizedDescription delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
            errorAlertView.delegate = self;
            errorAlertView.tag = ErrorAlertViewTag;
            [errorAlertView show];
        }
    }
    
    [affiliatesTableView deselectRowAtIndexPath:affiliatesTableView.indexPathForSelectedRow animated:YES];
}

@end
