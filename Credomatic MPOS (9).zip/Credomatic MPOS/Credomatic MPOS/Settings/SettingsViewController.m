/*
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  SettingsViewController.m
//  Zimple POS
//

#import "SettingsViewController.h"

#define AccountSettingsSectionNumber 0
#define ChangePasswordRowNumber 0
#define ChangePINNumberRowNumber 1

#define TaxesSettingsSectionNumber 1
#define TaxesRowNumber 0
#define TaxesPecentageRowNumber 1

#define TipRowNumber 0

#define EnableTaxesSwitchTag 0
#define EnableTipsSwitchTag 1
#define TaxAmountAlertViewTag 0

@interface SettingsViewController ()

@property (strong, nonatomic) UISwitch *enableTaxesSwitch;
@property (nonatomic) float taxPercentage;

@property (strong, nonatomic) UISwitch *enableTipsSwitch;

@property (nonatomic) BOOL taxesEnabled;

@end

@implementation SettingsViewController

@synthesize settingsTableView;
@synthesize enableTaxesSwitch;
@synthesize enableTipsSwitch;
@synthesize taxesEnabled;
@synthesize taxPercentage;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    UIView *tableViewBackgroundView = [[UIView alloc] initWithFrame:settingsTableView.frame];
    settingsTableView.backgroundView = tableViewBackgroundView;
    settingsTableView.backgroundColor = [UIColor clearColor];
    
    settingsTableView.separatorColor = [UIColorList lightBlueColor];
    settingsTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    settingsTableView.backgroundView.hidden = YES;
    
    enableTaxesSwitch = [[UISwitch alloc] init];
    enableTaxesSwitch.tag = EnableTaxesSwitchTag;
    [enableTaxesSwitch addTarget:self action:@selector(uiSwitchValueChanged:) forControlEvents:UIControlEventValueChanged];
    [enableTaxesSwitch setOnTintColor:[UIColorList credomaticBlueColor]];
    
    enableTipsSwitch = [[UISwitch alloc] init];
    enableTipsSwitch.tag = EnableTipsSwitchTag;
    [enableTipsSwitch addTarget:self action:@selector(uiSwitchValueChanged:) forControlEvents:UIControlEventValueChanged];
    [enableTipsSwitch setOnTintColor:[UIColorList credomaticBlueColor]];
    
    taxPercentage = [SettingsManager getTaxPercentageUserDefault];
    
    if (taxPercentage <= 0){
        taxesEnabled = FALSE;
    }else{
        taxesEnabled = TRUE;
    }
    enableTaxesSwitch.on = taxesEnabled;
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [settingsTableView deselectRowAtIndexPath:settingsTableView.indexPathForSelectedRow  animated:YES];
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    // Save the settings
    if (taxesEnabled){
        [SettingsManager writeTaxPercentageUserDefault:taxPercentage];
    }else{
        [SettingsManager writeTaxPercentageUserDefault:0];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)uiSwitchValueChanged:(id)sender{
    //NSLog(@"Value Changed");
    UISwitch *uiSwitch = sender;
    if (uiSwitch.tag == EnableTaxesSwitchTag){
        taxesEnabled = [uiSwitch isOn];
        NSIndexPath *indexPath = [NSIndexPath indexPathForItem:TaxesPecentageRowNumber inSection:TaxesSettingsSectionNumber];
        NSArray *indexesArray = [[NSArray alloc] initWithObjects:indexPath, nil];
        [settingsTableView beginUpdates];
        if (taxesEnabled){
            [settingsTableView insertRowsAtIndexPaths:indexesArray withRowAnimation:UITableViewRowAnimationTop];
        }else{
            [settingsTableView deleteRowsAtIndexPaths:indexesArray withRowAnimation:UITableViewRowAnimationBottom];
        }
        [settingsTableView endUpdates];
    }else if (uiSwitch.tag == EnableTipsSwitchTag){
    
    }
    
    // Save the settings
    if (taxesEnabled){
        [SettingsManager writeTaxPercentageUserDefault:taxPercentage];
    }else{
        [SettingsManager writeTaxPercentageUserDefault:0];
    }

}

#pragma mark UITableViewDataSource Methods

-(int)numberOfSectionsInTableView:(UITableView *)tableView{
    // Don't show the Taxes Section
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    int numberOfRows = 0;
    if (section == AccountSettingsSectionNumber){
        numberOfRows =2;
    }else if (section == TaxesSettingsSectionNumber){
        if (!taxesEnabled){
            numberOfRows = 1;
        }else{
            numberOfRows = 2;
        }
    }
    return numberOfRows;
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"SettingsCell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    }
    
    // Configure the cell.
    cell.textLabel.textColor = [UIColorList lightBlueColor];
    cell.accessoryView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Blue_Arrow"]];
    if (indexPath.section == AccountSettingsSectionNumber){
        if (indexPath.row == ChangePasswordRowNumber) {
            cell.textLabel.text = @"Cambiar contraseña";
        }else if (indexPath.row == ChangePINNumberRowNumber){
            cell.textLabel.text = @"Cambiar PIN";
        }
    }else if (indexPath.section == TaxesSettingsSectionNumber){
        if (indexPath.row == TaxesRowNumber) {
            cell.textLabel.text = @"Cobrar Impuestos";
            cell.accessoryView = enableTaxesSwitch;
        }else if (indexPath.row == TaxesPecentageRowNumber) {
            cell.textLabel.text = @"Porcentaje";
            if (taxPercentage > 0){
                cell.detailTextLabel.text = [NSString stringWithFormat:@"%.02f %%", taxPercentage];
            }
        }
        
    }
    
    return cell;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    NSString *headerTitle = @"";
    if (section == AccountSettingsSectionNumber){
        headerTitle = @"Administración de Cuenta";
    }else if (section == TaxesSettingsSectionNumber){
        headerTitle = @"Impuestos";
    }
    return  headerTitle;
}

#pragma mark UITableViewDataDelegate Methods

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == AccountSettingsSectionNumber){
        if (indexPath.row == ChangePasswordRowNumber){
            [self performSegueWithIdentifier:@"SettingsToChangePasswordSegue" sender:self];
        }else if (indexPath.row == ChangePINNumberRowNumber){
            [self performSegueWithIdentifier:@"SettingsToChangePINSegue" sender:self];
        }
    }else if (indexPath.section == TaxesSettingsSectionNumber){
        if (indexPath.row == TaxesRowNumber){
            enableTaxesSwitch.on = !enableTaxesSwitch.on;
            [self uiSwitchValueChanged:enableTaxesSwitch];
        }else if (indexPath.row == TaxesPecentageRowNumber){
            // Show an alertview with a textfield to enter the amount
            UIAlertView *taxAmountAlertView = [[UIAlertView alloc] initWithTitle:@"Porcentaje de Impuestos" message:@"Ingrese el porcentaje a cobrar por impuestos" delegate:self cancelButtonTitle:@"Cancelar" otherButtonTitles:@"Ok", nil];
            taxAmountAlertView.alertViewStyle = UIAlertViewStylePlainTextInput;
            taxAmountAlertView.tag = TaxAmountAlertViewTag;
            UITextField *amountTextField = [taxAmountAlertView textFieldAtIndex:0];
            amountTextField.placeholder = @"Porcentaje de Impuestos";
            amountTextField.textAlignment = NSTextAlignmentCenter;
            amountTextField.keyboardType = UIKeyboardTypeDecimalPad;
            [taxAmountAlertView show];
        }
    }
}

#pragma mark UIAlertViewDelegate Methods

- (BOOL)alertViewShouldEnableFirstOtherButton:(UIAlertView *)alertView
{
    NSString *inputText = [[alertView textFieldAtIndex:0] text];
    if( [inputText floatValue] > 0 )
    {
        return YES;
    }
    else
    {
        return NO;
    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView.tag == TaxAmountAlertViewTag){
        if (buttonIndex != alertView.cancelButtonIndex){
            UITextField *valueTextField = [alertView textFieldAtIndex:0];
            taxPercentage = [valueTextField.text floatValue];
            [SettingsManager writeTaxPercentageUserDefault:taxPercentage];
            [settingsTableView reloadData];
        }
    }
    [settingsTableView deselectRowAtIndexPath:settingsTableView.indexPathForSelectedRow animated:YES];
}

@end
