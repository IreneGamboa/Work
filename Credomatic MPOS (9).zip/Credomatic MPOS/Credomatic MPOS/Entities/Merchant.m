/*
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  Merchant.m
//  Zimple POS
//

#import "Merchant.h"

@implementation Merchant

+(JSONKeyMapper*)keyMapper
{
    return [[JSONKeyMapper alloc] initWithDictionary:@{
            @"legal_name":@"legalName",
            @"fantasy_name":@"fantasyName",
            
            @"use_tax":@"useTax",
            @"use_tip":@"useTip",
            @"tip_type":@"tipType",
            @"tax_type":@"taxType",
            @"max_tax_percent":@"maxTaxPercent",
            @"max_tax_amount":@"maxTaxAmount",
            @"max_tip_percent_1":@"maxTipPercent1",
            @"max_tip_percent_2":@"maxTipPercent2",
            @"max_tip_percent_3":@"maxTipPercent3",
            @"max_tip_amount":@"maxTipAmount",
            }];
}

- (TaxType)merchantTaxType{
    //if ([self.taxType intValue] == PercentageTaxType){
        //return PercentageTaxType;
    //}
    // Even if the backend is configured to PercentageTaxType, the application must use the tax as MaxAmountTaxType
    return MaxAmountTaxType;
}

- (TipType)merchantTipType{
    /*if ([self.tipType intValue] == PercentageTipType){
        return PercentageTipType;
    }
    return MaxAmountTipType;*/
    return MixedTipType;                 // For Credomatic, when the tip is enabled, it is always Mixed Type.
}

- (NSMutableArray *)merchantTipPercentageValues{
    NSMutableArray *percetageTips = [[NSMutableArray alloc] init];
    if (self.maxTipPercent1 != nil){
        [percetageTips addObject:self.maxTipPercent1];
    }
    if (self.maxTipPercent2 != nil){
        [percetageTips addObject:self.maxTipPercent2];
    }
    if (self.maxTipPercent3 != nil){
        [percetageTips addObject:self.maxTipPercent3];
    }
    return percetageTips;
}

@end
