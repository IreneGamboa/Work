/*
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  TransactionResult.m
//  Zimple POS
//

#import "TransactionResult.h"

@implementation TransactionResult

+(JSONKeyMapper*)keyMapper
{
    return [[JSONKeyMapper alloc] initWithDictionary:@{
            @"zimple_transaction_id":@"zimpleTransactionId",
            }];
}

-(NSDate*)transactionDate{
    return [DateAndTimeFormatter convertDateFromBackend:self.hostDate];
}

-(NSDate*)transactionTime{
    return [DateAndTimeFormatter convertTimeFromBackend:self.hostTime];;
}

-(NSString *)transactionDateWithFormat{
    return [DateAndTimeFormatter formatDate:self.transactionDate];
}

-(NSString *)transactionTimeWithFormat{
    /*// Convert date object to desired output format
    NSDateFormatter *timeFormatter = [[NSDateFormatter alloc] init];
    [timeFormatter setDateFormat:@"HH:mm:ss"];
    return[timeFormatter stringFromDate:self.transactionTime];*/
    return [DateAndTimeFormatter formatTime:self.transactionTime];
}

-(NSString *)transactionDateAndTimeWithFormat{
    /*// Convert date object to desired output format
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"dd/MM/yy"];
    return[NSString stringWithFormat:@"%@ %@", self.transactionDateWithFormat, self.transactionTimeWithFormat];*/
    return [DateAndTimeFormatter formatDateAndTime:self.transactionDate time:self.transactionTime separatedBy:@"-"];
}


-(NSString *)salesAmountWithFormat{
    // The Sales Amount has its decimals in the last two values.
    NSString *salesAmountWithDecimals = [NSString stringWithFormat:@"%@.%@", [self.salesAmount substringToIndex:self.salesAmount.length-2],[self.salesAmount substringFromIndex:self.salesAmount.length-2]];
    //NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
    //[numberFormatter setPositiveFormat:@"#,##0.00"];
    //return [numberFormatter stringFromNumber:[NSNumber numberWithFloat:salesAmountWithDecimals.floatValue]];
    NSNumber *salesAmountWithDecimalsNumber =  [AmountFormatter convertAmountToNumber:salesAmountWithDecimals];
    NSString *formattedAmount = [AmountFormatter formatNumberAmountAsString:salesAmountWithDecimalsNumber];
    return formattedAmount;
    
}

@end
