/*
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  SaleTransactionInfo.m
//  Zimple POS
//

#import "SaleTransactionInfo.h"

@implementation SaleTransactionInfo

@synthesize taxValue;
@synthesize tipValue;

/*- (float)saleTotalAmount{
    NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
    [numberFormatter setDecimalSeparator:@","];
    NSNumber *amountNumber = [numberFormatter numberFromString:self.amount];
    if (amountNumber == nil){
        // If the amountNumber is nil, try changing the decimal separator from , to .
        [numberFormatter setDecimalSeparator:@"."];
        amountNumber = [numberFormatter numberFromString:self.amount];
    }
    float totalAmount = 0;
    float amountAsFloat = [amountNumber floatValue];
    float taxAmount = [taxPercentage floatValue];
    float tipAmount = [tipValue floatValue];
    float taxAmountToAdd = 0;
    float tipAmountToAdd = 0;
    
    // The Total Amount is calculated by:
    // The tip value is taken from the original sale amount
    // The tax value is taken from the original sale amount
    // Both tip and taces are added to the original amount, resulting in the Total Amount.
    
    totalAmount = amountAsFloat;
    // Calculate the taxes percentage from the original amount
    taxAmountToAdd = (totalAmount * taxAmount) / 100;
    
    // Calculate the tip from the original amount
    if (!isTipPercetage){
        // Switch is off => Local currency
        tipAmountToAdd += tipAmount;
    }else{
        // Switch is on => Percentage
        tipAmountToAdd += (totalAmount * tipAmount) / 100;
    }
    
    // Add both, the tax and tip, to the total amount
    totalAmount += taxAmountToAdd;
    totalAmount += tipAmountToAdd;
    
    return totalAmount;
}*/

- (id)init{
	if (self == [super init]){
		// Make custom init
        UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
        /*if (userInfo.terminalInfo.merchant.merchantTaxType == MaxAmountTaxType){
            self.taxValue = userInfo.terminalInfo.merchant.maxTaxAmount;
        }else{
            self.taxValue = userInfo.terminalInfo.merchant.maxTaxPercent;
        }*/
        self.taxValue = @"";
        
        /*if (userInfo.terminalInfo.merchant.merchantTipType == MaxAmountTipType){
            //self.tipValue = userInfo.terminalInfo.merchant.maxTipAmount;
            // By Default, set the tip amount to 0
            self.tipValue = @"0";
        }else{
            if (userInfo.terminalInfo.merchant.merchantTipPercentageValues.count > 0){
                self.tipValue = [userInfo.terminalInfo.merchant.merchantTipPercentageValues objectAtIndex:0];
            }else{
                self.tipValue = 0;
            }
        }*/
        
        self.tipValue = @"0";
	}
	return self;
}

- (double)saleTotalAmount{
    double totalAmount = 0;
    //float amountAsFloat = [[self amountAsNumber] floatValue];
    double amountAsDouble = [AmountFormatter convertAmountToDouble:self.amount];
    
    // The Total Amount is calculated by:
    // The tip value is taken from the original sale amount
    // The tax value is taken from the original sale amount
    // Both tip and taces are added to the original amount, resulting in the Total Amount.
    
    totalAmount = amountAsDouble;
    
    // Add both, the tax and tip, to the total amount
    totalAmount += [self taxAmount];
    totalAmount += [self tipAmount];
    
    return totalAmount;
}

/*- (NSNumber *)amountAsNumber{
    NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
    [numberFormatter setDecimalSeparator:@","];
    NSNumber *amountNumber = [numberFormatter numberFromString:self.amount];
    if (amountNumber == nil){
        // If the amountNumber is nil, try changing the decimal separator from , to .
        [numberFormatter setDecimalSeparator:@"."];
        amountNumber = [numberFormatter numberFromString:self.amount];
    }
    return amountNumber;
}*/

- (double)taxAmount{
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    //float amountAsFloat = [[self amountAsNumber] floatValue];
    double amountAsDouble = [AmountFormatter convertAmountToDouble:self.amount];
    double taxAmount = [taxValue doubleValue];
    double taxAmountToAdd = 0;
    // Calculate the taxes percentage from the original amount
    if (userInfo.terminalInfo.merchant.merchantTaxType == MaxAmountTaxType){
        taxAmountToAdd += taxAmount;
    }else{
        taxAmountToAdd += (amountAsDouble * taxAmount) / 100;
    }
    
    return taxAmountToAdd;
}

- (double)tipAmount{
    UserInfo *userInfo = [UserInfo getInstanceOfUserInfo];
    //float amountAsFloat = [[self amountAsNumber] floatValue];
    double amountAsDouble = [AmountFormatter convertAmountToDouble:self.amount];
    double tipAmount = [tipValue doubleValue];
    double tipAmountToAdd = 0;
    // Calculate the tip from the original amount
    if (userInfo.terminalInfo.merchant.merchantTipType == MaxAmountTaxType || userInfo.terminalInfo.merchant.merchantTipType == MixedTipType){
        // Switch is off => Local currency
        tipAmountToAdd += tipAmount;
    }else{
        // Switch is on => Percentage
        tipAmountToAdd += (amountAsDouble * tipAmount) / 100;
    }
    
    return tipAmountToAdd;
}

- (NSString *)saleTotalAmountWithFormat{
    NSString *formattedAmount = [AmountFormatter formatDoubleAmountAsString:self.saleTotalAmount];
    return formattedAmount;
}

- (NSString *)tipAmountWithFormat{
    //NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
    //[numberFormatter setPositiveFormat:@"#,##0.00"];
    //return [numberFormatter stringFromNumber:[NSNumber numberWithFloat:self.tipAmount]];
    
    NSString *formattedAmount = [AmountFormatter formatDoubleAmountAsString:self.tipAmount];
    return formattedAmount;
}

- (NSString *)taxAmountWithFormat{
    //NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
    //[numberFormatter setPositiveFormat:@"#,##0.00"];
    //return [numberFormatter stringFromNumber:[NSNumber numberWithFloat:self.taxAmount]];
    
    NSString *formattedAmount = [AmountFormatter formatDoubleAmountAsString:self.taxAmount];
    return formattedAmount;
}

@end
