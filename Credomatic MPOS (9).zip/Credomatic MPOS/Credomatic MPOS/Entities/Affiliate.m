/*
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  Affiliate.m
//  Zimple POS
//

#import "Affiliate.h"

@interface Affiliate ()

@property (nonatomic, retain) NSString *maxAmountLimitStr;
@property (nonatomic, retain) NSString *dailyAmountLimitStr;
@property (nonatomic, retain) NSString *monthlyAmountLimitStr;
@property (nonatomic, retain) NSString *signatureAmountLimitStr;

@end

@implementation Affiliate

+(JSONKeyMapper*)keyMapper
{
    return [[JSONKeyMapper alloc] initWithDictionary:@{
            @"affiliate.iso_4217_currency_code":@"currencyCode",
            @"affiliate.affiliate_type.name":@"type",
            @"affiliate.name":@"name",
            @"affiliate.code":@"code",
            @"affiliate.status":@"status",
            
            @"max_amount_limit":@"maxAmountLimitStr",
            @"daily_amount_limit":@"dailyAmountLimitStr",
            @"monthly_amount_limit":@"monthlyAmountLimitStr",
            @"signature_amount_limit":@"signatureAmountLimitStr",
            @"bank_terminal_id":@"bankTerminalId",
            @"bank_terminal":@"bankTerminal",
            @"affiliate.performs_refunds":@"canPerformRefunds",
            @"affiliate.performs_sales":@"canPerformSales",
            @"affiliate.performs_voids":@"canPerformVoids",
            @"affiliate.performs_settlements":@"canPerformSettlements",
            @"affiliate.performs_tip_adjustments":@"canPerformTipAdjustements",
            }];
}

- (NSString *)affiliateTitle{
    //return [NSString stringWithFormat:@"Venta %@", self.currencyCode];
    return self.name;
}

- (float)maxAmountLimit{
    float value = VALUE_NOT_SET;
    if (self.maxAmountLimitStr != nil && ![self.maxAmountLimitStr isEqualToString:@""]){
        value = [self.maxAmountLimitStr floatValue];
    }
    return value;
}

- (float)dailyAmountLimit{
    float value = VALUE_NOT_SET;
    if (self.dailyAmountLimitStr != nil && ![self.dailyAmountLimitStr isEqualToString:@""]){
        value = [self.dailyAmountLimitStr floatValue];
    }
    return value;
}

- (float)monthlyAmountLimit{
    float value = VALUE_NOT_SET;
    if (self.monthlyAmountLimitStr != nil && ![self.monthlyAmountLimitStr isEqualToString:@""]){
        value = [self.monthlyAmountLimitStr floatValue];
    }
    return value;
}

- (float)signatureAmountLimit{
    float value = VALUE_NOT_SET;
    if (self.signatureAmountLimitStr != nil && ![self.signatureAmountLimitStr isEqualToString:@""]){
        value = [self.signatureAmountLimitStr floatValue];
    }
    return value;
}

@end
