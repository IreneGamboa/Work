/*
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  TransactionRecord.m
//  Zimple POS
//

#import "TransactionRecord.h"

@implementation TransactionRecord

+(JSONKeyMapper*)keyMapper
{
    return [[JSONKeyMapper alloc] initWithDictionary:@{
            @"transaction_type_id":@"transactionTypeId",
            @"transaction_type_text":@"transactionTypeText",
            @"transaction_status_id":@"transactionStatusId",
            @"transaction_status_text":@"transactionStatusText",
            @"sale_invoice":@"saleInvoice",
            @"amount":@"saleAmount",
            @"tax_amount":@"saleTaxAmount",
            @"tip_amount":@"saleTipAmount",
            @"card_postfix":@"creditCardLastDigits",
            @"sale_reference_number":@"saleReferenceNumber",
            @"sale_system_trace_number":@"saleSystemTraceNumber",
            @"sale_authorization_number":@"saleAuthorizationNumber",
            @"sale_response_code":@"saleResponseCode",
            @"sale_proxy_response":@"saleProxyCode",
            @"sale_transaction_id":@"saleTransactionId",
            @"sale_csp_date":@"saleCSPDate",
            @"sale_csp_time":@"saleCSPTime",
            @"sale_csp_duration":@"saleCSPDuration",
            @"zimple_transaction_id":@"zimpleTransactionId",
            @"voided":@"isVoided",
            @"voided_by_transaction_id":@"voidedByZimpleTransactionId",
            }];
}

-(NSDate*)transactionDate{
    return [DateAndTimeFormatter convertDateFromBackend:self.saleCSPDate];
}

-(NSDate*)transactionTime{
    return [DateAndTimeFormatter convertTimeFromBackend:self.saleCSPTime];
}

-(NSString *)transactionDateWithFormat{
    return [DateAndTimeFormatter formatDate:self.transactionDate];
}

-(NSString *)transactionDateAndTimeWithFormat{
    // Convert date object to desired output format
    /*NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"dd/MM/yy"];
    NSDateFormatter *timeFormat = [[NSDateFormatter alloc] init];
    [timeFormat setDateFormat:@"HH:mm:ss"];
    return [NSString stringWithFormat:@"%@ - %@", [dateFormat stringFromDate:self.transactionDate], [timeFormat stringFromDate:self.transactionTime]];*/
    
    return [DateAndTimeFormatter formatDateAndTime:self.transactionDate time:self.transactionTime separatedBy:@"-"];
}

-(NSString *)saleAmountWithFormat{
    //NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
    //[numberFormatter setPositiveFormat:@"#,##0.00"];
    //return [numberFormatter stringFromNumber:[NSNumber numberWithFloat:self.saleAmount.floatValue]];
    NSNumber *amountAsNumber = [AmountFormatter convertAmountToNumber:self.saleAmount];
    NSString *formattedAmount = [AmountFormatter formatNumberAmountAsString:amountAsNumber];
    return formattedAmount;
}

-(NSString *)subTotalSaleAmountWithFormat{
    //float totalAmount = [self.saleAmount floatValue] - [self.saleTaxAmount floatValue] - [self.saleTipAmount floatValue];
    //NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
    //[numberFormatter setPositiveFormat:@"#,##0.00"];
    //return [numberFormatter stringFromNumber:[NSNumber numberWithFloat:totalAmount]];*/
    double totalAmount = [AmountFormatter convertAmountToDouble:self.saleAmount] - [AmountFormatter convertAmountToDouble:self.saleTaxAmount] - [AmountFormatter convertAmountToDouble:self.saleTipAmount];
    NSString *formattedAmount = [AmountFormatter formatDoubleAmountAsString:totalAmount];
    return formattedAmount;
}

-(NSString *)tipAmountWithFormat{
    //NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
    //[numberFormatter setPositiveFormat:@"#,##0.00"];
    //return [numberFormatter stringFromNumber:[NSNumber numberWithFloat:[self.saleTipAmount floatValue]]];
    
    NSNumber *amountAsNumber = [AmountFormatter convertAmountToNumber:self.saleTipAmount];
    NSString *formattedAmount = [AmountFormatter formatNumberAmountAsString:amountAsNumber];
    return formattedAmount;
}

-(NSString *)taxAmountWithFormat{
    //NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
    //[numberFormatter setPositiveFormat:@"#,##0.00"];
    //return [numberFormatter stringFromNumber:[NSNumber numberWithFloat:[self.saleTaxAmount floatValue]]];
    
    NSNumber *amountAsNumber = [AmountFormatter convertAmountToNumber:self.saleTaxAmount];
    NSString *formattedAmount = [AmountFormatter formatNumberAmountAsString:amountAsNumber];
    return formattedAmount;
}

- (NSString *)maskedCreditCard{
    if (self.creditCardLastDigits != nil){
        return [NSString stringWithFormat:@"************%@", self.creditCardLastDigits];
    }
    return @"************%@";
}

@end
