/*
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  CreditCardInfo.m
//  Zimple POS
//

#import "CreditCardInfo.h"

@implementation CreditCardInfo

@synthesize creditCardEncryptedPayload;
@synthesize creditCardNumberMasked;
@synthesize cardHolderName;

#define STX @"02"
#define ETX @"03"

#define StartCentinel @"%"
#define FieldSeparator @"^"
#define LogitudinalRedundancyCheckStartCentiel @";"
#define EndCentinel @"?"

+(CreditCardInfo *)creditCardInfoFromHexEncryptedPayload:(NSString *)creditCardHexEncryptedPayload error:(NSError **)error{
    
    if ([CreditCardInfo validatePayLoadLength:creditCardHexEncryptedPayload] && [CreditCardInfo validateHashDataSentStatus:creditCardHexEncryptedPayload]){
        // Payload length and info are valid.
        CreditCardInfo *creditCardInfo = [[CreditCardInfo alloc] init];
        
        NSString *payloadAsString = [CreditCardInfo stringFromHex:creditCardHexEncryptedPayload];
        NSLog(@"Payload: %d", payloadAsString.length);
        NSLog(@"Payload: %@", payloadAsString);
        
        
        // Separete the track into the original track content and the Longitude Redundancy Check (LRC)
        NSArray *trackParts = [payloadAsString componentsSeparatedByString:EndCentinel];
        if ([trackParts count] >= 2){
            // At least to parts, the content and the LRC
            NSString *contentTrack = [trackParts objectAtIndex:0];
            //NSString *lcrTrack = [trackParts objectAtIndex:1];
            
            // Find the first number in the encryted payload
            int index = 0;
            BOOL numFounded = false;
            while (numFounded == false && index < [contentTrack length]) {
                if ([contentTrack characterAtIndex:index] == '0' ||
                    [contentTrack characterAtIndex:index] == '1' ||
                    [contentTrack characterAtIndex:index] == '2' ||
                    [contentTrack characterAtIndex:index] == '3' ||
                    [contentTrack characterAtIndex:index] == '4' ||
                    [contentTrack characterAtIndex:index] == '5' ||
                    [contentTrack characterAtIndex:index] == '6' ||
                    [contentTrack characterAtIndex:index] == '7' ||
                    [contentTrack characterAtIndex:index] == '8' ||
                    [contentTrack characterAtIndex:index] == '9'){
                    numFounded = TRUE;
                }else{
                    ++index;
                }
            }
            
            if(numFounded){
                NSString *ccInformation = [contentTrack substringFromIndex:index];
                
                // Save the Credit Card Number
                NSArray *ccInformationParts = [ccInformation componentsSeparatedByString:FieldSeparator];
                if ([ccInformationParts count] == 3){
                    // This information must contais 3 parts:
                    // The Credit Card Number
                    // The Credit Card Owner
                    // The Expiration Date, the Service Code and the Discretionary Data
                    creditCardInfo.creditCardNumberMasked = [ccInformationParts objectAtIndex:0];
                    // Try to parse the Owner Name
                    NSString *creditCardOwner = [ccInformationParts objectAtIndex:1];
                    NSArray *partNames = [creditCardOwner componentsSeparatedByString:@"/"];
                    if ([partNames count] == 2){
                        // Set the Owner by placing in the formar NAME LAST NAME, removing blank spaces at the end of the NAME
                        creditCardInfo.cardHolderName = [NSString stringWithFormat:@"%@ %@", [[partNames objectAtIndex:1] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]], [partNames objectAtIndex:0]];
                        
                        
                    }else{
                        creditCardInfo.cardHolderName = creditCardOwner;
                    }
                    
                    // Since the payload contains a valid format and the information has been parsed, set the hex encrypted payload to the credit card object
                    creditCardInfo.creditCardEncryptedPayload = creditCardHexEncryptedPayload;
                    
                    return creditCardInfo;
                    
                }else{
                    NSMutableDictionary *details = [NSMutableDictionary dictionary];
                    [details setValue:NSLocalizedString(@"CreditCardValidation_CannotParseInformation", @"") forKey:NSLocalizedDescriptionKey];
                    *error = [NSError errorWithDomain:@"Zimple" code:1 userInfo:details];
                }
            }else{
                NSMutableDictionary *details = [NSMutableDictionary dictionary];
                [details setValue:NSLocalizedString(@"CreditCardValidation_CannotParseInformation", @"") forKey:NSLocalizedDescriptionKey];
                *error = [NSError errorWithDomain:@"Zimple" code:1 userInfo:details];
            }
        }else{
            NSMutableDictionary *details = [NSMutableDictionary dictionary];
            [details setValue:NSLocalizedString(@"CreditCardValidation_EndSentinelNotFound", @"") forKey:NSLocalizedDescriptionKey];
            *error = [NSError errorWithDomain:@"Zimple" code:1 userInfo:details];
        }
    }else{
        NSMutableDictionary *details = [NSMutableDictionary dictionary];
        [details setValue:NSLocalizedString(@"CreditCardValidation_WrongPayloadLength", @"") forKey:NSLocalizedDescriptionKey];
        *error = [NSError errorWithDomain:@"Zimple" code:1 userInfo:details];
    }
    
    
    return nil;
}

+ (BOOL)validatePayLoadLength:(NSString *)creditCardHexPayload{
    /*
     Hex Encrypted Payload Definition:
     <STX><LenL><LenH><Card Data><CheckLRC><CheckSum><ETX>
     <STX> = 02h ==> Always look for 02 at the beggining
     <ETX> = 03h ==> Always look for 03 at the end
     <LenL><LenH> is a two byte length of <Card Data>. ==> To obtain the value just convert both values to decimal. Second, multiply by 256 to the LenH since its the high byte of the length.
     <CheckLRC> is a one byte Exclusive-OR sum calculated for all <Card Data>.
     <CheckSum> is a one byte Sum value calculated for all <Card data>.
     <Card Data> Card Data
     
     */
    
    if ([creditCardHexPayload hasPrefix:STX] && [creditCardHexPayload hasSuffix:ETX]){
        // Payload has the apropiate Beggining and End
        // Check for the total length of the <Card Data> section
        
        NSString *lenL = [[creditCardHexPayload substringFromIndex:2] substringToIndex:2];
        NSString *lenH = [[creditCardHexPayload substringFromIndex:4] substringToIndex:2];
        unsigned lenLInt = 0;
        unsigned lenHInt = 0;
        NSScanner *scanner = [NSScanner scannerWithString:lenL];
        [scanner scanHexInt:&lenLInt];
        scanner = [NSScanner scannerWithString:lenH];
        [scanner scanHexInt:&lenHInt];
        
        lenHInt *= 256;  // Add 256 to the lenHInt since its the
        
        int cardDataTotalLength = lenHInt + lenLInt; // carDataTotalLength is in regular chars (not hex)
        
        // The total payload must be the Card Data + 6 additional caracters in hex
        if (creditCardHexPayload.length == ((cardDataTotalLength + 6)*2)){
            return YES;
        }
    }
    return NO;
}

+ (BOOL)validateHashDataSentStatus:(NSString *)creditCardHexPayload{
    
    // The Credit Card Payload must contain at least two tracks of information (1 track reads are not valid)
    // So, the 9 byte of Credit Card Payload must be validated. This 9 byte of the payload is named the "Encrypted/Hash data sent status" and has information realted the tracks present on the payload.
    // The value must be read by bit like:
    /*  bit 0: if 1—tk1 encrypted data present 
        bit 1: if 1—tk2 encrypted data present 
        bit 2: if 1—tk3 encrypted data present 
        bit 3: if 1—tk1 hash data present
        bit 4: if 1—tk2 hash data present
        bit 5: if 1—tk3 hash data present
        Bit 6: if 1—session ID present
        Bit 7: if 1—KSN present
     The bit-7 is always enabled beacause we are using encrypted data
     So, in order to check that theres 2 or 3 tracks in the payload, this byte must have:
        - the first and second bit of the byte enabled for 2 tracks, resulting in a decimal value of 128 (key bit) + 3 = 131. This value in hex is 83
        - the first, second and third bit of the byte enabled for 3 tracks, resulting in a decimal value of 128 (key bit) + 7 = 135. This value in hex is 87
     
     Note: If theres only 1 track in the payload, only the firs bit will be enabled, resulting in a decimal value of 128 (key bit) + 1 = 129. This value in hex is 81. If this value is present, the payload is wrong.
    */
    
    // From the Hex Payload, get the 9 byte (the 18-19 characters)
    NSString *encryptedDatSentStatusHex = [[creditCardHexPayload substringFromIndex:18] substringToIndex:2];
    NSLog(@"EncryptedDatSentStatusHex: %@", encryptedDatSentStatusHex);
    if ([encryptedDatSentStatusHex isEqualToString:@"83"] || [encryptedDatSentStatusHex isEqualToString:@"87"]){
        return YES;
    }
    
    return NO;
}

+ (NSString *) stringFromHex:(NSString *)str
{
    NSMutableData *stringData = [[NSMutableData alloc] init];
    unsigned char whole_byte;
    char byte_chars[3] = {'\0','\0','\0'};
    int i;
    for (i=0; i < [str length] / 2; i++) {
        byte_chars[0] = [str characterAtIndex:i*2];
        byte_chars[1] = [str characterAtIndex:i*2+1];
        whole_byte = strtol(byte_chars, NULL, 16);
        [stringData appendBytes:&whole_byte length:1];
    }
    
    return [[NSString alloc] initWithData:stringData encoding:NSASCIIStringEncoding];
}

@end
