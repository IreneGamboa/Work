/*
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  TransactionResult.h
//  Zimple POS
//

#import <Foundation/Foundation.h>
#import "JSONModel.h"
#import "AmountFormatter.h"
#import "DateAndTimeFormatter.h"

@interface TransactionResult : JSONModel

@property (nonatomic, retain) NSString *responseCode;
@property (nonatomic, retain) NSString *responseCodeDescription;
@property (nonatomic, retain) NSString *hostTime;
@property (nonatomic, retain) NSString *hostDate;
@property (nonatomic, retain) NSString *referenceNumber;
@property (nonatomic, retain) NSString *authorizationNumber;
@property (nonatomic, retain) NSString *systemTraceNumber;
@property (nonatomic, retain) NSString *transactionId;
@property (nonatomic, retain) NSString *invoice;
@property (nonatomic, retain) NSString *salesAmount;
@property (nonatomic, retain) NSString *zimpleTransactionId;

-(NSDate*)transactionDate;
-(NSString *)transactionDateWithFormat;

-(NSString *)transactionDateAndTimeWithFormat;

-(NSString *)salesAmountWithFormat;

@end
