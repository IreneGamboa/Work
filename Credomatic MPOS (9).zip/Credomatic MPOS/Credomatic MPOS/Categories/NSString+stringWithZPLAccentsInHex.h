//
//  NSString+stringWithZPLAccentsInHex.h
//  Credomatic MPOS
//
//  Created by Jose Saurez on 11/22/13.
//  Copyright (c) 2013 Mobtion. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (stringWithZPLAccentsInHex)

- (NSString *)stringWithZPLAccentsInHex;

@end
