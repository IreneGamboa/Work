//
//  NSString+stringWithZPLAccentsInHex.m
//  Credomatic MPOS
//
//  Created by Jose Saurez on 11/22/13.
//  Copyright (c) 2013 Mobtion. All rights reserved.
//

#import "NSString+stringWithZPLAccentsInHex.h"

#define ZPLHexadecimalIndicator @"_"

@implementation NSString (stringWithZPLAccentsInHex)

- (NSString *)stringWithZPLAccentsInHex{
    NSString *stringWithAccents = self;
    
    stringWithAccents = [stringWithAccents stringByReplacingOccurrencesOfString:@"á" withString:[NSString stringWithFormat:@"%@A0", ZPLHexadecimalIndicator]];
    stringWithAccents = [stringWithAccents stringByReplacingOccurrencesOfString:@"é" withString:[NSString stringWithFormat:@"%@82", ZPLHexadecimalIndicator]];
    stringWithAccents = [stringWithAccents stringByReplacingOccurrencesOfString:@"í" withString:[NSString stringWithFormat:@"%@A1", ZPLHexadecimalIndicator]];
    stringWithAccents = [stringWithAccents stringByReplacingOccurrencesOfString:@"ó" withString:[NSString stringWithFormat:@"%@A2", ZPLHexadecimalIndicator]];
    stringWithAccents = [stringWithAccents stringByReplacingOccurrencesOfString:@"ú" withString:[NSString stringWithFormat:@"%@A3", ZPLHexadecimalIndicator]];
    stringWithAccents = [stringWithAccents stringByReplacingOccurrencesOfString:@"ñ" withString:[NSString stringWithFormat:@"%@A4", ZPLHexadecimalIndicator]];
    
    stringWithAccents = [stringWithAccents stringByReplacingOccurrencesOfString:@"Á" withString:[NSString stringWithFormat:@"%@B5", ZPLHexadecimalIndicator]];
    stringWithAccents = [stringWithAccents stringByReplacingOccurrencesOfString:@"É" withString:[NSString stringWithFormat:@"%@90", ZPLHexadecimalIndicator]];
    stringWithAccents = [stringWithAccents stringByReplacingOccurrencesOfString:@"Í" withString:[NSString stringWithFormat:@"%@D6", ZPLHexadecimalIndicator]];
    stringWithAccents = [stringWithAccents stringByReplacingOccurrencesOfString:@"Ó" withString:[NSString stringWithFormat:@"%@E0", ZPLHexadecimalIndicator]];
    stringWithAccents = [stringWithAccents stringByReplacingOccurrencesOfString:@"Ú" withString:[NSString stringWithFormat:@"%@E9", ZPLHexadecimalIndicator]];
    stringWithAccents = [stringWithAccents stringByReplacingOccurrencesOfString:@"Ñ" withString:[NSString stringWithFormat:@"%@A5", ZPLHexadecimalIndicator]];
    
    stringWithAccents = [stringWithAccents stringByReplacingOccurrencesOfString:@"^" withString:[NSString stringWithFormat:@"%@5E", ZPLHexadecimalIndicator]];
    stringWithAccents = [stringWithAccents stringByReplacingOccurrencesOfString:@"¿" withString:[NSString stringWithFormat:@"%@A8", ZPLHexadecimalIndicator]];
    stringWithAccents = [stringWithAccents stringByReplacingOccurrencesOfString:@"?" withString:[NSString stringWithFormat:@"%@3F", ZPLHexadecimalIndicator]];
    stringWithAccents = [stringWithAccents stringByReplacingOccurrencesOfString:@"@" withString:[NSString stringWithFormat:@"%@40", ZPLHexadecimalIndicator]];
    stringWithAccents = [stringWithAccents stringByReplacingOccurrencesOfString:@"¡" withString:[NSString stringWithFormat:@"%@AD", ZPLHexadecimalIndicator]];
    stringWithAccents = [stringWithAccents stringByReplacingOccurrencesOfString:@"!" withString:[NSString stringWithFormat:@"%@21", ZPLHexadecimalIndicator]];
    stringWithAccents = [stringWithAccents stringByReplacingOccurrencesOfString:@";" withString:[NSString stringWithFormat:@"%@3B", ZPLHexadecimalIndicator]];
    
    stringWithAccents = [stringWithAccents stringByReplacingOccurrencesOfString:@"(" withString:[NSString stringWithFormat:@"%@28", ZPLHexadecimalIndicator]];
    stringWithAccents = [stringWithAccents stringByReplacingOccurrencesOfString:@")" withString:[NSString stringWithFormat:@"%@29", ZPLHexadecimalIndicator]];
    stringWithAccents = [stringWithAccents stringByReplacingOccurrencesOfString:@"{" withString:[NSString stringWithFormat:@"%@7B", ZPLHexadecimalIndicator]];
    stringWithAccents = [stringWithAccents stringByReplacingOccurrencesOfString:@"}" withString:[NSString stringWithFormat:@"%@7D", ZPLHexadecimalIndicator]];
    stringWithAccents = [stringWithAccents stringByReplacingOccurrencesOfString:@"[" withString:[NSString stringWithFormat:@"%@5B", ZPLHexadecimalIndicator]];
    stringWithAccents = [stringWithAccents stringByReplacingOccurrencesOfString:@"]" withString:[NSString stringWithFormat:@"%@5D", ZPLHexadecimalIndicator]];
    stringWithAccents = [stringWithAccents stringByReplacingOccurrencesOfString:@"|" withString:[NSString stringWithFormat:@"%@7C", ZPLHexadecimalIndicator]];
    stringWithAccents = [stringWithAccents stringByReplacingOccurrencesOfString:@"\\" withString:[NSString stringWithFormat:@"%@5C", ZPLHexadecimalIndicator]];
    stringWithAccents = [stringWithAccents stringByReplacingOccurrencesOfString:@"/" withString:[NSString stringWithFormat:@"%@2F", ZPLHexadecimalIndicator]];
    
    return stringWithAccents;
}

@end
