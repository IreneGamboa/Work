//
//  UINavigationController+preferredStatusBarStyle.m
//  Credomatic MPOS
//
//  Created by Jose Saurez on 10/18/13.
//  Copyright (c) 2013 Mobtion. All rights reserved.
//

#import "UINavigationController+preferredStatusBarStyle.h"

@implementation UINavigationController (preferredStatusBarStyle)

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return [[self.viewControllers firstObject] preferredStatusBarStyle];
}

@end
