/*
 Copyright (c) 2013, MOBTION
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 
 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the BAC- CREDOMATIC nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  AmountFormatter.m
//  Zimple POS
//

#import "AmountFormatter.h"

@implementation AmountFormatter

+ (NSNumberFormatter *)amountNumberFormatter{
    NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
    [numberFormatter setNumberStyle:NSNumberFormatterDecimalStyle];
    //[numberFormatter setPositiveFormat:@"#,##0.00"];
    [numberFormatter setDecimalSeparator:@"."];
    [numberFormatter setGroupingSeparator:@","];
    [numberFormatter setGroupingSize:3];
    [numberFormatter setMinimumFractionDigits:2];
    [numberFormatter setMaximumFractionDigits:2];
    [numberFormatter setRoundingMode:NSNumberFormatterRoundDown];
    
    return numberFormatter;
}

+ (float)convertAmountToFloat:(NSString *)amount{
    NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
    [numberFormatter setDecimalSeparator:@","];
    [numberFormatter setMinimumFractionDigits:2];
    [numberFormatter setMaximumFractionDigits:2];
    [numberFormatter setRoundingMode:NSNumberFormatterRoundDown];
    NSNumber *amountNumber = [numberFormatter numberFromString:amount];
    if (amountNumber == nil){
        // If the amountNumber is nil, try changing the decimal separator from , to .
        [numberFormatter setDecimalSeparator:@"."];
        amountNumber = [numberFormatter numberFromString:amount];
    }
    
    float amountAsFloat = [amountNumber floatValue];
    
    return amountAsFloat;
}

+ (double)convertAmountToDouble:(NSString *)amount{
    NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
    [numberFormatter setDecimalSeparator:@","];
    [numberFormatter setMinimumFractionDigits:2];
    [numberFormatter setMaximumFractionDigits:2];
    [numberFormatter setRoundingMode:NSNumberFormatterRoundDown];
    NSNumber *amountNumber = [numberFormatter numberFromString:amount];
    if (amountNumber == nil){
        // If the amountNumber is nil, try changing the decimal separator from , to .
        [numberFormatter setDecimalSeparator:@"."];
        amountNumber = [numberFormatter numberFromString:amount];
    }
    
    double amountAsDouble = [amountNumber doubleValue];
    
    return amountAsDouble;
}

+ (NSNumber *)convertAmountToNumber:(NSString *)amount{
    NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
    [numberFormatter setDecimalSeparator:@","];
    [numberFormatter setMinimumFractionDigits:2];
    [numberFormatter setMaximumFractionDigits:2];
    [numberFormatter setRoundingMode:NSNumberFormatterRoundDown];
    NSNumber *amountNumber = [numberFormatter numberFromString:amount];
    if (amountNumber == nil){
        // If the amountNumber is nil, try changing the decimal separator from , to .
        [numberFormatter setDecimalSeparator:@"."];
        amountNumber = [numberFormatter numberFromString:amount];
    }
    
    return amountNumber;
}


+ (NSString *)formatNumberAmountAsString:(NSNumber *)amount{
    NSNumberFormatter *numberFormatter = [self amountNumberFormatter];
    
    NSString *formatttedAmount = [numberFormatter stringFromNumber:amount];
    
    return formatttedAmount;
}

+ (NSString *)formatFloatAmountAsString:(float)amount{
    NSNumberFormatter *numberFormatter = [self amountNumberFormatter];
    
    //NSNumber *amountAsNumber = [NSNumber numberWithFloat:amount];
    NSNumber *amountAsNumber = [NSNumber numberWithDouble:amount];
    NSString *formatttedAmount = [numberFormatter stringFromNumber:amountAsNumber];
    
    return formatttedAmount;
}

+ (NSString *)formatDoubleAmountAsString:(double)amount{
    NSNumberFormatter *numberFormatter = [self amountNumberFormatter];
    
    //NSNumber *amountAsNumber = [NSNumber numberWithFloat:amount];
    NSNumber *amountAsNumber = [NSNumber numberWithDouble:amount];
    NSString *formatttedAmount = [numberFormatter stringFromNumber:amountAsNumber];
    
    return formatttedAmount;
}

+ (NSString *)formatFloatAmountAsStringForBackend:(float)amount{
    return [NSString stringWithFormat:@"%0.2f", amount];
}

+ (NSString *)formatDoubleAmountAsStringForBackend:(double)amount{
    return [NSString stringWithFormat:@"%0.2f", amount];
}

@end
